<?php

require "connection.php";

require "SMTP.php";
require "PHPMailer.php";
require "Exception.php";

use PHPMailer\PHPMailer\PHPMailer;

if (isset($_GET["e"])) {

    $email = $_GET["e"];

    

    if ($n == 1) {


        $mail = new PHPMailer;
        $mail->IsSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ramindu.jiat@gmail.com';
        $mail->Password = 'eyvvqmmashucjssy';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('ramindu.jiat@gmail.com', 'Reset Password');
        $mail->addReplyTo('ramindu.jiat@gmail.com', 'Reset Password');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Media Center Forgot password Verification Code';
        $bodyContent = ' <center><img src="https://raw.githubusercontent.com/slramindu1/mysite1/31b095254238b3df569eb36970c325dd7ae1741a/2.png?token=BBPIBBTZ72A6JQDTIHO5ZFDE4LWLQ"/></center>
        Dear User,<br><br>
        We hope this message finds you well. At times, it becomes necessary to update and enhance the security measures associated with your account. As part of our commitment to maintaining the utmost security for your online presence, we provide you with the option to reset your password. This ensures that only you have access to your account, preventing unauthorized access and safeguarding your personal information. We understand that you might encounter situations where a password reset is essential, whether due to security concerns or a simple lapse in memory. In this email, we will guide you through the process of resetting your password, making it a seamless and secure experience. Your security is our top priority, and we are here to assist you every step of the way.<br><hr><br>
            We hope this email finds you well. It appears that you have requested a password reset for your account. <br> We understand that sometimes these things happen, and we are here to help you regain access to your account.
            To reset your password, please follow these steps:

    
<br>         <br>
            1. Click on the "Reset Password" button below.<br><br>
            2. You will be directed to a secure page where you can enter your new password.<br><br>
            3. Ensure your new password is strong and contains a combination of letters, numbers, and symbols.<br><br>
            4. Once you have entered your new password, click on the "Reset Password" button.<br><br>

            If you did not initiate this password reset, please ignore this email or contact our support team immediately at [ramindu.jiat@gmail.com] to secure your account.<br>
            <br>
                Thank you for being a valued member of our community.<br> If you have any further questions or need assistance, please dont hesitate to reach out to us.<br>

            <br>
            <h3 style="color:green;  font-weight:bold; ">Your verification code is ' . $code . '</h3><br>
            <br>
            Best regards,<br>
            <br>
           Media Center <br><br>
           Customer Support Team
           alt="">
           ';


        $mail->Body    = $bodyContent;
    }
}
