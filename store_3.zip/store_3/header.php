<header>
  <div class="header-top-area bb d-none d-lg-block">
    <div class="container">
      <div class="row">

        <div class="col-lg-4">

          <div class="language-menu dropdown">
            <?php

            session_start();

            if (isset($_SESSION["u"])) {

              $data = $_SESSION["u"];

            ?>

              <span class="text-lg-start"><b>Welcome </b><?php echo $data["fname"]; ?></span> |
              <span class="text-lg-start fw-bold signout" onclick="signout();">Sign Out</span> |

            <?php

            } else {

            ?>

              <a href="index.php" class="text-decoration-none fw-bold">Sign In or Register</a> |

            <?php

            }

            ?>

          </div>
        </div>
        <div class="col-lg-3">
          <p class="h2-color text-center">Welcome to MacroCart store!</p>
        </div>

        <div class="col-lg-5">
          <div class="header-top-right">
            <div class="account-menu">
              <ul>
                <li><a href="update_account.php">My Account</a></li>

                <li><a href="cart.php">Shopping Cart</a></li>
                <li><a href="wishlist.php">Wishlist</a></li>
                <li><a href="myproduct.php">My Product</a></li>
                <li><a href="addproduct.php">Add Prduct</a></li>
               
              </ul>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="header-middle-area">
    <div class="container">
      <div class="row align-items-center align-items-lg-start">
        <div class="col-lg-2 col-4 order-lg-1">
          <div class="logo">
            <a href="home.php">
              <img src="assets/images/logo/2.png" alt="" />
            </a>
          </div>
        </div>


        <div class="col-xl-7 col-lg-6 order-lg-2">
          <div class="search-box">
            <form action="#">
              <select name="#" id="select">
                <option value="0">All Categories</option>
                <?php
                require "connection.php";

                $category_rs = Database::search("SELECT * FROM `category`");
                $category_num = $category_rs->num_rows;

                for ($x = 0; $x < $category_num; $x++) {
                  $category_data = $category_rs->fetch_assoc();

                ?>

                  <option value="<?php echo $category_data["cat_id"]; ?>"><?php echo $category_data["cat_name"]; ?></option>

                <?php

                }

                ?>

              </select>
              <input type="text" placeholder="Search Products..." id="basic_search_txt" />
              <button onclick="basicSearch(0);"><i class="fa fa-search"></i></button>
              <form action="advancedsearch.php">

                <a href="advancedsearch.php" class="btn_advanced">Advanced</a>

              </form>

              <style>
                .btn_advanced {
                  background: #ae895d;
                  border: none;
                  color: #ffffff;
                  font-size: 16px;
                  height: 35px;
                  padding: 0 10px;
                  position: absolute;
                  right: 0;
                  top: 0;
                  margin-right: -150px;
                  text-align: center;
                  line-height: 35px;
                  /* This centers the text vertically */
                }

                .btn_advanced {
                  background: #906f48;
                }
              </style>

              <p class="hidden-sm hidden-md hidden-xs">
                Top search bundle product. Enter keywords to search: morbi, tablets, computer, furniture...
              </p>


          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="header-bottom bg-1 d-none d-lg-block">
    <div class="container">
      <div class="row gx-0">
        <div class="col-lg-3 col-md-3">
          <div class="position-relative">
            <div class="categories-menu text-uppercase click bg-7">
              <i class="fa fa-list-ul"></i>
              <span>All Categories</span>
            </div>
            <div class="menu-container toggole">
              <ul>


                <?php



                $rs = Database::search("SELECT * FROM `category`");

                $n = $rs->num_rows;

                for ($x = 0; $x < $n; $x++) {
                  $d = $rs->fetch_assoc();

                ?>

                  <li>
                    <a href="#"><i class="fa-solid fa-arrow-right"></i><?php echo $d["cat_name"]; ?></a>
                  </li>

                <?php

                }

                ?>

              </ul>
            </div>
          </div>
        </div>
        <div class="col-lg-9 col-md-9">
          <div class="mainmenu hover-bg dropdown">
            <nav>
              <ul class="menu-list">
                <li> <a href="home.php">Home</a></li>
                
               
                
                <li><a href="update_account.php">My Account</a></li>

                <li><a href="cart.php">Shopping Cart</a></li>
                <li><a href="wishlist.php">Wishlist</a></li>
               
                <li><a href="contact.php">contact us</a></li>
                <li><a href="orderhistory.php">Order History</a></li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>