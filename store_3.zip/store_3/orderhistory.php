<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/icofont.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/nivo-slider.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/percircle.css" />

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>
    <?php
    include "headername.php";
    require "connection.php";
    if (isset($_SESSION["u"])) {
        $mail = $_SESSION["u"]["email"];

        $invoice_rs = Database::search("SELECT * FROM `invoice` WHERE `users_email`='" . $mail . "'");
        $invoice_num = $invoice_rs->num_rows;
    ?>
        <style>
            body {
                background-color: #f8f9fa;
            }

            .table thead th {
                background-color: #343a40;
                color: #fff;
            }

            .table tbody tr:nth-child(even) {
                background-color: #f2f2f2;
            }
        </style>
        <?php
        if ($invoice_num == 0) {

        ?>
            <div class="col-12 text-center bg-body" style="height: 450px;">
                <span class="fs-1 fw-bold text-black-50 d-block" style="margin-top: 200px;">
                    You have not purchased any item yet...
                </span>
            </div>
        <?php

        } else {
        ?>
            <div class="container mt-5">
                <h2 class="mb-4">Order History</h2>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Date</th>
                                <th>Qty</th>
                                <th>Status</th>
                                <th>Total</th>
                                <th>Approved By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php

                            for ($x = 0; $x < $invoice_num; $x++) {
                                $invoice_data = $invoice_rs->fetch_assoc();
                            ?>
                                <tr>
                                    <td><?php echo $invoice_data["id"]; ?></td>
                                    <td><?php echo $invoice_data["date"]; ?></td>
                                    <td><?php echo $invoice_data["qty"]; ?></td>
                                    <td><?php echo $invoice_data["status"]; ?></td>
                                    <td>Rs. <?php echo $invoice_data["total"]; ?> .00</td>
                                    <td><a href="#" class="btn btn-info btn-sm">Admin</a></td>
                                </tr>
                            <?php
                            }

                            ?>

                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>
                </div>
            </div>

    <?php
        }
    }
    ?>

    <br><br>
    <hr><br><br>
    <?php include "footer.php" ?>

    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.mixitup.min.js"></script>
    <script src="assets/js/jquery-ui.min.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/jquery.countdown.min.js"></script>
    <script src="assets/js/jquery.nivo.slider.pack.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="https://kit.fontawesome.com/02566f2f41.js" crossorigin="anonymous"></script>

    <!-- Activation JS -->
    <script src="assets/js/main.js"></script>
    <script src="script.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>