<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product </title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

    <!-- CSS
      ============================================ -->

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/icofont.css" />

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/nivo-slider.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/percircle.css" />

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>
    <?php
    include "headername.php";
    ?>
    <?php
    require "connection.php";
    ?>
    <?php



    if (isset($_SESSION["u"])) {

        $email = $_SESSION["u"]["email"];

        // $details_rs = Database::search("SELECT * FROM `users` INNER JOIN `profile_image` ON
        // users.email=profile_image.users_email INNER JOIN `user_has_address` ON 
        // users.email=user_has_address.users_email INNER JOIN `city` ON 
        // user_has_address.city_id=city.id INNER JOIN `district` ON 
        // city.district_id=district.id INNER JOIN `province` ON 
        // district.province_id=province.id INNER JOIN `gender` ON 
        // gender.id=users.gender_id WHERE `email`='".$email."'");

        $details_rs = Database::search("SELECT * FROM `users` INNER JOIN `gender` ON 
gender.id=users.gender_id WHERE `email`='" . $email . "'");

        $image_rs = Database::search("SELECT * FROM `profile_image` WHERE `users_email`='" . $email . "'");

        $address_rs = Database::search("SELECT * FROM `users_has_address` INNER JOIN `city` ON 
users_has_address.city_city_id=city_city_id INNER JOIN `district` ON 
city.district_district_id=district.district_id INNER JOIN `province` ON 
district.province_province_id=province.province_id WHERE `users_email`='" . $email . "'");

        $details = $details_rs->fetch_assoc();
        $image_details = $image_rs->fetch_assoc();
        $address_details = $address_rs->fetch_assoc();

    ?>

        <br>
        <hr><br>
        <?php

        if (!empty($details["verified_batch"])) {

        ?>
            <div class="container">
                <div class="woocommerce-breadcrumb ">
                    <div class="menu">
                        <ul>
                            <li><a href="home.php">Home</a></li>
                            <li><a href="shop.php">Add Product</a></li>

                        </ul>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6 bg-light">
                        <div class="">
                            <br>
                            <h5 class=" text-primary fw-bold offset-1">Product Details</h5>
                            <hr>
                            <form class="offset-1">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Product Name</label>
                                            <input type="text" class="form-control" id="title" aria-describedby="emailHelp" placeholder="Enter Product Name">
                                            <small id=" emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Poduct Description</label>
                                    <textarea name="#" id="desc" cols="30" rows="10" class="textarea1"></textarea>
                                </div>
                                <div class="col-12">
                                    <select class="form-select text-center" id="category" onchange="loadBrands();">
                                        <option value="0">Select Category</option>
                                        <?php



                                        $category_rs = Database::search("SELECT * FROM `category`");
                                        $category_num = $category_rs->num_rows;

                                        for ($x = 0; $x < $category_num; $x++) {
                                            $category_data = $category_rs->fetch_assoc();

                                        ?>

                                            <option value="<?php echo $category_data["cat_id"]; ?>"><?php echo $category_data["cat_name"]; ?></option>

                                        <?php
                                        }

                                        ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Delivery Cost</label>
                                        </div>
                                        <div class="col-12  border-end border-success">
                                            <div class="row">
                                                <div class="col-12 offset-lg-1 col-lg-3">
                                                    <label class="form-label">Delivery cost Within Colombo</label>
                                                </div>
                                                <div class="col-12 col-lg-8">
                                                    <div class="input-group mb-2 mt-2">
                                                        <span class="input-group-text">Rs.</span>
                                                        <input type="text" class="form-control" id="dwc" />
                                                        <span class="input-group-text">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="col-12 ">
                                            <div class="row">
                                                <div class="col-12 offset-lg-1 col-lg-3">
                                                    <label class="form-label">Delivery cost out of Colombo</label>
                                                </div>
                                                <div class="col-12 col-lg-8">
                                                    <div class="input-group mb-2 mt-2">
                                                        <span class="input-group-text">Rs.</span>
                                                        <input type="text" class="form-control" id="doc" />
                                                        <span class="input-group-text">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <br><br><br>
                            </form>



                        </div>

                    </div>
                    <div class="col-6 bg-light">
                        <div class="">
                            <br>
                            <h5 class="text-uppercase text-primary fw-bold offset-1">Product Images</h5>
                            <hr>

                            <div class="row">

                                <div class="col-4">
                                    <div class="dropzone">
                                        <img src="assets/images/upload.png" class="upload-icon img4" id="product_image_view1"/>
                                        <input type="file" class="upload-input" id="i0"  onclick="addproductphoto();"/>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="dropzone">
                                        <img src="assets/images/upload.png" class="upload-icon img4"  id="product_image_view2"/>
                                        <input type="file" class="upload-input" id="i1" onclick="addproductphoto1();"/>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="dropzone">
                                        <img src="assets/images/upload.png" class="upload-icon img4" id="product_image_view3" />
                                        <input type="file" class="upload-input" id="i2" onclick="addproductphoto2();"/>
                                    </div>
                                </div>
                            </div><br>
                            <hr><br>
                            <div class="row">
                                <div class="col-6">
                                    <h5 class="text-uppercase text-primary fw-bold offset-1">Product colours</h5>
                                    <select class="col-12 form-select" id="clr">
                                        <option value="0">Select Colour</option>
                                        <?php

                                        $clr_rs = Database::search("SELECT * FROM `color`");
                                        $clr_num = $clr_rs->num_rows;

                                        for ($x = 0; $x < $clr_num; $x++) {
                                            $clr_data = $clr_rs->fetch_assoc();
                                        ?>

                                            <option value="<?php echo $clr_data["clr_id"]; ?>"><?php echo $clr_data["clr_name"]; ?></option>

                                        <?php
                                        }

                                        ?>
                                    </select>
                                </div>
                                <div class="col-6">
                                    <h5 class="text-uppercase text-primary fw-bold offset-1">Product Brand</h5>
                                    <select class="form-select text-center" id="brand">
                                        <option value="0">Select Brand</option>
                                        <?php

                                        $brand_rs = Database::search("SELECT * FROM `brand`");
                                        $brand_num = $brand_rs->num_rows;

                                        for ($x = 0; $x < $brand_num; $x++) {
                                            $brand_data = $brand_rs->fetch_assoc();

                                        ?>

                                            <option value="<?php echo $brand_data["brand_id"]; ?>"><?php echo $brand_data["brand_name"]; ?></option>

                                        <?php
                                        }

                                        ?>
                                    </select>
                                </div>
                            </div><br>
                            <hr><br>
                            <div class="row">
                                <div class="col-6">
                                    <h5 class="text-uppercase text-primary fw-bold offset-1">Product Qty</h5>
                                    <input type="number" class="form-control" value="0" min="0" id="qty" />
                                </div>
                                <div class="col-6">
                                    <h5 class="text-uppercase text-primary fw-bold offset-1">Product Model</h5>
                                    <select class="form-select text-center" id="model">
                                        <option value="0">Select Model</option>
                                        <?php

                                        $model_rs = Database::search("SELECT * FROM `model`");
                                        $model_num = $model_rs->num_rows;

                                        for ($x = 0; $x < $model_num; $x++) {
                                            $model_data = $model_rs->fetch_assoc();

                                        ?>

                                            <option value="<?php echo $model_data["model_id"]; ?>"><?php echo $model_data["model_name"]; ?></option>

                                        <?php
                                        }

                                        ?>
                                    </select>
                                </div>
                            </div><br>

                            <div class="col-12">
                                <div class="form-check form-check-inline mx-5">
                                    <input class="form-check-input" type="radio" id="b" name="c" checked />
                                    <label class="form-check-label fw-bold" for="b">Brandnew</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" id="u" name="c" />
                                    <label class="form-check-label fw-bold" for="u">Used</label>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1" class="text-uppercase text-primary fw-bold" style="font-size: 17px;">Price For 1 Product</label>
                                    <input type="text" class="form-control" id="cost" aria-describedby="emailHelp" placeholder="Enter 1 Product Price">
                                </div>
                            </div> <br>

                        </div>

                    </div>
                    <div class="col-12 bg-light">



                        <center><label class="form-label text-danger fw-bold" style="font-size: 19px;">
                                We are taking 5% of the product from price from every
                                product as a service charge.
                            </label></center>
                    </div>
                    <div class="offset-lg-4 col-12 col-lg-4 d-grid mt-3 mb-3 bg-light">
                        <button class="btn btn-success" onclick="addProduct();">Save Product</button>
                    </div>
                </div>
            </div>
        <?php
        } else {
        ?>


            <div class="container">
                <h1 class="text-danger fw-bold">You Are Not A Verfied User</h1>
                <div style="font-size: 15px;">

                    Thank you for visiting our ecommerce website. To ensure a secure and trustworthy shopping experience, we prioritize the verification of our users. As of now, your account is <span class="text-danger fw-bold">not verified.</span>

                    Verification is a crucial step in establishing trust and safety within our platform. Verified users enjoy various benefits, including enhanced security, faster transactions, and personalized recommendations based on their preferences.

                    To complete the verification process and unlock these advantages, please follow the instructions provided in your account or reach out to our support team for assistance.

                    Thank you for your understanding and cooperation.
                </div> <br>
                <hr>
                <h1 class="text-primary fw-bold">How To Become A Verifed User</h1>
                <div style="font-size: 15px;">


                    1. **Log In to Your Account**: Visit the ecommerce website and log in using your registered credentials.

                    2. **Access Your Profile**: Navigate to your account profile by clicking on your profile icon or username, usually located at the top right corner of the webpage.

                    3. **Update Your Profile**: Within your profile, review and update your personal information, including your contact details, address, and any other required fields.

                    4. **Provide Necessary Information**: Fill in any additional information requested for verification purposes, such as identification details or payment information.

                    5. **Verify Your Email Address**: If you haven't already done so, verify your email address by clicking on a verification link sent to your registered email.

                    6. **Verify Your Phone Number**: Complete the phone number verification process, which may involve receiving a verification code via SMS and entering it on the website.

                    7. **Upload Required Documents**: If further verification is needed, upload any necessary documents such as a government-issued ID, utility bills, or credit card statements as specified by the website.

                    8. **Submit Verification Request**: After providing all required information and documents, submit a verification request through the designated process provided on the website.

                    9. **Wait for Approval**: Allow some time for the website administrators to review your provided information and documents. The verification process may take a few hours to a few days.

                    10. **Receive Confirmation**: Once your verification is approved, you'll receive a confirmation email or notification confirming your verified user status.

                    11. **Enjoy Verified User Benefits**: As a verified user, you'll now have access to enhanced security features, smoother transactions, and personalized shopping experiences.

                    12. **Keep Your Information Updated**: Ensure to regularly update your profile and review the provided information to maintain your verified user status and enjoy continued benefits.

                    If any specific steps or requirements are provided by the ecommerce website, be sure to follow those instructions accordingly.
                </div>
            </div>
        <?php  } ?>

    <?php  } ?>

    <?php
    include "footer.php";

    ?>



    <!-- Vendors JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.mixitup.min.js"></script>
    <script src="assets/js/jquery-ui.min.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/jquery.countdown.min.js"></script>
    <script src="assets/js/jquery.nivo.slider.pack.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="https://kit.fontawesome.com/02566f2f41.js" crossorigin="anonymous"></script>
    <!-- Activation JS -->
    <script src="assets/js/main.js"></script>
    <script src="script.js"></script>
</body>