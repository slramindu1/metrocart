<!DOCTYPE html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Contact</title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

  <!-- CSS
		============================================ -->

  <!-- Icon Font CSS -->
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/icofont.css" />

  <!-- Plugins CSS -->
  <link rel="stylesheet" href="assets/css/animate.min.css" />
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/nivo-slider.css" />
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
  <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/magnific-popup.css" />
  <link rel="stylesheet" href="assets/css/percircle.css" />

  <!-- Main Style CSS -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->

  <!-- header start -->
  <?php
  include "header.php";
  ?>
  <!-- header end -->

  <!-- Offcanvas Menu start -->
  <div class="offcanvas offcanvas-start" id="offcanvasMenu">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title">Menu</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <div class="account-menu">
        <ul>
          <li><a href="account.html">My Account</a></li>
          <li>
            <a href="cart.html">compare <span>(0)</span></a>
          </li>
          <li>
            <a href="wishlist.html">Wishlist <span>(0)</span></a>
          </li>
        </ul>
      </div>

      <div class="accordion" id="languageMenu">
        <div class="accordion-item">
          <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
            English
          </button>
          <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
            <ul>
              <li><a href="#">France</a></li>
              <li><a href="#">Germany</a></li>
              <li><a href="#">Japanese</a></li>
            </ul>
          </div>
        </div>

        <div class="accordion-item">
          <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
            USD
          </button>
          <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
            <ul>
              <li><a href="#">EUR - Euro</a></li>
              <li><a href="#">GBP - British Pound</a></li>
              <li><a href="#">INR - Indian Rupee</a></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="mobail-menu">
        <nav class="offcanvas-menu">
          <ul>
            <li class="active">
              <a href="index.html">Home</a>
              <ul class="sub-menu">
                <li><a href="index.html">Home shop 1</a></li>
                <li><a href="index-2.html">Home shop 2</a></li>
                <li><a href="index-3.html">Home shop 3</a></li>
              </ul>
            </li>
            <li>
              <a href="shop.html">Shop</a>
              <ul class="sub-menu">
                <li>
                  <a class="mega-title" href="#">Shop Layout</a>
                  <ul>
                    <li><a href="shop-full-width.html">Full Width</a></li>
                    <li>
                      <a href="shop-sitebar-right.html">Sidebar Right</a>
                    </li>
                    <li><a href="shop-sitebar-left.html">Sidebar Left</a></li>
                    <li><a href="Shop-list-view.html">List View</a></li>
                  </ul>
                </li>
                <li>
                  <a class="mega-title" href="#">Shop Pages</a>
                  <ul class="sub-menu">
                    <li><a href="account.html">My account</a></li>
                    <li><a href="cart.html">Shoping cart</a></li>
                    <li><a href="checkout.html">checkout</a></li>
                    <li><a href="wishlist.html">wishlist</a></li>
                  </ul>
                </li>
                <li>
                  <a class="mega-title" href="#">Product type</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="shop-simple-product.html">simple product</a>
                    </li>
                    <li>
                      <a href="shop-variable-Product.html">Variable Product</a>
                    </li>
                    <li>
                      <a href="shop-grouped-Product.html">Grouped Product</a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              <a href="blog.html">blog</a>
              <ul class="sub-menu">
                <li>
                  <a href="#">Blog Layouts 1</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="blog-left-sitebar-list.html">left sitebar list</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-1.html">left sitebar grid 1</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-2.html">left sitebar grid 2</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-3.html">left sitebar grid 3</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 2</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="blog-right-sitebar-list.html">right sitebar list</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-1.html">right sitebar list 1</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-2.html">right sitebar list 2</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-3.html">right sitebar list 3</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 3</a>
                  <ul class="sub-menu">
                    <li><a href="blog-1-col.html">grid 1 columns</a></li>
                    <li><a href="blog-2-col.html">grid 2 columns</a></li>
                    <li><a href="blog-3-col.html">grid 3 columns</a></li>
                    <li><a href="blog-4-col.html">grid 4 columns</a></li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 4</a>
                  <ul class="sub-menu">
                    <li><a href="blog-details-1.html">format:images</a></li>
                    <li>
                      <a href="blog-details-gallery.html">format:gallery</a>
                    </li>
                    <li>
                      <a href="blog-details-vedio.html">format:video</a>
                    </li>
                    <li><a href="blog-details-2.html">format:audio</a></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              <a href="#">pages</a>
              <ul class="sub-menu">
                <li><a href="about.html">about us</a></li>
                <li><a href="faq.html">F.A.Q.s</a></li>
                <li><a href="404.html">404 pages</a></li>
              </ul>
            </li>
            <li>
              <a href="protfolio.html">Protfolio</a>
              <ul class="sub-menu">
                <li><a href="protfolio-details-1.html">single project</a></li>
                <li><a href="protfolio-2-col.html">two columns</a></li>
                <li><a href="protfolio-3-col.html">three columns</a></li>
                <li><a href="protfolio.html">four columns</a></li>
              </ul>
            </li>
            <li><a href="contact.html">contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <!-- Offcanvas Menu end -->

  <!-- contuct-area start -->
  <div class="main-container">
    <div class="google-map-area mb-50">
      <iframe class="map-size" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3960.9476143423144!2d79.85776061078735!3d6.896869418682665!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae25bd8f6bc0e3f%3A0xebb846a35afbf4f4!2sJava%20Institute%20For%20Advanced%20Technology!5e0!3m2!1sen!2slk!4v1692597770898!5m2!1sen!2slk">
      
      </iframe>
    </div>
    <div class="contuct-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="contuct mb-50 bg-fff box-shadow p-20">
              <div class="contuct-title">
                <h2>Contact Us</h2>
              </div>
              <div class="contuct-form form-style">
                <form action="#">
                  <span>Your Name (required)</span>
                  <input type="text" id="username"/>
                  <span>Your Email (required)</span>
                  <input type="email" id="em"/>
                  <span>Subject</span>
                  <input type="text"  value="Contact On Your Team For Problem" readonly onclick="subject();"/>
                 
                  <span>Your Message</span>
                  <textarea name="#" id="mail" cols="30" rows="10" ></textarea>
                  
                </form>
                <button onclick="contact();">send</button>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="contuct-detail mb-50 p-20 bg-fff box-shadow">
              <div class="contuct-title">
                <h2>Contact detail</h2>
              </div>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Mauris convallis sed neque vitae bibendum. Nunc auctor dictum
                risus, a finibus eros iaculis nec. Sed et euismod felis, non
                euismod est. Maecenas quis nulla ullamcorper, imperdiet lacus
                et, porta sem.
              </p>
              <div class="same">
                <h5>OFFICE ADDRESS</h5>
                <p>Maecenas quis nulla ullamcorper</p>
              </div>
              <div class="same">
                <h5>EMAIL</h5>
                <p>lion-themes@gmail.com</p>
              </div>
              <div class="same">
                <h5>PHONE NUMBER</h5>
                <p>025 1234 5678 - 025 1234 5779</p>
              </div>
              <div class="same">
                <h5>TIME HOURS</h5>
                <p>Monday to Friday: 10am to 7pm</p>
                <p>Saturday: 10am to 4pm</p>
                <p>Sunday: 12am to 4pm</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- contuct-area end -->

  <!-- footer-area start -->
  <footer class="bg-fff bt">
    <div class="footer-top-area bb">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-sm-6">
            <div class="footer-widget">
              <div class="footer-logo mb-25">
                <img src="assets/images/logo/1.png" alt="" />
              </div>
              <div class="footer-content">
                <p>
                  OneClick is a premium Wordpress theme with advanced admin
                  module. It's extremely customizable, easy to use and
                </p>
                <ul>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Facebook"><i class="fa fa-facebook"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Twetter"><i class="fa fa-twitter"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Instagram"><i class="fa fa-instagram"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Google-Plus"><i class="fa fa-google-plus"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Linkedin"><i class="fa fa-linkedin"></i></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6">
            <div class="footer-widget">
              <h3 class="footer-title bb mb-20 pb-15">About Us</h3>
              <ul>
                <li>
                  <div class="contuct-content">
                    <div class="contuct-icon">
                      <i class="fa fa-map-marker"></i>
                    </div>
                    <div class="contuct-info">
                      <span>75, Avenue Anatole France, Paris</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="contuct-content">
                    <div class="contuct-icon">
                      <i class="fa fa-fax"></i>
                    </div>
                    <div class="contuct-info">
                      <span>01.234 56789 - 10.987 65432</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="contuct-content">
                    <div class="contuct-icon">
                      <i class="fa fa-envelope"></i>
                    </div>
                    <div class="contuct-info">
                      <span>hasib.me1995@gmail.com</span>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-sm-4">
            <div class="footer-widget">
              <h3 class="footer-title bb mb-20 pb-15">Information</h3>
              <div class="footer-menu home3-hover">
                <ul>
                  <li><a href="blog.html">Our Blog</a></li>
                  <li><a href="shop.html">About Our Shop</a></li>
                  <li><a href="#">Secure Shopping</a></li>
                  <li><a href="#">Privacy Policy</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-sm-4">
            <div class="footer-widget">
              <h3 class="footer-title bb mb-20 pb-15">My account</h3>
              <div class="footer-menu home3-hover">
                <ul>
                  <li><a href="account.html">My Account</a></li>
                  <li><a href="checkout.html">Checkout</a></li>
                  <li><a href="cart.html">Shopping Cart</a></li>
                  <li><a href="wishlist.html">Wishlist</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-sm-4">
            <div class="footer-widget">
              <h3 class="footer-title bb mb-20 pb-15">Our services</h3>
              <div class="footer-menu">
                <ul>
                  <li><a href="#">Shipping & Returns</a></li>
                  <li><a href="#">Secure Shopping</a></li>
                  <li><a href="#">International Shipping</a></li>
                  <li><a href="#">Affiliates</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom ptb-20">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="copyright">
              <p>
                &copy; 2022 <span> OneClick </span> Made with
                <i class="fa fa-heart"></i> by
                <a href="https://hasthemes.com/">HasThemes</a>
              </p>
            </div>
          </div>
          <div class="col-md-6">
            <div class="mayment text-end">
              <a href="#">
                <img src="assets/images/p14.png" alt="" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- footer-area end -->

  <!-- JS Vendor, Plugins & Activation Script Files -->

  <!-- Vendors JS -->
  <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
  <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

  <!-- Plugins JS -->
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/jquery.mixitup.min.js"></script>
  <script src="assets/js/jquery-ui.min.js"></script>
  <script src="assets/js/jquery.scrollUp.min.js"></script>
  <script src="assets/js/jquery.countdown.min.js"></script>
  <script src="assets/js/jquery.nivo.slider.pack.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/plugins.js"></script>
<script src="script.js"></script>
  <!-- Activation JS -->
  <script src="assets/js/main.js"></script>
</body>

</html>