<?php

include "connection.php";
session_start();

$user =  $_SESSION["user"];
$userId = $user["id"];

$stocklist = [];
$qtyList = [];

$errors = '';


if (isset($_GET["cart"]) && $_GET["cart"] == "true") {

    $rs = Database::search("SELECT * FROM cart WHERE user_id = $userId");
    $num = $rs->num_rows;

    for ($i = 0; $i < $num; $i++) {
        $row = $rs->fetch_assoc();

        $stocklist[] = $row["stock_id"];
        $qtyList[] = $row["qty"];
    }
}

$merchantid = "1227811";
$merchantSecret = "NDEzNTE3NzM4MDEzMjY0NTY3NjczNzkwOTc1MTAzMzc3NzY3MjA3NQ==";
$items = [];
$netTotal = 0;
$currency = "LKR";
$orderid = uniqid();

for ($x = 0; $x < sizeof($stocklist); $x++) {


    $stockRs = Database::search("SELECT * FROM `products` WHERE `qty` = " . $stocklist[$x] . "'");
    $stock = $stockRs->fetch_assoc();

    $stockQty = $stock["qty"];


    if ($stockQty >= $qtyList[$x]) {
        $items[] = $stock["name"];
        $netTotal += $stock["price"] * $qtyList[$x];
    } else {
        $errors =  "Not enough stock";
    }
}
$netTotal += 500;
$hash = strtoupper(
    md5(
        $merchantid .
            $orderid .
            number_format($netTotal, 2, '.', '') .
            $currency .
            strtoupper(md5($merchantSecret))
    )
);



$payment = [];
$payment["sandbox"] = "true";
$payment["merchantid"] = $merchantid;
$payment["returnurl"] = "http://localhost/store_3/home.php";
$payment["cancelurl"] = "http://localhost/store_3/home.php";
$payment["notifyurl"] = "http://localhost/store_3/home.php";
$payment["orderid"] = $orderid;
$payment["items"] = implode(", ", $items);
$payment["amount"] = number_format($netTotal, 2, '.', '');
$payment["currency"] = $currency;
$payment["hash"] = $hash;
$payment["first_name"] = $user["first_name"];
$payment["last_name"] = $user["last_name"];
$payment["email"] = $user["email"];
$payment["phone"] = $user["phone"];
$payment["address"] = $user["address"];
$payment["city"] = $user["city"];
$payment["country"] = $user["country"];
//echo json_encode($payment);

$addressRs = Database::search("SELECT * FROM `user_has_address` WHERE `user_id` = $userId");
$num = $addressRs->num_rows;


if ($num > 0) {
    $address = $addressRs->fetch_assoc();
    $payment["address"] = $address["line_1"] . "" . $address["line_2"];
    $payment["city"] = $address["city"];
    $payment["country"] = "Sri Lanka";


    // echo json_encode($payment);
} else {
    $errors =  "user-profile";
    
}

$json = [];
if(empty($error)){
    $json["status"] = "sucess";
    $json["payment"] = $payment;
}else{
  $json["status"] = "error";
  $json["errors"] = $errors;



  echo json_encode($json);
}