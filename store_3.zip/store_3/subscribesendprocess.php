<?php

require "connection.php";

require "SMTP.php";
require "PHPMailer.php";
require "Exception.php";

use PHPMailer\PHPMailer\PHPMailer;


if (isset($_GET["e"])) {

    $email = $_GET["e"];

    $rs = Database::search("SELECT * FROM `users` WHERE `email`='" . $email . "'");
    $n = $rs->num_rows;

    if ($n == 1) {

        $code = 1;

        Database::iud("UPDATE `users` SET `subscribe`='" . $code . "' WHERE `email`='" . $email . "'");

        $mail = new PHPMailer;
        $mail->IsSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ramindu.jiat@gmail.com';
        $mail->Password = 'qtdlggcsnypmxssd';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('ramindu.jiat@gmail.com', 'Subsribe Newsletter');
        $mail->addReplyTo('ramindu.jiat@gmail.com', 'Subsribe Newsletter');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Gadget Hub Newsletter Subscription';
        $bodyContent = ' <center><img src="https://raw.githubusercontent.com/slramindu1/mysite1/31b095254238b3df569eb36970c325dd7ae1741a/2.png?token=BBPIBBTZ72A6JQDTIHO5ZFDE4LWLQ"/></center>
        Subject: Thank You for Subscribing to Our Newsletter

        Dear [Subscribers Name],
        <br>
        We are thrilled to welcome you to our newsletter community and appreciate your interest in staying informed and connected with us. Thank you for subscribing to [Your Company/Organization]s newsletter.<br>
        <br>
        Our newsletter is designed to keep you updated on the latest industry trends, insightful articles, exciting announcements, and upcoming events. We believe it will provide valuable insights that align with your interests and needs.
        <br>
        By being a part of our newsletter, you will be among the first to know about exclusive offers, insightful blogs, and upcoming events that we believe will enhance your experience with us.
        <br>
        If you have any specific topics or questions you would like us to cover in our newsletters, please feel free to reach out to us. Your input is important to us, and we want to ensure our content is relevant and valuable to you.
        <br>
        Thank you once again for subscribing, and we look forward to building a meaningful and mutually beneficial relationship with you through our newsletter.
        <br>
        Best regards,
        <br>
        Ramindu Ravihansa<br>
        [Subscribe Sneding Manager Team]
           ';


        $mail->Body    = $bodyContent;

        if (!$mail->send()) {
            echo 'Subscribe  sending failed';
        } else {
            echo 'Success';
        }
    } else {
        echo ("Invalid Email Address");
    }
}

