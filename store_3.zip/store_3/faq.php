<!DOCTYPE html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>FAQ</title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

  <!-- CSS
		============================================ -->

  <!-- Icon Font CSS -->
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/icofont.css" />

  <!-- Plugins CSS -->
  <link rel="stylesheet" href="assets/css/animate.min.css" />
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/nivo-slider.css" />
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
  <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/magnific-popup.css" />
  <link rel="stylesheet" href="assets/css/percircle.css" />

  <!-- Main Style CSS -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->

  <!-- header start -->
  <?php

  include "header.php";

  ?>
  <!-- header end -->

  <!-- Offcanvas Menu start -->
  <div class="offcanvas offcanvas-start" id="offcanvasMenu">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title">Menu</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <div class="account-menu">
        <ul>
          <li><a href="account.php">My Account</a></li>
          <li>
            <a href="cart.php">compare <span>(0)</span></a>
          </li>
          <li>
            <a href="wishlist.php">Wishlist <span>(0)</span></a>
          </li>
        </ul>
      </div>

      <div class="accordion" id="languageMenu">
        <div class="accordion-item">
          <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
            English
          </button>
          <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
            <ul>
              <li><a href="#">France</a></li>
              <li><a href="#">Germany</a></li>
              <li><a href="#">Japanese</a></li>
            </ul>
          </div>
        </div>

        <div class="accordion-item">
          <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
            USD
          </button>
          <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
            <ul>
              <li><a href="#">EUR - Euro</a></li>
              <li><a href="#">GBP - British Pound</a></li>
              <li><a href="#">INR - Indian Rupee</a></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="mobail-menu">
        <nav class="offcanvas-menu">
          <ul>
            <li class="active">
              <a href="home.php">Home</a>
              <ul class="sub-menu">
                <li><a href="home.php">Home shop 1</a></li>
                <li><a href="index-2.php">Home shop 2</a></li>
                <li><a href="index-3.php">Home shop 3</a></li>
              </ul>
            </li>
            <li>
              <a href="shop.php">Shop</a>
              <ul class="sub-menu">
                <li>
                  <a class="mega-title" href="#">Shop Layout</a>
                  <ul>
                    <li><a href="shop-full-width.php">Full Width</a></li>
                    <li>
                      <a href="shop-sitebar-right.php">Sidebar Right</a>
                    </li>
                    <li><a href="shop-sitebar-left.php">Sidebar Left</a></li>
                    <li><a href="Shop-list-view.php">List View</a></li>
                  </ul>
                </li>
                <li>
                  <a class="mega-title" href="#">Shop Pages</a>
                  <ul class="sub-menu">
                    <li><a href="account.php">My account</a></li>
                    <li><a href="cart.php">Shoping cart</a></li>
                    <li><a href="checkout.php">checkout</a></li>
                    <li><a href="wishlist.php">wishlist</a></li>
                  </ul>
                </li>
                <li>
                  <a class="mega-title" href="#">Product type</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="shop-simple-product.php">simple product</a>
                    </li>
                    <li>
                      <a href="shop-variable-Product.php">Variable Product</a>
                    </li>
                    <li>
                      <a href="shop-grouped-Product.php">Grouped Product</a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              <a href="blog.php">blog</a>
              <ul class="sub-menu">
                <li>
                  <a href="#">Blog Layouts 1</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="blog-left-sitebar-list.php">left sitebar list</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-1.php">left sitebar grid 1</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-2.php">left sitebar grid 2</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-3.php">left sitebar grid 3</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 2</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="blog-right-sitebar-list.php">right sitebar list</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-1.php">right sitebar list 1</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-2.php">right sitebar list 2</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-3.php">right sitebar list 3</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 3</a>
                  <ul class="sub-menu">
                    <li><a href="blog-1-col.php">grid 1 columns</a></li>
                    <li><a href="blog-2-col.php">grid 2 columns</a></li>
                    <li><a href="blog-3-col.php">grid 3 columns</a></li>
                    <li><a href="blog-4-col.php">grid 4 columns</a></li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 4</a>
                  <ul class="sub-menu">
                    <li><a href="blog-details-1.php">format:images</a></li>
                    <li>
                      <a href="blog-details-gallery.php">format:gallery</a>
                    </li>
                    <li>
                      <a href="blog-details-vedio.php">format:video</a>
                    </li>
                    <li><a href="blog-details-2.php">format:audio</a></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              <a href="#">pages</a>
              <ul class="sub-menu">
                <li><a href="about.php">about us</a></li>
                <li><a href="faq.php">F.A.Q.s</a></li>
                <li><a href="404.php">404 pages</a></li>
              </ul>
            </li>
            <li>
              <a href="protfolio.php">Protfolio</a>
              <ul class="sub-menu">
                <li><a href="protfolio-details-1.php">single project</a></li>
                <li><a href="protfolio-2-col.php">two columns</a></li>
                <li><a href="protfolio-3-col.php">three columns</a></li>
                <li><a href="protfolio.php">four columns</a></li>
              </ul>
            </li>
            <li><a href="contact.php">contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <!-- Offcanvas Menu end -->

  <!-- f-a-q-s-area start -->
  <div class="f-a-q-s-area">
    <div class="container">
      <div class="arequently-title mtb-50 text-center">
        <h1>Frequently Asked Questions</h1>
        <p>
          I am text block. Click edit button to change this text. Lorem ipsum
          dolor sit amet,consectetur adipiscing elit. Ut elit tellus, luctus
          nec ullamcorper mattis, pulvinar dapibus leo.
        </p>
      </div>
      <div class="border mb-30"></div>

      <div class="row">
        <div class="col-md-6">
          <div class="accordion-style mb-35 bg-fff box-shadow">
            <div class="panel-group" id="accordion-faq1">
              <div class="panel panel-default">
                <div class="panel-heading" id="headingOne">
                  <h4 class="panel-title">
                    <a data-bs-toggle="collapse" href="#collapseOne">First question</a>
                  </h4>
                </div>
                <div id="collapseOne" class="panel-collapse collapse show" data-bs-parent="#accordion-faq1">
                  <div class="panel-body">
                    <p>
                      Lorem ipsum dolor sit amet isse potenti. Vesquam ante
                      aliquet lacusemper elit. Cras neque nulla, convallis non
                      commodo et, euismod nonsese. At vero eos et accusamus et
                      iusto odio dignissimos ducimus qui blanditiis
                      praesentium voluptatum deleniti atque corrupti quos
                      dolores et quas molestias excepturi sint occaecati
                      cupiditate non provident, similique sunt in culpa qui
                      officia deserunt mollitia animi, id est laborum et
                      dolorum fuga.
                    </p>
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="headingTwo">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#headingTwo">I have forgotten my password, now what?</a>
                  </h4>
                </div>
                <div id="headingTwo" class="panel-collapse collapse" data-bs-parent="#accordion-faq1">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="headingThree">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapseThree">What methods of payment are accepted?</a>
                  </h4>
                </div>
                <div id="collapseThree" class="panel-collapse collapse" data-bs-parent="#accordion-faq1">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="headingfour">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapsefour">Why don't you ship to my country?</a>
                  </h4>
                </div>
                <div id="collapsefour" class="panel-collapse collapse" data-bs-parent="#accordion-faq1">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="headingfive">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapsefive">How long will it take for my items to arrive?</a>
                  </h4>
                </div>
                <div id="collapsefive" class="panel-collapse collapse" data-bs-parent="#accordion-faq1">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="headingsix">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapsesix">I have forgotten my password, now what?</a>
                  </h4>
                </div>
                <div id="collapsesix" class="panel-collapse collapse" data-bs-parent="#accordion-faq1">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="accordion-style accordion-style-2 mb-35 bg-fff box-shadow">
            <div class="panel-group" id="accordion-faq2">
              <div class="panel panel-default">
                <div class="panel-heading" id="heading7">
                  <h4 class="panel-title">
                    <a data-bs-toggle="collapse" href="#collapse7">First question</a>
                  </h4>
                </div>
                <div id="collapse7" class="panel-collapse collapse show" data-bs-parent="#accordion-faq2" role="tabpanel" aria-labelledby="heading7">
                  <div class="panel-body">
                    <p>
                      Lorem ipsum dolor sit amet isse potenti. Vesquam ante
                      aliquet lacusemper elit. Cras neque nulla, convallis non
                      commodo et, euismod nonsese. At vero eos et accusamus et
                      iusto odio dignissimos ducimus qui blanditiis
                      praesentium voluptatum deleniti atque corrupti quos
                      dolores et quas molestias excepturi sint occaecati
                      cupiditate non provident, similique sunt in culpa qui
                      officia deserunt mollitia animi, id est laborum et
                      dolorum fuga.
                    </p>
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="heading8">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapse8">I have forgotten my password, now what?</a>
                  </h4>
                </div>
                <div id="collapse8" class="panel-collapse collapse" data-bs-parent="#accordion-faq2" role="tabpanel" aria-labelledby="heading8">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="heading9">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapse9">What methods of payment are accepted?</a>
                  </h4>
                </div>
                <div id="collapse9" class="panel-collapse collapse" data-bs-parent="#accordion-faq2" role="tabpanel" aria-labelledby="heading9">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="heading10">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapse10">Why don't you ship to my country?</a>
                  </h4>
                </div>
                <div id="collapse10" class="panel-collapse collapse" data-bs-parent="#accordion-faq2" role="tabpanel" aria-labelledby="heading10">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="heading11">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapse11">How long will it take for my items to arrive?</a>
                  </h4>
                </div>
                <div id="collapse11" class="panel-collapse collapse" data-bs-parent="#accordion-faq2" role="tabpanel" aria-labelledby="heading11">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading" id="heading12">
                  <h4 class="panel-title">
                    <a class="collapsed" data-bs-toggle="collapse" href="#collapse12">I have forgotten my password, now what?</a>
                  </h4>
                </div>
                <div id="collapse12" class="panel-collapse collapse" data-bs-parent="#accordion-faq2" role="tabpanel" aria-labelledby="heading12">
                  <div class="panel-body">
                    <p>
                      Cras neque nulla, convallis non commodo et, euismod
                      nonsese. At vero eos et accusamus et iusto odio
                      dignissimos ducimus qui blanditiis praesentium
                      voluptatum deleniti atque corrupti
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- f-a-q-s-area end -->

  <!-- brand-area start -->
  <div class="brand-area mb-35">
    <div class="container">
      <div class="brand-active box-shadow p-15 bg-fff">
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/1.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/2.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/3.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/1.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/4.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/5.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/6.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/7.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/8.jpg" alt="" />
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- brand-area end -->

  <!-- footer-area start -->
  <footer class="bg-fff bt">
    <div class="footer-top-area bb">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-sm-6">
            <div class="footer-widget">
              <div class="footer-logo mb-25">
                <img src="assets/images/logo/1.png" alt="" />
              </div>
              <div class="footer-content">
                <p>
                  OneClick is a premium Wordpress theme with advanced admin
                  module. It's extremely customizable, easy to use and
                </p>
                <ul>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Facebook"><i class="fa fa-facebook"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Twetter"><i class="fa fa-twitter"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Instagram"><i class="fa fa-instagram"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Google-Plus"><i class="fa fa-google-plus"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Linkedin"><i class="fa fa-linkedin"></i></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6">
            <div class="footer-widget">
              <h3 class="footer-title bb mb-20 pb-15">About Us</h3>
              <ul>
                <li>
                  <div class="contuct-content">
                    <div class="contuct-icon">
                      <i class="fa fa-map-marker"></i>
                    </div>
                    <div class="contuct-info">
                      <span>75, Avenue Anatole France, Paris</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="contuct-content">
                    <div class="contuct-icon">
                      <i class="fa fa-fax"></i>
                    </div>
                    <div class="contuct-info">
                      <span>01.234 56789 - 10.987 65432</span>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="contuct-content">
                    <div class="contuct-icon">
                      <i class="fa fa-envelope"></i>
                    </div>
                    <div class="contuct-info">
                      <span>hasib.me1995@gmail.com</span>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-sm-4">
            <div class="footer-widget">
              <h3 class="footer-title bb mb-20 pb-15">Information</h3>
              <div class="footer-menu home3-hover">
                <ul>
                  <li><a href="blog.php">Our Blog</a></li>
                  <li><a href="shop.php">About Our Shop</a></li>
                  <li><a href="#">Secure Shopping</a></li>
                  <li><a href="#">Privacy Policy</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-sm-4">
            <div class="footer-widget">
              <h3 class="footer-title bb mb-20 pb-15">My account</h3>
              <div class="footer-menu home3-hover">
                <ul>
                  <li><a href="account.php">My Account</a></li>
                  <li><a href="checkout.php">Checkout</a></li>
                  <li><a href="cart.php">Shopping Cart</a></li>
                  <li><a href="wishlist.php">Wishlist</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-sm-4">
            <div class="footer-widget">
              <h3 class="footer-title bb mb-20 pb-15">Our services</h3>
              <div class="footer-menu">
                <ul>
                  <li><a href="#">Shipping & Returns</a></li>
                  <li><a href="#">Secure Shopping</a></li>
                  <li><a href="#">International Shipping</a></li>
                  <li><a href="#">Affiliates</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom ptb-20">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="copyright">
              <p>
                &copy; 2022 <span> OneClick </span> Made with
                <i class="fa fa-heart"></i> by
                <a href="https://hasthemes.com/">HasThemes</a>
              </p>
            </div>
          </div>
          <div class="col-md-6">
            <div class="mayment text-end">
              <a href="#">
                <img src="assets/images/p14.png" alt="" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- footer-area end -->

  <!-- JS Vendor, Plugins & Activation Script Files -->

  <!-- Vendors JS -->
  <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
  <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

  <!-- Plugins JS -->
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/jquery.mixitup.min.js"></script>
  <script src="assets/js/jquery-ui.min.js"></script>
  <script src="assets/js/jquery.scrollUp.min.js"></script>
  <script src="assets/js/jquery.countdown.min.js"></script>
  <script src="assets/js/jquery.nivo.slider.pack.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/plugins.js"></script>

  <!-- Activation JS -->
  <script src="assets/js/main.js"></script>
</body>

</html>