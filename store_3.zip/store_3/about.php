<!DOCTYPE html>
<html class="no-js" lang="">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>About</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Favicon -->
    <link
      rel="shortcut icon"
      type="image/x-icon"
      href="assets/images/favicon.png"
    />

    <!-- CSS
		============================================ -->

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/icofont.css" />

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/nivo-slider.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/percircle.css" />

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
  </head>
  <body>
    <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->

    <!-- header start -->
    <header>
      <div class="header-top-area bb d-none d-lg-block">
        <div class="container">
          <div class="row">
            <div class="col-lg-4">
              <div class="language-menu dropdown">
                <ul>
                  <li>
                    <a href="#">eng <i class="fa fa-angle-down"></i></a>
                    <ul>
                      <li><a href="#">France</a></li>
                      <li><a href="#">Germany</a></li>
                      <li><a href="#">Japanese</a></li>
                    </ul>
                  </li>
                  <li>
                    <a href="#">usd <i class="fa fa-angle-down"></i></a>
                    <ul>
                      <li><a href="#">EUR - Euro</a></li>
                      <li><a href="#">GBP - British Pound</a></li>
                      <li><a href="#">INR - Indian Rupee</a></li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-4">
              <p class="h2-color text-center">Wellcome to Oneclick store!</p>
            </div>
            <div class="col-lg-4">
              <div class="header-top-right">
                <div class="account-menu">
                  <ul>
                    <li><a href="account.php">My Account</a></li>
                    <li><a href="checkout.php">Checkout</a></li>
                    <li><a href="cart.php">Shopping Cart</a></li>
                    <li><a href="wishlist.php">Wishlist</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="header-middle-area">
        <div class="container">
          <div class="row align-items-center align-items-lg-start">
            <div class="col-lg-3 col-5 order-lg-1">
              <div class="logo">
                <a href="home.php">
                  <img src="assets/images/logo/1.png" alt="" />
                </a>
              </div>
            </div>

            <div class="col-xl-2 col-lg-3 col-7 order-lg-3">
              <div class="header-actions">
                <div class="top-cart bg-5">
                  <div class="cart">
                    <i class="icofont icofont-bag"></i>
                    <a href="#">
                      3 Items - <strong>$500.00 </strong>
                      <i class="icofont icofont-rounded-down"></i>
                    </a>
                  </div>
                  <ul>
                    <li>
                      <div class="cart-items">
                        <div class="cart-item bb mt-10">
                          <div class="cart-img">
                            <a href="#">
                              <img src="assets/images/cart/1.jpg" alt="" />
                            </a>
                          </div>
                          <div class="cart-content">
                            <a href="#">Lorem nec augue</a>
                            <a href="#" class="pull-right cart-remove">
                              <i class="fa fa-times"></i
                            ></a>
                            <span>1 x $220.00</span>
                          </div>
                        </div>
                        <div class="cart-item bb mt-10">
                          <div class="cart-img">
                            <a href="#">
                              <img src="assets/images/cart/2.jpg" alt="" />
                            </a>
                          </div>
                          <div class="cart-content">
                            <a href="#">Lorem nec augue</a>
                            <a href="#" class="pull-right cart-remove">
                              <i class="fa fa-times"></i
                            ></a>
                            <span>1 x $220.00</span>
                          </div>
                        </div>
                        <div class="cart-item bb mt-10">
                          <div class="cart-img">
                            <a href="#">
                              <img src="assets/images/cart/3.jpg" alt="" />
                            </a>
                          </div>
                          <div class="cart-content">
                            <a href="#">Lorem nec augue</a>
                            <a href="#" class="pull-right cart-remove">
                              <i class="fa fa-times"></i
                            ></a>
                            <span>1 x $220.00</span>
                          </div>
                        </div>
                        <div class="total mt-10">
                          <span class="pull-left">Subtotal:</span>
                          <span class="pull-right">$200.00</span>
                        </div>
                        <div class="cart-btn mb-20">
                          <a href="#">view cart</a>
                          <a href="#">Checkout</a>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>

                <button
                  class="action-toggle d-lg-none"
                  data-bs-toggle="offcanvas"
                  data-bs-target="#offcanvasMenu"
                >
                  <span></span>
                  <span></span>
                  <span></span>
                </button>
              </div>
            </div>

            <div class="col-xl-7 col-lg-6 order-lg-2">
              <div class="search-box">
                <form action="#">
                  <select name="#" id="select">
                    <option value="">All categories</option>
                    <option value="40">Accessories</option>
                    <option value="41">Clothing</option>
                    <option value="42">-Hoodies</option>
                    <option value="47">-T-shirts</option>
                    <option value="43">Men's</option>
                    <option value="50">-Hats</option>
                    <option value="44">Music</option>
                    <option value="46">-Singles</option>
                    <option value="49">-Albums</option>
                    <option value="45">Posters</option>
                    <option value="48" min="1">Women's</option>
                    <option value="51">-Hats</option>
                  </select>
                  <input type="text" placeholder="Search Products..." />
                  <button><i class="fa fa-search"></i></button>
                </form>
                <p class="hidden-sm hidden-md hidden-xs">
                  top search bundle product, Enter keywords to search, morbi,
                  Tablets, computer,funiture...
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="header-bottom bg-1 d-none d-lg-block">
        <div class="container">
          <div class="row gx-0">
            <div class="col-lg-3 col-md-3">
              <div class="position-relative">
                <div class="categories-menu text-uppercase click bg-7">
                  <i class="fa fa-list-ul"></i>
                  <span>All Categories</span>
                </div>
                <div class="menu-container toggole">
                  <ul>
                    <li>
                      <a href="#"
                        ><i class="fa fa-laptop"></i> Electronics
                        <i class="fa fa-angle-right pull-right"></i
                      ></a>
                      <ul class="megamenu-2 box-shadow">
                        <li>
                          <a class="mega-title bb" href="shop-style-1.php"
                            >Men's</a
                          >
                          <a href="shop-style-1.php">hats</a>
                          <a href="shop-style-1.php">music</a>
                          <a href="shop-style-1.php">singles</a>
                        </li>
                        <li>
                          <a class="mega-title bb" href="#"
                            >Sports & Outdoors</a
                          >
                          <a href="shop-style-1.php">Smartphone</a>
                          <a href="shop-style-1.php">women's</a>
                          <a href="shop-style-1.php">Health & Beauty</a>
                        </li>
                        <li>
                          <a class="mega-title bb" href="#">Accessories</a>
                          <a href="#">Hobbies</a>
                          <a href="#">Networking</a>
                          <a href="#">Accessories</a>
                          <a href="#">Clothing</a>
                        </li>
                        <li>
                          <a class="mega-title bb" href="#"
                            >Laptops & Accessories</a
                          >
                          <a href="#">Hobbies</a>
                          <a href="#">Clothing</a>
                          <a href="#">Flashlights</a>
                          <a href="shop-style-1.php">music</a>
                        </li>
                      </ul>
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-mobile"></i> Smartphone & Tablets</a
                      >
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-medkit"></i> Health & Beauty</a
                      >
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-futbol-o"></i> Sports & Outdoors</a
                      >
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-compass"></i> Bags, Shoes &
                        Accessories</a
                      >
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-shopping-bag"></i> Toys & Hobbies</a
                      >
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-desktop"></i> Computers & Networking</a
                      >
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-laptop"></i> Laptops & Accessories</a
                      >
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-clock-o"></i> Jewelry & Watches</a
                      >
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-chrome"></i> Flashlights & Lamps</a
                      >
                    </li>
                    <li>
                      <a href="#"><i class="fa fa-star"></i> Headlight</a>
                    </li>
                    <li>
                      <a href="#"
                        ><i class="fa fa-plus-square-o"></i> More Categories</a
                      >
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-9 col-md-9">
              <div class="mainmenu hover-bg dropdown">
                <nav>
                  <ul class="menu-list">
                    <li class="active">
                      <a href="home.php"
                        >Home <i class="fa fa-caret-down"></i
                      ></a>
                      <ul>
                        <li><a href="home.php">Home shop 1</a></li>
                        <li><a href="index-2.php">Home shop 2</a></li>
                        <li><a href="index-3.php">Home shop 3</a></li>
                      </ul>
                    </li>
                    <li>
                      <a href="shop.php"
                        >Shop <i class="fa fa-caret-down"></i
                      ></a>
                      <div class="megamenu">
                        <span>
                          <a class="mega-title" href="#">Shop Layout</a>
                          <a href="shop-full-width.php">Full Width</a>
                          <a href="shop-sitebar-right.php">Sidebar Right</a>
                          <a href="shop-sitebar-left.php">Sidebar Left</a>
                          <a href="Shop-list-view.php">List View</a>
                        </span>
                        <span>
                          <a class="mega-title" href="#">Shop Pages</a>
                          <a href="account.php">My account</a>
                          <a href="cart.php">Shoping cart</a>
                          <a href="checkout.php">checkout</a>
                          <a href="wishlist.php">wishlist</a>
                        </span>
                        <span>
                          <a class="mega-title" href="#">Product type</a>
                          <a href="shop-simple-product.php">simple product</a>
                          <a href="shop-variable-Product.php"
                            >Variable Product</a
                          >
                          <a href="shop-grouped-Product.php"
                            >Grouped Product</a
                          >
                        </span>
                      </div>
                    </li>
                    <li>
                      <a href="blog.php"
                        >blog <i class="fa fa-caret-down"></i
                      ></a>
                      <ul>
                        <li>
                          <a href="#"
                            >Blog Layouts 1 <i class="fa fa-angle-right"></i
                          ></a>
                          <ul>
                            <li>
                              <a href="blog-left-sitebar-list.php"
                                >left sitebar list</a
                              >
                            </li>
                            <li>
                              <a href="blog-left-sitebar-1.php"
                                >left sitebar grid 1</a
                              >
                            </li>
                            <li>
                              <a href="blog-left-sitebar-2.php"
                                >left sitebar grid 2</a
                              >
                            </li>
                            <li>
                              <a href="blog-left-sitebar-3.php"
                                >left sitebar grid 3</a
                              >
                            </li>
                          </ul>
                        </li>
                        <li>
                          <a href="#"
                            >Blog Layouts 2 <i class="fa fa-angle-right"></i
                          ></a>
                          <ul>
                            <li>
                              <a href="blog-right-sitebar-list.php"
                                >right sitebar list</a
                              >
                            </li>
                            <li>
                              <a href="blog-right-sitebar-list-1.php"
                                >right sitebar list 1</a
                              >
                            </li>
                            <li>
                              <a href="blog-right-sitebar-list-2.php"
                                >right sitebar list 2</a
                              >
                            </li>
                            <li>
                              <a href="blog-right-sitebar-list-3.php"
                                >right sitebar list 3</a
                              >
                            </li>
                          </ul>
                        </li>
                        <li>
                          <a href="#"
                            >Blog Layouts 3 <i class="fa fa-angle-right"></i
                          ></a>
                          <ul>
                            <li>
                              <a href="blog-1-col.php">grid 1 columns</a>
                            </li>
                            <li>
                              <a href="blog-2-col.php">grid 2 columns</a>
                            </li>
                            <li>
                              <a href="blog-3-col.php">grid 3 columns</a>
                            </li>
                            <li>
                              <a href="blog-4-col.php">grid 4 columns</a>
                            </li>
                          </ul>
                        </li>
                        <li>
                          <a href="#"
                            >Blog Layouts 4 <i class="fa fa-angle-right"></i
                          ></a>
                          <ul>
                            <li>
                              <a href="blog-details-1.php">format:images</a>
                            </li>
                            <li>
                              <a href="blog-details-gallery.php"
                                >format:gallery</a
                              >
                            </li>
                            <li>
                              <a href="blog-details-vedio.php">format:video</a>
                            </li>
                            <li>
                              <a href="blog-details-2.php">format:audio</a>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </li>
                    <li>
                      <a href="#">pages <i class="fa fa-caret-down"></i></a>
                      <ul>
                        <li><a href="about.php">about us</a></li>
                        <li><a href="faq.php">F.A.Q.s</a></li>
                        <li><a href="404.php">404 pages</a></li>
                      </ul>
                    </li>
                    <li>
                      <a href="protfolio.php"
                        >Protfolio <i class="fa fa-caret-down"></i
                      ></a>
                      <ul>
                        <li>
                          <a href="protfolio-details-1.php">single project</a>
                        </li>
                        <li><a href="protfolio-2-col.php">two columns</a></li>
                        <li>
                          <a href="protfolio-3-col.php">three columns</a>
                        </li>
                        <li><a href="protfolio.php">four columns</a></li>
                      </ul>
                    </li>
                    <li><a href="contact.php">contact us</a></li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- header end -->

    <!-- Offcanvas Menu start -->
    <div class="offcanvas offcanvas-start" id="offcanvasMenu">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title">Menu</h5>
        <button
          type="button"
          class="btn-close text-reset"
          data-bs-dismiss="offcanvas"
          aria-label="Close"
        ></button>
      </div>
      <div class="offcanvas-body">
        <div class="account-menu">
          <ul>
            <li><a href="account.php">My Account</a></li>
            <li>
              <a href="cart.php">compare <span>(0)</span></a>
            </li>
            <li>
              <a href="wishlist.php">Wishlist <span>(0)</span></a>
            </li>
          </ul>
        </div>

        <div class="accordion" id="languageMenu">
          <div class="accordion-item">
            <button
              class="accordion-button"
              data-bs-toggle="collapse"
              data-bs-target="#collapseOne"
            >
              English
            </button>
            <div
              id="collapseOne"
              class="accordion-collapse collapse"
              data-bs-parent="#languageMenu"
            >
              <ul>
                <li><a href="#">France</a></li>
                <li><a href="#">Germany</a></li>
                <li><a href="#">Japanese</a></li>
              </ul>
            </div>
          </div>

          <div class="accordion-item">
            <button
              class="accordion-button collapsed"
              data-bs-toggle="collapse"
              data-bs-target="#collapseTwo"
            >
              USD
            </button>
            <div
              id="collapseTwo"
              class="accordion-collapse collapse"
              data-bs-parent="#languageMenu"
            >
              <ul>
                <li><a href="#">EUR - Euro</a></li>
                <li><a href="#">GBP - British Pound</a></li>
                <li><a href="#">INR - Indian Rupee</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div class="mobail-menu">
          <nav class="offcanvas-menu">
            <ul>
              <li class="active">
                <a href="home.php">Home</a>
                <ul class="sub-menu">
                  <li><a href="home.php">Home shop 1</a></li>
                  <li><a href="index-2.php">Home shop 2</a></li>
                  <li><a href="index-3.php">Home shop 3</a></li>
                </ul>
              </li>
              <li>
                <a href="shop.php">Shop</a>
                <ul class="sub-menu">
                  <li>
                    <a class="mega-title" href="#">Shop Layout</a>
                    <ul>
                      <li><a href="shop-full-width.php">Full Width</a></li>
                      <li>
                        <a href="shop-sitebar-right.php">Sidebar Right</a>
                      </li>
                      <li><a href="shop-sitebar-left.php">Sidebar Left</a></li>
                      <li><a href="Shop-list-view.php">List View</a></li>
                    </ul>
                  </li>
                  <li>
                    <a class="mega-title" href="#">Shop Pages</a>
                    <ul class="sub-menu">
                      <li><a href="account.php">My account</a></li>
                      <li><a href="cart.php">Shoping cart</a></li>
                      <li><a href="checkout.php">checkout</a></li>
                      <li><a href="wishlist.php">wishlist</a></li>
                    </ul>
                  </li>
                  <li>
                    <a class="mega-title" href="#">Product type</a>
                    <ul class="sub-menu">
                      <li>
                        <a href="shop-simple-product.php">simple product</a>
                      </li>
                      <li>
                        <a href="shop-variable-Product.php"
                          >Variable Product</a
                        >
                      </li>
                      <li>
                        <a href="shop-grouped-Product.php">Grouped Product</a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li>
                <a href="blog.php">blog</a>
                <ul class="sub-menu">
                  <li>
                    <a href="#">Blog Layouts 1</a>
                    <ul class="sub-menu">
                      <li>
                        <a href="blog-left-sitebar-list.php"
                          >left sitebar list</a
                        >
                      </li>
                      <li>
                        <a href="blog-left-sitebar-1.php"
                          >left sitebar grid 1</a
                        >
                      </li>
                      <li>
                        <a href="blog-left-sitebar-2.php"
                          >left sitebar grid 2</a
                        >
                      </li>
                      <li>
                        <a href="blog-left-sitebar-3.php"
                          >left sitebar grid 3</a
                        >
                      </li>
                    </ul>
                  </li>
                  <li>
                    <a href="#">Blog Layouts 2</a>
                    <ul class="sub-menu">
                      <li>
                        <a href="blog-right-sitebar-list.php"
                          >right sitebar list</a
                        >
                      </li>
                      <li>
                        <a href="blog-right-sitebar-list-1.php"
                          >right sitebar list 1</a
                        >
                      </li>
                      <li>
                        <a href="blog-right-sitebar-list-2.php"
                          >right sitebar list 2</a
                        >
                      </li>
                      <li>
                        <a href="blog-right-sitebar-list-3.php"
                          >right sitebar list 3</a
                        >
                      </li>
                    </ul>
                  </li>
                  <li>
                    <a href="#">Blog Layouts 3</a>
                    <ul class="sub-menu">
                      <li><a href="blog-1-col.php">grid 1 columns</a></li>
                      <li><a href="blog-2-col.php">grid 2 columns</a></li>
                      <li><a href="blog-3-col.php">grid 3 columns</a></li>
                      <li><a href="blog-4-col.php">grid 4 columns</a></li>
                    </ul>
                  </li>
                  <li>
                    <a href="#">Blog Layouts 4</a>
                    <ul class="sub-menu">
                      <li><a href="blog-details-1.php">format:images</a></li>
                      <li>
                        <a href="blog-details-gallery.php">format:gallery</a>
                      </li>
                      <li>
                        <a href="blog-details-vedio.php">format:video</a>
                      </li>
                      <li><a href="blog-details-2.php">format:audio</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li>
                <a href="#">pages</a>
                <ul class="sub-menu">
                  <li><a href="about.php">about us</a></li>
                  <li><a href="faq.php">F.A.Q.s</a></li>
                  <li><a href="404.php">404 pages</a></li>
                </ul>
              </li>
              <li>
                <a href="protfolio.php">Protfolio</a>
                <ul class="sub-menu">
                  <li><a href="protfolio-details-1.php">single project</a></li>
                  <li><a href="protfolio-2-col.php">two columns</a></li>
                  <li><a href="protfolio-3-col.php">three columns</a></li>
                  <li><a href="protfolio.php">four columns</a></li>
                </ul>
              </li>
              <li><a href="contact.php">contact us</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
    <!-- Offcanvas Menu end -->

    <!-- about-area start -->
    <div class="about-main-area shop-bg">
      <div class="about-title-area ptb-50 bg-img mb-50">
        <div class="container">
          <div class="about-heading">
            <h1>About us</h1>
          </div>
        </div>
      </div>
      <div class="about-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-6">
              <div class="about-content mb-30">
                <div class="about-title mb-40">
                  <h2>Welcome to oneclick</h2>
                </div>
                <p>
                  Donec pede justo, fringilla vel, aliquet nec, vulputate eget,
                  arcu.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                  Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                  natoque penatibus et magnis dis parturient montes, nascetur
                  ridiculus mus. Donec quam felis, ultricies nec, pellentesque
                  eu, pretium quis, sem. Nulla consequat massa quis enim. Donec
                  pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.
                </p>
                <p>
                  Donec pede justo, fringilla vel, aliquet nec, vulputate eget,
                  arcu.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                  Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                  natoque penatibus et magnis dis parturient montes, nascetur
                  ridiculus mus. Donec quam felis, ultricies nec, pellentesque
                  eu, pretium quis, sem. Nulla consequat massa quis enim. Donec
                  pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.
                </p>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="about-img mb-30">
                <div class="about-img-3D">
                  <img src="assets/images/about/1.jpg" alt="" />
                </div>
              </div>
            </div>
          </div>

          <!-- team-area -->
          <div class="team-area mt-50">
            <div class="team-title mb-40">
              <h2>Meet Our Team</h2>
            </div>

            <div class="row">
              <div class="col-lg-4 col-md-6">
                <div class="team-wrapper bg-fff mb-50">
                  <div class="team-img about-img">
                    <img src="assets/images/team/2.jpg" alt="" />
                  </div>
                  <div class="team-info p-20">
                    <h3>Nick Monroe</h3>
                    <span>Human Resources</span>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                <div class="team-wrapper bg-fff mb-50">
                  <div class="team-img about-img">
                    <img src="assets/images/team/3.jpg" alt="" />
                  </div>
                  <div class="team-info p-20">
                    <h3>Diana Grey</h3>
                    <span>Human Resources</span>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                <div class="team-wrapper bg-fff mb-50">
                  <div class="team-img about-img">
                    <img src="assets/images/team/4.jpg" alt="" />
                  </div>
                  <div class="team-info p-20">
                    <h3>Anthony Scott</h3>
                    <span>Human Resources</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="skill-area mb-50">
        <div class="container">
          <div class="row">
            <div class="col-lg-6">
              <div class="skill-wrapper">
                <div class="skill-title mb-30">
                  <h2>Our Skills</h2>
                </div>
                <h5>
                  <em
                    >Ut enim ad minim veniam, quis nostrud exerctation ullamco
                    .</em
                  >
                </h5>
                <p>
                  Donec pede justo, fringilla vel, aliquet nec, vulputate eget,
                  arcu.Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                  Aenean commodo ligula eget dolor. Aenean massa. Cum sociis
                  natoque penatibus et magnis dis parturient montes, nascetur
                  ridiculus mus. Donec quam felis, ultricies nec, pellentesque
                  eu, pretium quis, sem. Nulla consequat massa quis enim. Donec
                  pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.
                </p>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="skill-wrapper">
                <div class="progress">
                  <div
                    class="progress-bar wow fadeInLeftBig progress-bar-1"
                    role="progressbar"
                  >
                    <span class="progress-bar-text">Development 90%</span>
                  </div>
                </div>
                <div class="progress">
                  <div
                    class="progress-bar wow fadeInLeftBig progress-bar-2"
                    role="progressbar"
                  >
                    <span class="progress-bar-text">Design 80%</span>
                  </div>
                </div>
                <div class="progress">
                  <div
                    class="progress-bar wow fadeInLeftBig progress-bar-3"
                    role="progressbar"
                  >
                    <span class="progress-bar-text">HTML5 & CSS3 75%</span>
                  </div>
                </div>
                <div class="progress">
                  <div
                    class="progress-bar wow fadeInLeftBig progress-bar-4"
                    role="progressbar"
                  >
                    <span class="progress-bar-text">Marketing 70%</span>
                  </div>
                </div>
                <div class="progress">
                  <div
                    class="progress-bar wow fadeInLeftBig progress-bar-5"
                    role="progressbar"
                  >
                    <span class="progress-bar-text">WORDPRESS 90%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- brand-area start -->
      <div class="brand-area mb-35">
        <div class="container">
          <div class="brand-active box-shadow p-15 bg-fff">
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/1.jpg" alt="" />
              </a>
            </div>
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/2.jpg" alt="" />
              </a>
            </div>
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/3.jpg" alt="" />
              </a>
            </div>
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/1.jpg" alt="" />
              </a>
            </div>
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/4.jpg" alt="" />
              </a>
            </div>
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/5.jpg" alt="" />
              </a>
            </div>
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/6.jpg" alt="" />
              </a>
            </div>
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/7.jpg" alt="" />
              </a>
            </div>
            <div class="single-brand">
              <a href="#">
                <img src="assets/images/brand/8.jpg" alt="" />
              </a>
            </div>
          </div>
        </div>
      </div>
      <!-- brand-area end -->
    </div>
    <!-- about-area end -->

    <!-- footer-area start -->
    <footer class="bg-fff bt">
      <div class="footer-top-area bb">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-sm-6">
              <div class="footer-widget">
                <div class="footer-logo mb-25">
                  <img src="assets/images/logo/1.png" alt="" />
                </div>
                <div class="footer-content">
                  <p>
                    OneClick is a premium Wordpress theme with advanced admin
                    module. It's extremely customizable, easy to use and
                  </p>
                  <ul>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Facebook"
                        ><i class="fa fa-facebook"></i
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Twetter"
                        ><i class="fa fa-twitter"></i
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Instagram"
                        ><i class="fa fa-instagram"></i
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Google-Plus"
                        ><i class="fa fa-google-plus"></i
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Linkedin"
                        ><i class="fa fa-linkedin"></i
                      ></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6">
              <div class="footer-widget">
                <h3 class="footer-title bb mb-20 pb-15">About Us</h3>
                <ul>
                  <li>
                    <div class="contuct-content">
                      <div class="contuct-icon">
                        <i class="fa fa-map-marker"></i>
                      </div>
                      <div class="contuct-info">
                        <span>75, Avenue Anatole France, Paris</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="contuct-content">
                      <div class="contuct-icon">
                        <i class="fa fa-fax"></i>
                      </div>
                      <div class="contuct-info">
                        <span>01.234 56789 - 10.987 65432</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="contuct-content">
                      <div class="contuct-icon">
                        <i class="fa fa-envelope"></i>
                      </div>
                      <div class="contuct-info">
                        <span>hasib.me1995@gmail.com</span>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-2 col-sm-4">
              <div class="footer-widget">
                <h3 class="footer-title bb mb-20 pb-15">Information</h3>
                <div class="footer-menu home3-hover">
                  <ul>
                    <li><a href="blog.php">Our Blog</a></li>
                    <li><a href="shop.php">About Our Shop</a></li>
                    <li><a href="#">Secure Shopping</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-sm-4">
              <div class="footer-widget">
                <h3 class="footer-title bb mb-20 pb-15">My account</h3>
                <div class="footer-menu home3-hover">
                  <ul>
                    <li><a href="account.php">My Account</a></li>
                    <li><a href="checkout.php">Checkout</a></li>
                    <li><a href="cart.php">Shopping Cart</a></li>
                    <li><a href="wishlist.php">Wishlist</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-sm-4">
              <div class="footer-widget">
                <h3 class="footer-title bb mb-20 pb-15">Our services</h3>
                <div class="footer-menu">
                  <ul>
                    <li><a href="#">Shipping & Returns</a></li>
                    <li><a href="#">Secure Shopping</a></li>
                    <li><a href="#">International Shipping</a></li>
                    <li><a href="#">Affiliates</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom ptb-20">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <div class="copyright">
                <p>
                  &copy; 2022 <span> OneClick </span> Made with
                  <i class="fa fa-heart"></i> by
                  <a href="https://hasthemes.com/">HasThemes</a>
                </p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="mayment text-end">
                <a href="#">
                  <img src="assets/images/p14.png" alt="" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- footer-area end -->

    <!-- JS Vendor, Plugins & Activation Script Files -->

    <!-- Vendors JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.mixitup.min.js"></script>
    <script src="assets/js/jquery-ui.min.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/jquery.countdown.min.js"></script>
    <script src="assets/js/jquery.nivo.slider.pack.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!-- Activation JS -->
    <script src="assets/js/main.js"></script>
  </body>
</html>
