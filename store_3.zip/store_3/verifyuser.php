<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify User</title>


    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/icofont.css" />

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/nivo-slider.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/percircle.css" />

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>


    <?php

    require "connection.php";
    ?>



    <?php
    if (isset($_GET['code'])) {
        $code = $_GET['code'];




        $dverify = 1;
        Database::iud(" UPDATE `users`  SET `verified_batch` = '$dverify', `verify_account_code` = NULL , `email_verify` = '$dverify' WHERE `verify_account_code` = '$code' LIMIT 1; ");


    ?>

        <style>
            body {
                text-align: center;
                padding: 40px 0;
                background: #EBF0F5;
            }

            h1 {
                color: #88B04B;
                font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
                font-weight: 900;
                font-size: 40px;
                margin-bottom: 10px;
            }

            p {
                color: #404F5E;
                font-family: "Nunito Sans", "Helvetica Neue", sans-serif;
                font-size: 20px;
                margin: 0;
            }

            i {
                color: #9ABC66;
                font-size: 100px;
                line-height: 200px;
                margin-left: -15px;
            }

            .card {
                background: white;
                padding: 60px;
                border-radius: 4px;
                box-shadow: 0 2px 3px #C8D0D8;
                display: inline-block;
                margin: 0 auto;
            }
        </style>


        <div class="card">
            <div style="border-radius:200px; height:200px; width:200px; background: #F8FAF5; margin:0 auto;">
                <i class="checkmark">✓</i>
            </div>
            <h1>Success</h1>
            <p>We received your Completed User Verification;<br /></p>

            <br>
            <hr><br>
            <h4>We Sure To You Are Enter valid details <br> Thank You</h4>

            <script>
                // Function to change window location after a delay
                function changeWindowLocationWithDelay(url, delay) {
                    setTimeout(function() {
                        window.location.href = url; // Change the window location after the delay
                    }, delay);
                }

                // Example usage: Change the location after a delay of 3000 milliseconds (3 seconds)
                const targetUrl = 'http://localhost/store_3/update_account.php'; // Replace with your desired URL
                const delayMilliseconds = 2000; // Replace with your desired delay in milliseconds

                changeWindowLocationWithDelay(targetUrl, delayMilliseconds);
            </script>

        </div>

    <?php

    } else {
        echo ("Invalid Verification Code");
    }

    ?>


    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.mixitup.min.js"></script>
    <script src="assets/js/jquery-ui.min.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/jquery.countdown.min.js"></script>
    <script src="assets/js/jquery.nivo.slider.pack.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="script.js"></script>
    <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>
    <!-- <script src="assets/js/zoom.js"></script>
  <script src="assets/js/jquery.js"></script> -->


    <!-- Activation JS -->
    <script src="assets/js/main.js"></script>
    <script src="script.js"></script>
</body>

</html>