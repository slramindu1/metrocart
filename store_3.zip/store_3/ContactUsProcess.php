<?php



require "SMTP.php";
require "PHPMailer.php";
require "Exception.php";

use PHPMailer\PHPMailer\PHPMailer;


$email = $_GET["em"];
$user = $_GET["u"];
$message = $_GET["m"];

if (empty($user)) {
    echo ("Please enter your  Name!");
} else if (strlen($user) > 50) {
    echo (" Name must have LESS THAN 10 characters!");
} else if (empty($email)) {
    echo ("Please enter your email!");
} else if (strlen($email) > 100) {
    echo ("Email must have LESS THAN 50 characters!");
} else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo ("Invalid Email address!");
} else if (empty($message)) {
    echo ("Please enter your message!");
} else if (strlen($message) > 50) {
    echo (" Message must have LESS THAN 50 characters!");
} else if (strlen($message) < 10) {
    echo (" Message minimum 10 characters!");
} else {


    $mail = new PHPMailer;
    $mail->IsSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'synthwave.lk@gmail.com';
    $mail->Password = 'iirftpwqqivszobt';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom($email, 'Contact On Your Team For Problem');
    $mail->addReplyTo($email, 'Contact On Your Team For Problem');
    $mail->addAddress('synthwave.lk@gmail.com');
    $mail->isHTML(true);
    $mail->Subject = 'Contact On Your Team For Problem';
    $bodyContent = '
       

Dear Ramindu(Admin),<br>

' . $message . ' <br>

Best regards,<br>

' . $user . '<br>
my email address <br>
' . $email . '
<br>

Contact On,<br>
[Gadget Hub Contact Us Page]
';


    $mail->Body    = $bodyContent;

    if (!$mail->send()) {
        echo 'Verification code sending failed';
    } else {
        echo 'Success';
    }
}
