<!DOCTYPE html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Wishlist</title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

  <!-- CSS
		============================================ -->

  <!-- Icon Font CSS -->
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/icofont.css" />

  <!-- Plugins CSS -->
  <link rel="stylesheet" href="assets/css/animate.min.css" />
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/nivo-slider.css" />
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
  <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/magnific-popup.css" />
  <link rel="stylesheet" href="assets/css/percircle.css" />

  <!-- Main Style CSS -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>
  <?php
  include "header.php";
  if (isset($_SESSION["u"])) {

    $user = $_SESSION["u"]["email"];

    $total = 0;
    $subtal = 0;
    $shipping = 0;

  ?>

    <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->

    <?php

    $cart_rs = Database::search("SELECT * FROM `watchlist` WHERE `users_email`='" . $user . "'");
    $cart_num = $cart_rs->num_rows;

    if ($cart_num == 0) {

    ?>
      <div class="col-12">
        <div class="row">
          <div class="col-12 emptyCart"></div>
          <div class="col-12 text-center mb-2">
            <label class="form-label fs-1 fw-bold">
              <br>
              You have no items in your Wishlist yet.
            </label>
          </div>
          <div class="offset-lg-4 col-12 col-lg-4 mb-4 d-grid">
            <a href="home.php" class="btn btn-danger">
              Start Shopping
            </a>
          </div>
        </div>
      </div>
      <!-- Empty View -->
    <?php

    } else {
    ?>
      <!-- Offcanvas Menu end -->

      <!-- cart-area start -->
      <div class="cart-main-container shop-bg">
        <div class="cart-area">
          <div class="container">
            <div class="woocommerce-breadcrumb mtb-15">
              <div class="menu">
                <ul>
                  <li><a href="home.php">Home</a></li>
                  <li class="active"><a href="wishlist.php">wishlist</a></li>
                </ul>
              </div>
            </div>

            <div class="account-title mtb-20 text-center">
              <h1>Wishlist</h1>
            </div>

            <div class="wishlist-heading mb-30">
              <h2>My wishlist on Welcome</h2>
            </div>
            <div class="cart-table mb-50 bg-fff">
              <div>
                <div class="table-content table-responsive">
                  <table>
                    <thead>
                      <tr>
                        <th class="product-remove"></th>
                        <th class="product-thumbnail"></th>
                        <th class="product-name">Product</th>
                        <th class="product-seller">Seller</th>
                        <th class="product-price">Price</th>
                        <th class="product-quantity">Quantity</th>
                        <th class="product-subtotal">Total</th>
                      </tr>
                    </thead>
                    <tbody>

                      <?php
                      for ($x = 0; $x < $cart_num; $x++) {
                        $cart_data = $cart_rs->fetch_assoc();

                        $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $cart_data["product_id"] . "'");
                        $product_data = $product_rs->fetch_assoc();

                        $total = $total + ($product_data["price"] * $cart_data["qty"]);

                        $address_rs = Database::search("SELECT district.district_id AS did FROM `users_has_address` INNER JOIN `city` ON 
                        users_has_address.city_city_id=city.city_id INNER JOIN `district` ON city.district_district_id=district.district_id WHERE 
                        `users_email`='" . $user . "'");
                        $address_data = $address_rs->fetch_assoc();

                        $ship = 0;
                        $shipping = 0; // Initialize $shipping variable

                        if ($address_data && isset($address_data["did"])) {
                          if ($address_data["did"] == 4) {
                            $ship = $product_data["delivery_fee_colombo"];
                            $shipping = $shipping + $product_data["delivery_fee_colombo"];
                          } else {
                            $ship = $product_data["delivery_fee_other"];
                            $shipping = $shipping + $product_data["delivery_fee_other"];
                          }
                        }

                        $seller_rs = Database::search("SELECT * FROM `users` WHERE `email`='" . $product_data["users_email"] . "'");
                        $seller_data = $seller_rs->fetch_assoc();
                        $seller = $seller_data["fname"] . " " . $seller_data["lname"];

                      ?>
                        <!-- product area start -->
                        <tr class="cart-item">
                          <td class="product-remove">

                            <a href="#" class="remove" title="Remove this item" onclick="deleteFromCart(<?php echo $cart_data['id']; ?>);">Remove</a><br>
                            <a href="#" class="remove" title="Remove this item" onclick="addtocart_from_watchlist(<?php echo $cart_data['product_id']; ?>);">Add To Cart</a>
                          </td>
                          <td class="product-thumbnail">
                            <a href="#">
                              <img src="assets/images/cart/1.jpg" alt="" />
                            </a>
                          </td>

                          <td class="product-name">
                            <a href="#"><?php echo $product_data["title"]; ?> </a>
                          </td>
                          <td class="product-seller">
                            <a href="#"><?php echo $seller; ?></a>
                          </td>
                          <td class="product-price">
                            <span class="amounte">Rs. <?php echo $product_data["price"]; ?> .00</span>
                          </td>
                          <td class="product-quantity">
                            <input value="1" min="1" type="number" />
                          </td>
                          <td class="product-subtotal">
                            <span class="sub-total">Rs. <?php echo $product_data["price"]; ?> .00</span>
                          </td>
                        </tr>
                        <!-- product area end -->

                      <?php
                      }
                      ?>




                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- cart-area End -->

      <!-- footer-area start -->
      <?php

      include "footer.php";

      ?>
    <?php
    }
    ?>
    </div>
  <?php

  } else {
    echo ("Please login or signup first");
  }


  include "footer.php"
  ?>
  <!-- footer-area end -->

  <!-- JS Vendor, Plugins & Activation Script Files -->

  <!-- Vendors JS -->
  <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
  <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
  <script src="script.js"></script>
  <!-- Plugins JS -->
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/jquery.mixitup.min.js"></script>
  <script src="assets/js/jquery-ui.min.js"></script>
  <script src="assets/js/jquery.scrollUp.min.js"></script>
  <script src="assets/js/jquery.countdown.min.js"></script>
  <script src="assets/js/jquery.nivo.slider.pack.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/plugins.js"></script>

  <!-- Activation JS -->
  <script src="assets/js/main.js"></script>
</body>

</html>