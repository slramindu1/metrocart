<!-- Offcanvas Menu start -->
  <div class="offcanvas offcanvas-start" id="offcanvasMenu">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title">Menu</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <div class="account-menu">
        <ul>
          <li><a href="login.php">My Account</a></li>
          <li>
            <a href="cart.php">compare <span>(0)</span></a>
          </li>
          <li>
            <a href="wishlist.php">Wishlist <span>(0)</span></a>
          </li>
        </ul>
      </div>

      <div class="accordion" id="languageMenu">
        <div class="accordion-item">
          <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
            English
          </button>
          <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
            <ul>
              <li><a href="#">France</a></li>
              <li><a href="#">Germany</a></li>
              <li><a href="#">Japanese</a></li>
            </ul>
          </div>
        </div>

        <div class="accordion-item">
          <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
            USD
          </button>
          <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
            <ul>
              <li><a href="#">EUR - Euro</a></li>
              <li><a href="#">GBP - British Pound</a></li>
              <li><a href="#">INR - Indian Rupee</a></li>
            </ul>
          </div>
        </div>
      </div>

      <div class="mobail-menu">
        <nav class="offcanvas-menu">
          <ul>
            <li class="active">
              <a href="home.php">Home</a>
              <ul class="sub-menu">
                <li><a href="home.php">Home shop 1</a></li>
                <li><a href="index-2.php">Home shop 2</a></li>
                <li><a href="index-3.php">Home shop 3</a></li>
              </ul>
            </li>
            <li>
              <a href="shop.php">Shop</a>
              <ul class="sub-menu">
                <li>
                  <a class="mega-title" href="#">Shop Layout</a>
                  <ul>
                    <li><a href="shop-full-width.php">Full Width</a></li>
                    <li>
                      <a href="shop-sitebar-right.php">Sidebar Right</a>
                    </li>
                    <li><a href="shop-sitebar-left.php">Sidebar Left</a></li>
                    <li><a href="Shop-list-view.php">List View</a></li>
                  </ul>
                </li>
                <li>
                  <a class="mega-title" href="#">Shop Pages</a>
                  <ul class="sub-menu">
                    <li><a href="login.php">My account</a></li>
                    <li><a href="cart.php">Shoping cart</a></li>
                    <li><a href="checkout.php">checkout</a></li>
                    <li><a href="wishlist.php">wishlist</a></li>
                  </ul>
                </li>
                <li>
                  <a class="mega-title" href="#">Product type</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="shop-simple-product.php">simple product</a>
                    </li>
                    <li>
                      <a href="shop-variable-Product.php">Variable Product</a>
                    </li>
                    <li>
                      <a href="shop-grouped-Product.php">Grouped Product</a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              <a href="blog.php">blog</a>
              <ul class="sub-menu">
                <li>
                  <a href="#">Blog Layouts 1</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="blog-left-sitebar-list.php">left sitebar list</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-1.php">left sitebar grid 1</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-2.php">left sitebar grid 2</a>
                    </li>
                    <li>
                      <a href="blog-left-sitebar-3.php">left sitebar grid 3</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 2</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="blog-right-sitebar-list.php">right sitebar list</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-1.php">right sitebar list 1</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-2.php">right sitebar list 2</a>
                    </li>
                    <li>
                      <a href="blog-right-sitebar-list-3.php">right sitebar list 3</a>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 3</a>
                  <ul class="sub-menu">
                    <li><a href="blog-1-col.php">grid 1 columns</a></li>
                    <li><a href="blog-2-col.php">grid 2 columns</a></li>
                    <li><a href="blog-3-col.php">grid 3 columns</a></li>
                    <li><a href="blog-4-col.php">grid 4 columns</a></li>
                  </ul>
                </li>
                <li>
                  <a href="#">Blog Layouts 4</a>
                  <ul class="sub-menu">
                    <li><a href="blog-details-1.php">format:images</a></li>
                    <li>
                      <a href="blog-details-gallery.php">format:gallery</a>
                    </li>
                    <li>
                      <a href="blog-details-vedio.php">format:video</a>
                    </li>
                    <li><a href="blog-details-2.php">format:audio</a></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li>
              <a href="#">pages</a>
              <ul class="sub-menu">
                <li><a href="about.php">about us</a></li>
                <li><a href="faq.php">F.A.Q.s</a></li>
                <li><a href="404.php">404 pages</a></li>
              </ul>
            </li>
            <li>
              <a href="protfolio.php">Protfolio</a>
              <ul class="sub-menu">
                <li><a href="protfolio-details-1.php">single project</a></li>
                <li><a href="protfolio-2-col.php">two columns</a></li>
                <li><a href="protfolio-3-col.php">three columns</a></li>
                <li><a href="protfolio.php">four columns</a></li>
              </ul>
            </li>
            <li><a href="contact.php">contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <!-- Offcanvas Menu end -->

  <!-- slider area start -->
  <div class="sloder-area">
    <div id="slider-active">
      <img src="assets/images/slider/1.jpg" alt="" title="#active1" />
      <img src="assets/images/slider/2.jpg" alt="" title="#active2" />
    </div>
    <div id="active1" class="nivo-html-caption">
      <div class="container">
        <div class="row">
          <div class="col-lg-11">
            <div class="slide1-text text-left">
              <div class="middle-text">
                <div class="cap-sub-title animated">
                  <h3>Welcome to market</h3>
                </div>
                <div class="cap-title animated text-uppercase">
                  <h1>Rayed Bravia KDL</h1>
                </div>
                <div class="cap-dec animated">
                  <p>
                    Claritas est etiam processus dynamicus, qui sequitur
                    mutationem<br />
                    consuetudium lectorum.
                  </p>
                </div>
                <div class="cap-readmore animated">
                  <a href="#">View Collection</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="slider-progress"></div>
    </div>
    <div id="active2" class="nivo-html-caption">
      <div class="container">
        <div class="row">
          <div class="col-lg-11">
            <div class="slide1-text text-left">
              <div class="middle-text">
                <div class="cap-sub-title animated">
                  <h3>Welcome to market</h3>
                </div>
                <div class="cap-title animated text-uppercase">
                  <h1>Rayed Bravia KDL</h1>
                </div>
                <div class="cap-dec animated">
                  <p>
                    Claritas est etiam processus dynamicus, qui sequitur
                    mutationem<br />
                    consuetudium lectorum.
                  </p>
                </div>
                <div class="cap-readmore animated">
                  <a href="#">View Collection</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="slider-progress"></div>
    </div>
  </div>
  <!-- slider area end -->

  <!-- product area start -->
  <div class="product-area ptb-35">
    <div class="container">
      <div class="product box-shadow bg-fff">
        <div class="product-title bg-1 text-uppercase">
          <i class="fa fa-star-o icon bg-4"></i>
          <h3>best selling</h3>
        </div>



        <!-- products database -->
        <div class="product-active left-right-angle">
          <div class="product-wrapper bl">
            <div class="product-img">
              <a href="#">
                <img src="assets/images/product/1.jpg" alt="" class="primary" />
                <img src="assets/images/product/2.jpg" alt="" class="secondary" />
              </a>
              <div class="product-icon c-fff hover-bg">
                <ul>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                  </li>
                </ul>
              </div>
              <span class="sale">Sale</span>
            </div>
            <div class="product-content">
              <h3><a href="#">Nam fringilla augue</a></h3>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <span>&300.00</span>
            </div>
          </div>
          <!-- products database -->

          <div class="product-wrapper bl">
            <div class="product-img">
              <a href="#">
                <img src="assets/images/product/3.jpg" alt="" class="primary" />
                <img src="assets/images/product/4.jpg" alt="" class="secondary" />
              </a>
              <div class="product-icon c-fff hover-bg">
                <ul>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="product-content">
              <h3><a href="#">Adipiscing cursus eu</a></h3>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <span>&300.00</span>
            </div>
          </div>

          <div class="product-wrapper bl">
            <div class="product-img">
              <a href="#">
                <img src="assets/images/product/5.jpg" alt="" class="primary" />
                <img src="assets/images/product/6.jpg" alt="" class="secondary" />
              </a>
              <div class="product-icon c-fff hover-bg">
                <ul>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="product-content">
              <h3><a href="#">Nam fringilla augue</a></h3>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <span>&300.00</span>
            </div>
          </div>
          <div class="product-wrapper bl">
            <div class="product-img">
              <a href="#">
                <img src="assets/images/product/7.jpg" alt="" class="primary" />
                <img src="assets/images/product/8.jpg" alt="" class="secondary" />
              </a>
              <div class="product-icon c-fff hover-bg">
                <ul>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="product-content">
              <h3><a href="#">Nam fringilla augue</a></h3>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <span>&300.00</span>
            </div>
          </div>
          <div class="product-wrapper bl">
            <div class="product-img">
              <a href="#">
                <img src="assets/images/product/1.jpg" alt="" class="primary" />
                <img src="assets/images/product/2.jpg" alt="" class="secondary" />
              </a>
              <div class="product-icon c-fff hover-bg">
                <ul>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="product-content">
              <h3><a href="#">Adipiscing cursus eu</a></h3>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <span>&300.00</span>
            </div>
          </div>
          <div class="product-wrapper bl">
            <div class="product-img">
              <a href="#">
                <img src="assets/images/product/5.jpg" alt="" class="primary" />
                <img src="assets/images/product/6.jpg" alt="" class="secondary" />
              </a>
              <div class="product-icon c-fff hover-bg">
                <ul>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                  </li>
                  <li>
                    <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="product-content">
              <h3><a href="#">Nam fringilla augue</a></h3>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <span>&300.00</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- product area end -->

  <!-- banner-area start -->
  <div class="banner-area">
    <div class="container">
      <div class="row g-4">
        <div class="col-xl-4 col-lg-4 col-md-6">
          <div class="single-banner">
            <a href="#">
              <img src="assets/images/banner/1.jpg" alt="" />
            </a>
          </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-6">
          <div class="single-banner">
            <a href="#">
              <img src="assets/images/banner/2.jpg" alt="" />
            </a>
          </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-6">
          <div class="single-banner">
            <a href="#">
              <img src="assets/images/banner/3.jpg" alt="" />
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- banner-area end -->

  <!-- all-product-area start -->
  <div class="all-product-area mtb-45">
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="latest-deals box-shadow mb-35 bg-fff">
            <div class="row">
              <div class="col-md-12">
                <div class="product-title bg-2 text-uppercase">
                  <i class="fa fa-history icon bg-3"></i>
                  <h3>latest deals</h3>
                </div>
              </div>
            </div>
            <div class="latest-deals-active">
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img src="assets/images/product/1.jpg" alt="" class="primary" />
                    <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                  </a>
                  <div class="product-icon hover-bg">
                    <ul>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                      </li>
                    </ul>
                  </div>
                  <span class="sale">Sale</span>
                  <div class="deal-count">
                    <div class="timer">
                      <div data-countdown="2023/12/01"></div>
                    </div>
                  </div>
                </div>
                <div class="product-content">
                  <h3><a href="#">Adipiscing cursus eu</a></h3>
                  <ul>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                  </ul>
                  <span>&300.00</span>
                </div>
              </div>
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img src="assets/images/product/6.jpg" alt="" class="primary" />
                    <img src="assets/images/product/3.jpg" alt="" class="secondary" />
                  </a>
                  <div class="product-icon hover-bg">
                    <ul>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                      </li>
                    </ul>
                  </div>
                  <span class="sale">Sale</span>
                  <div class="deal-count">
                    <div class="timer">
                      <div data-countdown="2023/12/01"></div>
                    </div>
                  </div>
                </div>
                <div class="product-content">
                  <h3><a href="#">Adipiscing cursus eu</a></h3>
                  <ul>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                  </ul>
                  <span>&300.00</span>
                </div>
              </div>
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img src="assets/images/product/3.jpg" alt="" class="primary" />
                    <img src="assets/images/product/5.jpg" alt="" class="secondary" />
                  </a>
                  <div class="product-icon hover-bg">
                    <ul>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                      </li>
                      <li>
                        <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                      </li>
                    </ul>
                  </div>
                  <span class="sale">Sale</span>
                  <div class="deal-count">
                    <div class="timer">
                      <div data-countdown="2023/12/01"></div>
                    </div>
                  </div>
                </div>
                <div class="product-content">
                  <h3><a href="#">Adipiscing cursus eu</a></h3>
                  <ul>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                    <li><i class="fa fa-star"></i></li>
                  </ul>
                  <span>&300.00</span>
                </div>
              </div>
            </div>
          </div>
          <!-- featured-area start -->
          <div class="featured-area box-shadow bg-fff">
            <div class="product-title bg-1 text-uppercase">
              <i class="fa fa-star-o icon bg-4"></i>
              <h3>featured</h3>
            </div>
            <div class="feautred-active right left-right-angle">
              <div class="featured-wrapper">
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/1.jpg" alt="" class="primary" />
                      <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/3.jpg" alt="" class="primary" />
                      <img src="assets/images/product/4.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/5.jpg" alt="" class="primary" />
                      <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/7.jpg" alt="" class="primary" />
                      <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
              <div class="featured-wrapper">
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/1.jpg" alt="" class="primary" />
                      <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/3.jpg" alt="" class="primary" />
                      <img src="assets/images/product/4.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/5.jpg" alt="" class="primary" />
                      <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/7.jpg" alt="" class="primary" />
                      <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
              <div class="featured-wrapper">
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/1.jpg" alt="" class="primary" />
                      <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/3.jpg" alt="" class="primary" />
                      <img src="assets/images/product/4.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/5.jpg" alt="" class="primary" />
                      <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/7.jpg" alt="" class="primary" />
                      <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
              <div class="featured-wrapper">
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/1.jpg" alt="" class="primary" />
                      <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/3.jpg" alt="" class="primary" />
                      <img src="assets/images/product/4.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/5.jpg" alt="" class="primary" />
                      <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper single-featured mtb-15">
                  <div class="product-img floatleft">
                    <a href="#">
                      <img src="assets/images/product/7.jpg" alt="" class="primary" />
                      <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                    </a>
                  </div>
                  <div class="product-content floatright">
                    <h3><a href="#">Duis convallis</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- featured-area end -->
          <!-- testimonils-area start -->
          <div class="testimonils-area box-shadow mtb-35 bg-fff">
            <div class="product-title bg-1 text-uppercase">
              <i class="fa fa-star-o icon bg-4"></i>
              <h3>TESTIMONIALS</h3>
            </div>
            <div class="feautred-active right left-right-angle">
              <div class="single-testimonil clear">
                <div class="testimonil-content p mtb-25">
                  <p>
                    Duis autem vel eum iriure dolor in hendrerit in vulputate
                    velit esse molestie consequat, vel illum dolore eu feugiat
                    nulla facilisis at vero eros et accumsan et iusto odio
                    dignissim…
                  </p>
                </div>
                <div class="test-img floatleft">
                  <img src="assets/images/test/2.jpg" alt="" />
                </div>
                <div class="test-info">
                  <h6>Kaji Hasibur Rahman</h6>
                  <span>Web Designer</span>
                </div>
              </div>
              <div class="single-testimonil clear">
                <div class="testimonil-content p mtb-25">
                  <p>
                    Duis autem vel eum iriure dolor in hendrerit in vulputate
                    velit esse molestie consequat, vel illum dolore eu feugiat
                    nulla facilisis at vero eros et accumsan et iusto odio
                    dignissim…
                  </p>
                </div>
                <div class="test-img floatleft">
                  <img src="assets/images/test/1.jpg" alt="" />
                </div>
                <div class="test-info">
                  <h6>Lorem ipsum</h6>
                  <span>CEO of WooThemes</span>
                </div>
              </div>
              <div class="single-testimonil clear">
                <div class="testimonil-content p mtb-25">
                  <p>
                    Duis autem vel eum iriure dolor in hendrerit in vulputate
                    velit esse molestie consequat, vel illum dolore eu feugiat
                    nulla facilisis at vero eros et accumsan et iusto odio
                    dignissim…
                  </p>
                </div>
                <div class="test-img floatleft">
                  <img src="assets/images/test/1.jpg" alt="" />
                </div>
                <div class="test-info">
                  <h6>Lorem ipsum</h6>
                  <span>CEO of WooThemes</span>
                </div>
              </div>
            </div>
          </div>
          <!-- testimonils-area end -->
          <!-- blog-area start -->
          <div class="blog-area box-shadow bg-fff">
            <div class="product-title bg-1 text-uppercase">
              <i class="fa fa-comments-o icon bg-4"></i>
              <h3>LATEST BLOG</h3>
            </div>
            <div class="feautred-active right left-right-angle">
              <div class="blog-wrapper">
                <div class="blog-img mtb-30">
                  <a href="#">
                    <img src="assets/images/blog/1.jpg" alt="" />
                  </a>
                </div>
                <div class="blog-content">
                  <h3><a href="#">hello world</a></h3>
                  <div class="blog-meta">
                    <span>April 18, 2022</span>
                    <span>0 Comment(s)</span>
                  </div>
                  <p>
                    Welcome to WordPress. This is your first post. Edit or
                    delete it, then start writing!Aenean posuere libero eu
                    augue condimentum rhoncus. Praesent …
                  </p>
                </div>
              </div>
              <div class="blog-wrapper">
                <div class="blog-img mtb-30">
                  <a href="#">
                    <img src="assets/images/blog/2.jpg" alt="" />
                  </a>
                </div>
                <div class="blog-content">
                  <h3><a href="#">hello world</a></h3>
                  <div class="blog-meta">
                    <span>April 18, 2022</span>
                    <span>0 Comment(s)</span>
                  </div>
                  <p>
                    Welcome to WordPress. This is your first post. Edit or
                    delete it, then start writing!Aenean posuere libero eu
                    augue condimentum rhoncus. Praesent …
                  </p>
                </div>
              </div>
              <div class="blog-wrapper">
                <div class="blog-img mtb-30">
                  <a href="#">
                    <img src="assets/images/blog/3.jpg" alt="" />
                  </a>
                </div>
                <div class="blog-content">
                  <h3><a href="#">hello world</a></h3>
                  <div class="blog-meta">
                    <span>April 18, 2022</span>
                    <span>0 Comment(s)</span>
                  </div>
                  <p>
                    Welcome to WordPress. This is your first post. Edit or
                    delete it, then start writing!Aenean posuere libero eu
                    augue condimentum rhoncus. Praesent …
                  </p>
                </div>
              </div>
              <div class="blog-wrapper">
                <div class="blog-img mtb-30">
                  <a href="#">
                    <img src="assets/images/blog/4.jpg" alt="" />
                  </a>
                </div>
                <div class="blog-content">
                  <h3><a href="#">hello world</a></h3>
                  <div class="blog-meta">
                    <span>April 18, 2022</span>
                    <span>0 Comment(s)</span>
                  </div>
                  <p>
                    Welcome to WordPress. This is your first post. Edit or
                    delete it, then start writing!Aenean posuere libero eu
                    augue condimentum rhoncus. Praesent …
                  </p>
                </div>
              </div>
              <div class="blog-wrapper">
                <div class="blog-img mtb-30">
                  <a href="#">
                    <img src="assets/images/blog/5.jpg" alt="" />
                  </a>
                </div>
                <div class="blog-content">
                  <h3><a href="#">hello world</a></h3>
                  <div class="blog-meta">
                    <span>April 18, 2022</span>
                    <span>0 Comment(s)</span>
                  </div>
                  <p>
                    Welcome to WordPress. This is your first post. Edit or
                    delete it, then start writing!Aenean posuere libero eu
                    augue condimentum rhoncus. Praesent …
                  </p>
                </div>
              </div>
            </div>
          </div>
          <!-- blog-area end -->
          <!-- newsletter-area start -->
          <div class="newsletter-area box-shadow mt-35 bg-fff">
            <div class="product-title bg-1 text-uppercase">
              <i class="fa fa-envelope-o icon bg-4"></i>
              <h3>NEWSLETTER SIGN UP</h3>
            </div>
            <div class="newsletter form-style plbr-15">
              <p>Submit your mail to get events</p>
              <form action="#">
                <input type="email" placeholder="Email" />
                <button><i class="fa fa-paper-plane-o"></i></button>
              </form>
            </div>
          </div>
          <!-- newsletter-area start -->
        </div>
        <!-- product-area start -->
        <div class="col-lg-9">
          <div class="product box-shadow bg-fff">
            <div class="product-title bg-1 text-uppercase">
              <i class="fa fa-paper-plane-o icon bg-4"></i>
              <h3>New Products</h3>
            </div>
            <div class="new-product-active left left-right-angle">
              <div class="product-items">
                <div class="product-wrapper bb bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/11.jpg" alt="" class="primary" />
                      <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                    <span class="sale">New</span>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/5.jpg" alt="" class="primary" />
                      <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
              <div class="product-items">
                <div class="product-wrapper bb bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/15.jpg" alt="" class="primary" />
                      <img src="assets/images/product/13.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/9.jpg" alt="" class="primary" />
                      <img src="assets/images/product/5.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
              <div class="product-items">
                <div class="product-wrapper bb bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/1.jpg" alt="" class="primary" />
                      <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                    <span class="sale">Sale</span>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/3.jpg" alt="" class="primary" />
                      <img src="assets/images/product/4.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
              <div class="product-items">
                <div class="product-wrapper bb bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/5.jpg" alt="" class="primary" />
                      <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/7.jpg" alt="" class="primary" />
                      <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
              <div class="product-items">
                <div class="product-wrapper bb bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/9.jpg" alt="" class="primary" />
                      <img src="assets/images/product/10.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/11.jpg" alt="" class="primary" />
                      <img src="assets/images/product/12.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
              <div class="product-items">
                <div class="product-wrapper bb bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/13.jpg" alt="" class="primary" />
                      <img src="assets/images/product/14.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
                <div class="product-wrapper bl">
                  <div class="product-img">
                    <a href="#">
                      <img src="assets/images/product/15.jpg" alt="" class="primary" />
                      <img src="assets/images/product/16.jpg" alt="" class="secondary" />
                    </a>
                    <div class="product-icon c-fff hover-bg">
                      <ul>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                        </li>
                        <li>
                          <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                        </li>
                      </ul>
                    </div>
                    <span class="sale">Sale</span>
                  </div>
                  <div class="product-content">
                    <h3><a href="#">Adipiscing cursus eu</a></h3>
                    <ul>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                      <li><i class="fa fa-star"></i></li>
                    </ul>
                    <span>&300.00</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- banner-area start -->
          <div class="banner-area mtb-35">
            <div class="row g-4">
              <div class="col-md-6">
                <div class="single-banner">
                  <a href="#">
                    <img src="assets/images/banner/4.jpg" alt="" />
                  </a>
                </div>
              </div>
              <div class="col-md-6">
                <div class="single-banner">
                  <a href="#">
                    <img src="assets/images/banner/5.jpg" alt="" />
                  </a>
                </div>
              </div>
            </div>
          </div>
          <!-- banner-area end -->
          <!-- tab-area start -->
          <div class="tab-area box-shadow bg-fff">
            <div class="product-title bg-1 text-uppercase">
              <i class="fa fa-check-square-o icon bg-4"></i>
              <h3>Products category</h3>
              <div class="tab-menu floatright">
                <ul class="nav" role="tablist">
                  <li>
                    <a class="active" href="#electronics" data-bs-toggle="tab">Electronics</a>
                  </li>
                  <li>
                    <a href="#smartphone" data-bs-toggle="tab">Smartphone</a>
                  </li>
                  <li><a href="#tablets" data-bs-toggle="tab">Tablets</a></li>
                </ul>
              </div>
            </div>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="electronics">
                <div class="tab-active left left-right-angle">
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/1.jpg" alt="" class="primary" />
                          <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/3.jpg" alt="" class="primary" />
                          <img src="assets/images/product/4.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/5.jpg" alt="" class="primary" />
                          <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/7.jpg" alt="" class="primary" />
                          <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/9.jpg" alt="" class="primary" />
                          <img src="assets/images/product/10.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/11.jpg" alt="" class="primary" />
                          <img src="assets/images/product/12.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/13.jpg" alt="" class="primary" />
                          <img src="assets/images/product/14.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/15.jpg" alt="" class="primary" />
                          <img src="assets/images/product/16.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/6.jpg" alt="" class="primary" />
                          <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/7.jpg" alt="" class="primary" />
                          <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div role="tabpanel" class="tab-pane fade" id="smartphone">
                <div class="tab-active left left-right-angle">
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/16.jpg" alt="" class="primary" />
                          <img src="assets/images/product/15.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/14.jpg" alt="" class="primary" />
                          <img src="assets/images/product/13.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/12.jpg" alt="" class="primary" />
                          <img src="assets/images/product/11.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/10.jpg" alt="" class="primary" />
                          <img src="assets/images/product/9.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/8.jpg" alt="" class="primary" />
                          <img src="assets/images/product/7.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/6.jpg" alt="" class="primary" />
                          <img src="assets/images/product/5.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/4.jpg" alt="" class="primary" />
                          <img src="assets/images/product/3.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/2.jpg" alt="" class="primary" />
                          <img src="assets/images/product/1.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/6.jpg" alt="" class="primary" />
                          <img src="assets/images/product/7.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/8.jpg" alt="" class="primary" />
                          <img src="assets/images/product/9.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div role="tabpanel" class="tab-pane fade" id="tablets">
                <div class="tab-active left left-right-angle">
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/4.jpg" alt="" class="primary" />
                          <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/5.jpg" alt="" class="primary" />
                          <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/2.jpg" alt="" class="primary" />
                          <img src="assets/images/product/9.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/11.jpg" alt="" class="primary" />
                          <img src="assets/images/product/9.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/12.jpg" alt="" class="primary" />
                          <img src="assets/images/product/14.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/5.jpg" alt="" class="primary" />
                          <img src="assets/images/product/7.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/13.jpg" alt="" class="primary" />
                          <img src="assets/images/product/14.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/9.jpg" alt="" class="primary" />
                          <img src="assets/images/product/16.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="product-items">
                    <div class="product-wrapper bb bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/10.jpg" alt="" class="primary" />
                          <img src="assets/images/product/1.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                        <span class="sale">Sale</span>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper bl">
                      <div class="product-img">
                        <a href="#">
                          <img src="assets/images/product/12.jpg" alt="" class="primary" />
                          <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                        </a>
                        <div class="product-icon c-fff hover-bg">
                          <ul>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Add to cart"><i class="fa fa-shopping-cart"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Wishlist"><i class="fa fa-heart-o"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Compare"><i class="fa fa-comments"></i></a>
                            </li>
                            <li>
                              <a href="#" data-bs-toggle="tooltip" title="Accumsan eli"><i class="fa fa-search"></i></a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- mostviewed-area start -->
          <div class="mostviewed-area mt-35 box-shadow bg-fff">
            <div class="product-title bg-1 text-uppercase">
              <i class="fa fa-check-square-o icon bg-4"></i>
              <h3>Mostviewed</h3>
            </div>
            <div class="row">
              <div class="col-lg-4 col-md-4">
                <div class="single-banner">
                  <a href="#">
                    <img src="assets/images/banner/6.jpg" alt="" />
                  </a>
                </div>
              </div>
              <div class="col-lg-8 col-md-8">
                <div class="mostviewed-active left-right-angle">
                  <div class="featured-wrapper">
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/6.jpg" alt="" class="primary" />
                          <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatleft">
                        <h3><a href="#">Cras nec nisl ut erat</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/11.jpg" alt="" class="primary" />
                          <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/9.jpg" alt="" class="primary" />
                          <img src="assets/images/product/7.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Cras nec nisl ut erat</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="featured-wrapper">
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/15.jpg" alt="" class="primary" />
                          <img src="assets/images/product/17.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Ligula euismod eget</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/8.jpg" alt="" class="primary" />
                          <img src="assets/images/product/18.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/7.jpg" alt="" class="primary" />
                          <img src="assets/images/product/5.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="featured-wrapper">
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/1.jpg" alt="" class="primary" />
                          <img src="assets/images/product/2.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/3.jpg" alt="" class="primary" />
                          <img src="assets/images/product/4.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/5.jpg" alt="" class="primary" />
                          <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="featured-wrapper">
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/7.jpg" alt="" class="primary" />
                          <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/9.jpg" alt="" class="primary" />
                          <img src="assets/images/product/10.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/11.jpg" alt="" class="primary" />
                          <img src="assets/images/product/12.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="featured-wrapper">
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/13.jpg" alt="" class="primary" />
                          <img src="assets/images/product/14.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/15.jpg" alt="" class="primary" />
                          <img src="assets/images/product/16.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/17.jpg" alt="" class="primary" />
                          <img src="assets/images/product/18.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="featured-wrapper">
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/3.jpg" alt="" class="primary" />
                          <img src="assets/images/product/4.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/5.jpg" alt="" class="primary" />
                          <img src="assets/images/product/6.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                    <div class="product-wrapper single-featured mtb-15">
                      <div class="product-img floatleft">
                        <a href="#">
                          <img src="assets/images/product/7.jpg" alt="" class="primary" />
                          <img src="assets/images/product/8.jpg" alt="" class="secondary" />
                        </a>
                      </div>
                      <div class="product-content floatright">
                        <h3><a href="#">Adipiscing cursus eu</a></h3>
                        <ul>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                          <li><i class="fa fa-star"></i></li>
                        </ul>
                        <span>&300.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- mostviewed-area end -->
        </div>
        <!-- product-area end -->
      </div>
    </div>
  </div>