<!DOCTYPE html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Xmee | Login and Register Form </title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="login_res/img/favicon.png" />
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="login_res/css/bootstrap.min.css" />
  <!-- Fontawesome CSS -->
  <link rel="stylesheet" href="login_res/css/fontawesome-all.min.css" />
  <!-- Flaticon CSS -->
  <link rel="stylesheet" href="login_res/font/flaticon.css" />
  <!-- Google Web Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
  <!-- Custom CSS -->
  <link rel="stylesheet" href="login_res/style.css" />
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->
  <div id="preloader" class="preloader">
    <div class="inner">
      <div class="line1"></div>
      <div class="line2"></div>
      <div class="line3"></div>
    </div>
  </div>
  <section class="fxt-template-animation fxt-template-layout13">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 col-12 order-md-2 fxt-bg-wrap">
          <div class="fxt-bg-img" data-bg-image="login_res/img/figure/bg13-l.jpg">
            <div class="fxt-header">
              <div class="fxt-transformY-50 fxt-transition-delay-1">
                <a href="index.php" class="fxt-logo"><img src="assets/images/logo/1.png" alt="Logo" /></a>
              </div>
              <div class="fxt-transformY-50 fxt-transition-delay-2">
                <h1>Welcome To MetroCart</h1>
              </div>
              <div class="fxt-transformY-50 fxt-transition-delay-3">
                <p>
                  Grursus mal suada faci lisis Lorem ipsum dolarorit more
                  ametion consectetur elit. Vesti at bulum nec odio aea the
                  dumm ipsumm ipsum that dolocons rsus mal suada and fadolorit
                  to the dummy consectetur elit the Lorem Ipsum genera.
                </p>
              </div>
            </div>
            <ul class="fxt-socials">
              <li class="fxt-facebook fxt-transformY-50 fxt-transition-delay-4">
                <a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a>
              </li>
              <li class="fxt-twitter fxt-transformY-50 fxt-transition-delay-5">
                <a href="#" title="twitter"><i class="fab fa-twitter"></i></a>
              </li>
              <li class="fxt-google fxt-transformY-50 fxt-transition-delay-6">
                <a href="#" title="google"><i class="fab fa-google-plus-g"></i></a>
              </li>
              <li class="fxt-linkedin fxt-transformY-50 fxt-transition-delay-7">
                <a href="#" title="linkedin"><i class="fab fa-linkedin-in"></i></a>
              </li>
              <li class="fxt-youtube fxt-transformY-50 fxt-transition-delay-8">
                <a href="#" title="youtube"><i class="fab fa-youtube"></i></a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-6 col-12 order-md-1 fxt-bg-color">
          <div class="fxt-content">
            <h2>Forgot Password</h2>
            <div class="fxt-form">
              <div>
                <div class="form-group">
                  <label for="email" class="input-label">Enter The Correct Email Address</label>
                  <input type="text" id="email2" class="form-control" name="email" placeholder="Enter Correct Email Address" />
                </div>
                <div class="form-group">
                  <button type="submit" class="fxt-btn-fill" onclick="forgotpassword();">
                    Enter The Email
                  </button>
                </div>
              </div>
            </div>
            <div class="text-center">
              <p>
                Don't have an account?<a href="register.php" class="switcher-text2 inline-text">Register</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- jquery-->
  <script src="login_res/js/jquery.min.js"></script>
  <!-- Bootstrap js -->
  <script src="login_res/js/bootstrap.min.js"></script>
  <!-- Imagesloaded js -->
  <script src="login_res/js/imagesloaded.pkgd.min.js"></script>
  <!-- Validator js -->
  <script src="login_res/js/validator.min.js"></script>
  <!-- Custom Js -->
  <script src="login_res/js/main.js"></script>
  <script src="script.js"></script>
</body>

</html>