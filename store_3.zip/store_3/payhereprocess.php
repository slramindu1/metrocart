<?php

session_start();
require "connection.php";

if (isset($_SESSION["u"])) {
    if (isset($_GET["id"]) && isset($_GET["qty"])) {
        $id = htmlspecialchars($_GET["id"]);
        $qty = (int)$_GET["qty"];
        $umail = $_SESSION["u"]["email"];

        $array = array();
        $order_id = uniqid();

        $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $id . "'");
        if ($product_rs->num_rows > 0) {
            $product_data = $product_rs->fetch_assoc();

            $city_rs = Database::search("SELECT * FROM `users_has_address` WHERE `users_email`='" . $umail . "'");
            if ($city_rs->num_rows == 1) {
                $city_data = $city_rs->fetch_assoc();

                $city_id = $city_data["city_city_id"];
                $address = $city_data["line1"] . "," . $city_data["line2"];

                $district_rs = Database::search("SELECT * FROM `city` WHERE `city_id`='" . $city_id . "'");
                if ($district_rs->num_rows > 0) {
                    $district_data = $district_rs->fetch_assoc();

                    $district_id = $district_data["district_district_id"];
                    $delivery = 0;

                    if ($district_id == "4") {
                        $delivery = (int)$product_data["delivery_fee_colombo"];
                    } else {
                        $delivery = (int)$product_data["delivery_fee_other"];
                    }

                    $item = $product_data["title"];
                    $amount = ((int)$product_data["price"] * $qty) + $delivery;

                    $fname = $_SESSION["u"]["fname"];
                    $lname = $_SESSION["u"]["lname"];
                    $mobile = $_SESSION["u"]["mobile"];
                    $uaddress = $address;
                    $city = $district_data["city_name"];

                    $merchant_id = "1227811";
                    $merchant_secret = "NDEzNTE3NzM4MDEzMjY0NTY3NjczNzkwOTc1MTAzMzc3NzY3MjA3NQ==";
                    $currency = "LKR";

                    $hash = strtoupper(
                        md5(
                            $merchant_id .
                            $order_id .
                            number_format($amount, 2, '.', '') .
                            $currency .
                            strtoupper(md5($merchant_secret))
                        )
                    );

                    $array["id"] = $order_id;
                    $array["item"] = $item;
                    $array["amount"] = $amount;
                    $array["fname"] = $fname;
                    $array["lname"] = $lname;
                    $array["mobile"] = $mobile;
                    $array["address"] = $uaddress;
                    $array["city"] = $city;
                    $array["umail"] = $umail;
                    $array["hash"] = $hash;

                    echo json_encode($array);
                } else {
                    echo json_encode(["error" => "District not found."]);
                }
            } else {
                echo json_encode(["error" => "2"]); // No address found
            }
        } else {
            echo json_encode(["error" => "Product not found."]);
        }
    } else {
        echo json_encode(["error" => "Missing product ID or quantity."]);
    }
} else {
    echo json_encode(["error" => "1"]); // User not logged in
}
