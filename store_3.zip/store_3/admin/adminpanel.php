<?php

session_start();

require "connection.php";

if (isset($_SESSION["au"])) {

?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <title>
      Lava Material - Web Application and Website Multipurpose Admin Panel
      Template
    </title>
    <!--== META TAGS ==-->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!--== FAV ICON ==-->
    <link rel="shortcut icon" href="images/fav.ico" />

    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600|Quicksand:300,400,500" rel="stylesheet" />

    <!-- FONT-AWESOME ICON CSS -->
    <link rel="stylesheet" href="css/font-awesome.min.css" />

    <!--== ALL CSS FILES ==-->
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/mob.css" />
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/materialize.css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
    <!--== MAIN CONTRAINER ==-->
    <div class="container-fluid sb1">
      <div class="row">
        <!--== LOGO ==-->
        <div class="col-md-2 col-sm-3 col-xs-6 sb1-1">
          <a href="#" class="btn-close-menu"><i class="fa fa-times" aria-hidden="true"></i></a>
          <a href="#" class="atab-menu"><i class="fa fa-bars tab-menu" aria-hidden="true"></i></a>
          <a href="index.html" class="logo"><img src="images/logo1.png" alt="" />
          </a>
        </div>
        <!--== SEARCH ==-->
        <div class="col-md-6 col-sm-6 mob-hide">
          <form class="app-search">
            <input type="text" placeholder="Search..." class="form-control" />
            <a href=""><i class="fa fa-search"></i></a>
          </form>
        </div>
        <!--== NOTIFICATION ==-->
        <div class="col-md-2 tab-hide">
          <div class="top-not-cen">
            <a class="waves-effect btn-noti" href="#"><i class="fa fa-commenting-o" aria-hidden="true"></i><span>5</span></a>
            <a class="waves-effect btn-noti" href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i><span>5</span></a>
            <a class="waves-effect btn-noti" href="#"><i class="fa fa-tag" aria-hidden="true"></i><span>5</span></a>
          </div>
        </div>
        <!--== MY ACCCOUNT ==-->
        <div class="col-md-2 col-sm-3 col-xs-6">
          <!-- Dropdown Trigger -->
          <a class="waves-effect dropdown-button top-user-pro" href="#" data-activates="top-menu"><img src="images/user/6.png" alt="" />My Account
            <i class="fa fa-angle-down" aria-hidden="true"></i>
          </a>

          <!-- Dropdown Structure -->
          <ul id="top-menu" class="dropdown-content top-menu-sty">
            <li>
              <a href="setting.html" class="waves-effect"><i class="fa fa-cogs" aria-hidden="true"></i>Admin Setting</a>
            </li>
            <li>
              <a href="listing-all.html" class="waves-effect"><i class="fa fa-list-ul" aria-hidden="true"></i> Listings</a>
            </li>
            <li>
              <a href="hotel-all.html" class="waves-effect"><i class="fa fa-building-o" aria-hidden="true"></i> Hotels</a>
            </li>
            <li>
              <a href="package-all.html" class="waves-effect"><i class="fa fa-umbrella" aria-hidden="true"></i> Tour
                Packages</a>
            </li>
            <li>
              <a href="event-all.html" class="waves-effect"><i class="fa fa-flag-checkered" aria-hidden="true"></i>
                Events</a>
            </li>
            <li>
              <a href="offers.html" class="waves-effect"><i class="fa fa-tags" aria-hidden="true"></i> Offers</a>
            </li>
            <li>
              <a href="user-add.html" class="waves-effect"><i class="fa fa-user-plus" aria-hidden="true"></i> Add New
                User</a>
            </li>
            <li>
              <a href="#" class="waves-effect"><i class="fa fa-undo" aria-hidden="true"></i> Backup Data</a>
            </li>
            <li class="divider"></li>
            <li>
              <a href="#" class="ho-dr-con-last waves-effect"><i class="fa fa-sign-in" aria-hidden="true"></i> Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <!--== BODY CONTNAINER ==-->
    <div class="container-fluid sb2">
      <div class="row">
        <div class="sb2-1">
          <!--== USER INFO ==-->
          <div class="sb2-12">
            <ul>
              <li><img src="images/placeholder.jpg" alt="" /></li>
              <li>
                <h5><?php echo $_SESSION["au"]["fname"] . " " . $_SESSION["au"]["lname"]; ?> <span> Santa Ana, CA</span></h5>
              </li>
              <li></li>
            </ul>
          </div>
          <!--== LEFT MENU ==-->
          <div class="sb2-13">
            <ul class="collapsible" data-collapsible="accordion">


            </ul>
          </div>
        </div>

        <!--== BODY INNER CONTAINER ==-->
        <div class="sb2-2">
          <!--== breadcrumbs ==-->
          <div class="sb2-2-2">
            <ul>
              <li>
                <a href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
              </li>
              <li class="active-bre"><a href="#"> Dashboard</a></li>
              <li class="page-back">
                <a href="login.php"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
              </li>
            </ul>
          </div>
          <!--== DASHBOARD INFO ==-->
          <div class="ad-v2-hom-info">
            <div class="ad-v2-hom-info-inn">
              <ul>

                <li>
                  <div class="ad-hom-box ad-hom-box-2">
                    <span class="ad-hom-col-com ad-hom-col-2"><i class="fa fa-usd"></i></span>
                    <div class="ad-hom-view-com">
                      <p><i class="fa fa-arrow-up up"></i> Daily Earnings</p>
                      <?php

                      $today = date("Y-m-d");
                      $thismonth = date("m");
                      $thisyear = date("Y");

                      $a = "0";
                      $b = "0";
                      $c = "0";
                      $e = "0";
                      $f = "0";

                      $invoice_rs = Database::search("SELECT * FROM `invoice`");
                      $invoice_num = $invoice_rs->num_rows;

                      for ($x = 0; $x < $invoice_num; $x++) {
                        $invoice_data = $invoice_rs->fetch_assoc();

                        $f = $f + $invoice_data["qty"]; //total qty

                        $d = $invoice_data["date"];
                        $splitDate = explode(" ", $d); //separate date from time
                        $pdate = $splitDate[0]; //sold date

                        if ($pdate == $today) {
                          $a = $a + $invoice_data["total"];
                          $c = $c + $invoice_data["qty"];
                        }

                        $splitMonth = explode("-", $pdate); //separate date as year,month & date
                        $pyear = $splitMonth[0]; //year
                        $pmonth = $splitMonth[1]; //month

                        if ($pyear == $thisyear) {
                          if ($pmonth == $thismonth) {
                            $b = $b + $invoice_data["total"];
                            $e = $e + $invoice_data["qty"];
                          }
                        }
                      }

                      ?>
                      <h3 class="fs-5">Rs. <?php echo $a; ?> .00</h3>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="ad-hom-box ad-hom-box-3">
                    <span class="ad-hom-col-com ad-hom-col-3"><i class="fa fa-address-card-o"></i></span>
                    <div class="ad-hom-view-com">
                      <p><i class="fa fa-arrow-up up"></i> Total Sellings</p>
                      <h3 class="fs-5"><?php echo $f; ?> Items</h3>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="ad-hom-box ad-hom-box-4">
                    <span class="ad-hom-col-com ad-hom-col-4"><i class="fa fa-envelope-open-o"></i></span>
                    <div class="ad-hom-view-com">
                      <p><i class="fa fa-arrow-up up"></i> Total Engagement</p>
                      <?php
                      $user_rs = Database::search("SELECT * FROM `users`");
                      $user_num = $user_rs->num_rows;
                      ?>
                      <h3 class="fs-5"><?php echo $user_num; ?> Members</h3>
                    </div>
                  </div>
                </li>

              </ul>
            </div>
          </div>


          <!--== User Details ==-->
          <div class="sb2-2-3">
            <div class="row">
              <div class="col-md-12">
                <div class="box-inn-sp">
                  <div class="inn-title">
                    <h4>User Details</h4>
                    <p>
                      Airtport Hotels The Right Way To Start A Short Break
                      Holiday
                    </p>
                    <a class="dropdown-button drop-down-meta" href="#" data-activates="dr-users"><i class="material-icons">more_vert</i></a>
                    <ul id="dr-users" class="dropdown-content">
                      <li><a href="#!">Add New</a></li>
                      <li><a href="#!">Edit</a></li>
                      <li><a href="#!">Update</a></li>
                      <li class="divider"></li>
                      <li>
                        <a href="#!"><i class="material-icons">delete</i>Delete</a>
                      </li>
                      <li>
                        <a href="#!"><i class="material-icons">subject</i>View All</a>
                      </li>
                      <li>
                        <a href="#!"><i class="material-icons">play_for_work</i>Download</a>
                      </li>
                    </ul>
                    <!-- Dropdown Structure -->
                  </div>
                  <div class="tab-inn">
                    <div class="table-responsive table-desi">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th>Profile Image</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Registerd Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php

                          $query = "SELECT * FROM `users`";
                          $pageno;

                          if (isset($_GET["page"])) {
                            $pageno = $_GET["page"];
                          } else {
                            $pageno = 1;
                          }

                          $user_rs = Database::search($query);
                          $user_num = $user_rs->num_rows;

                          $results_per_page = 20;
                          $number_of_pages = ceil($user_num / $results_per_page);

                          $page_results = ($pageno - 1) * $results_per_page;
                          $selected_rs =  Database::search($query . " LIMIT " . $results_per_page . " OFFSET " . $page_results . "");

                          $selected_num = $selected_rs->num_rows;

                          for ($x = 0; $x < $selected_num; $x++) {
                            $selected_data = $selected_rs->fetch_assoc();

                          ?>
                            <tr>
                              <td>
                                <span class="list-img"><img src="images/user/1.png" alt="" /></span>
                              </td>
                              <td>
                                <a href="#"><span class="list-enq-name"><?php echo $selected_data["fname"] ?></span></a>
                              </td>
                              <td>
                                <a href="#"><span class="list-enq-name"><?php echo $selected_data["lname"] ?></span></a>
                              </td>
                              <td><?php echo $selected_data["mobile"] ?></td>
                              <td><?php echo $selected_data["email"] ?></td>
                              <td><?php echo $selected_data["joined_date"] ?></td>
                              <td>
                                <?php

                                if ($selected_data["status"] == 1) {
                                ?>
                                  <button class="btn btn-danger" id="ub<?php echo $selected_data['email']; ?>" onclick="blockUser('<?php echo $selected_data['email']; ?>');">Block</button>
                                <?php
                                } else {
                                ?>
                                  <button class="btn btn-success" id="ub<?php echo $selected_data['email']; ?>" onclick="blockUser('<?php echo $selected_data['email']; ?>');">Unblock</button>
                              </td>
                            <?php

                                }

                            ?>

                            </tr>

                        </tbody>
                      <?php

                          }

                      ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="sb2-2-3">
            <div class="row">
              <!--== Listing Enquiry ==-->
              <div class="col-md-8">
                <div class="box-inn-sp">
                  <div class="inn-title">
                    <h4>Unverified Users</h4>
                    <p>
                      Airtport Hotels The Right Way To Start A Short Break
                      Holiday
                    </p>
                    <a class="dropdown-button drop-down-meta" href="#" data-activates="dr-listings"><i class="material-icons">more_vert</i></a>
                    <ul id="dr-listings" class="dropdown-content">
                      <li><a href="#!">Add New</a></li>
                      <li><a href="#!">Edit</a></li>
                      <li><a href="#!">Update</a></li>
                      <li class="divider"></li>
                      <li>
                        <a href="#!"><i class="material-icons">delete</i>Delete</a>
                      </li>
                      <li>
                        <a href="#!"><i class="material-icons">subject</i>View All</a>
                      </li>
                      <li>
                        <a href="#!"><i class="material-icons">play_for_work</i>Download</a>
                      </li>
                    </ul>
                    <!-- Dropdown Structure -->
                  </div>
                  <?php


                  // SQL query to get unverified users
                  $sql = "SELECT * FROM users WHERE verified_batch IS NULL";
                  $result = Database::search($sql);
                  ?>

                  <div class="tab-inn">
                    <div class="table-responsive table-desi">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th>Profile Image</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Date</th>
                            <th>Other</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if ($result->num_rows > 0) : ?>
                            <?php while ($row = $result->fetch_assoc()) : ?>
                              <tr>
                                <td>
                                  <span class='list-img'>
                                    <img src='<?php echo htmlspecialchars($row['profile_image']); ?>' alt='' />
                                  </span>
                                </td>
                                <td>
                                  <span class='list-enq-name'>
                                    <?php echo htmlspecialchars($row['fname']); ?>
                                  </span>
                                </td>
                                <td>
                                  <span class='list-enq-name'>
                                    <?php echo htmlspecialchars($row['lname']); ?>
                                  </span>
                                </td>
                                <td>
                                  <?php echo htmlspecialchars($row['joined_date']); ?>
                                </td>
                                <td>
                                  <button class="btn btn-danger">Send Warning Email</button>
                                </td>
                              </tr>
                            <?php endwhile; ?>
                          <?php else : ?>
                            <tr>
                              <td colspan='5'>No unverified users found</td>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              </div>
              <script type="text/javascript">
                window.onload = function() {

                  var options = {
                    title: {
                      text: "Website Traffic Source"
                    },
                    data: [{
                      type: "pie",
                      startAngle: 45,
                      showInLegend: "true",
                      legendText: "{label}",
                      indexLabel: "{label} ({y})",
                      yValueFormatString: "#,##0.#" % "",
                      dataPoints: [{
                          label: "Organic",
                          y: 36
                        },
                        {
                          label: "Email Marketing",
                          y: 31
                        },
                        {
                          label: "Referrals",
                          y: 7
                        },
                        {
                          label: "Twitter",
                          y: 7
                        },
                        {
                          label: "Facebook",
                          y: 6
                        },
                        {
                          label: "Google",
                          y: 10
                        },
                        {
                          label: "Others",
                          y: 3
                        }
                      ]
                    }]
                  };
                  $("#chartContainer").CanvasJSChart(options);

                }
              </script>
              <!--== Hotel Bookings ==-->
              <div class="col-md-4">
                <div class="box-inn-sp">
                  <div class="inn-title">
                    <h4>Website Security</h4>
                    <div id="chartContainer" style="height: 370px; width: 100%;"></div>

                    <!-- Dropdown Structure -->
                  </div>


                </div>
              </div>
            </div>
          </div>
          <div class="sb2-2-3">
            <div class="row">
              <div class="col-md-12">
                <div class="box-inn-sp">
                  <div class="inn-title">
                    <h4>Product Details</h4>
                    <p>
                      Airtport Hotels The Right Way To Start A Short Break
                      Holiday
                    </p>
                    <a class="dropdown-button drop-down-meta" href="#" data-activates="dr-users"><i class="material-icons">more_vert</i></a>
                    <ul id="dr-users" class="dropdown-content">
                      <li><a href="#!">Add New</a></li>
                      <li><a href="#!">Edit</a></li>
                      <li><a href="#!">Update</a></li>
                      <li class="divider"></li>
                      <li>
                        <a href="#!"><i class="material-icons">delete</i>Delete</a>
                      </li>
                      <li>
                        <a href="#!"><i class="material-icons">subject</i>View All</a>
                      </li>
                      <li>
                        <a href="#!"><i class="material-icons">play_for_work</i>Download</a>
                      </li>
                    </ul>
                    <!-- Dropdown Structure -->
                  </div>
                  <div class="tab-inn">
                    <div class="table-responsive table-desi">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th>Profile Image</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Registerd Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php

                          $query = "SELECT * FROM `product`";
                          $pageno;

                          if (isset($_GET["page"])) {
                            $pageno = $_GET["page"];
                          } else {
                            $pageno = 1;
                          }

                          $user_rs = Database::search($query);
                          $user_num = $user_rs->num_rows;

                          $results_per_page = 20;
                          $number_of_pages = ceil($user_num / $results_per_page);

                          $page_results = ($pageno - 1) * $results_per_page;
                          $selected_rs =  Database::search($query . " LIMIT " . $results_per_page . " OFFSET " . $page_results . "");

                          $selected_num = $selected_rs->num_rows;

                          for ($x = 0; $x < $selected_num; $x++) {
                            $selected_data = $selected_rs->fetch_assoc();

                          ?>
                            <tr>
                              <td>
                                <span class="list-img"><img src="images/user/1.png" alt="" /></span>
                              </td>
                              <td>
                                <a href="#"><span class="list-enq-name"><?php echo $selected_data["price"] ?></span></a>
                              </td>
                              <td>
                                <a href="#"><span class="list-enq-name"><?php echo $selected_data["qty"] ?></span></a>
                              </td>
                              <td><?php echo $selected_data["title"] ?></td>
                              <td><?php echo $selected_data["datetime_added"] ?></td>
                              <td><?php echo $selected_data["users_email"] ?></td>
                             
                           

                            </tr>

                        </tbody>
                      <?php

                          }

                      ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
         
          <!--== User Details ==-->
          <div class="sb2-2-3">
            <div class="row">
              <div class="col-md-12">
                <div class="box-inn-sp">
                  <div class="inn-title">
                    <h4>Google Map</h4>
                    <p>
                      Airtport Hotels The Right Way To Start A Short Break
                      Holiday
                    </p>
                    <a class="dropdown-button drop-down-meta" href="#" data-activates="dr-map"><i class="material-icons">more_vert</i></a>
                    <ul id="dr-map" class="dropdown-content">
                      <li><a href="#!">Add New</a></li>
                      <li><a href="#!">Edit</a></li>
                      <li><a href="#!">Update</a></li>
                      <li class="divider"></li>
                      <li>
                        <a href="#!"><i class="material-icons">delete</i>Delete</a>
                      </li>
                      <li>
                        <a href="#!"><i class="material-icons">subject</i>View All</a>
                      </li>
                      <li>
                        <a href="#!"><i class="material-icons">play_for_work</i>Download</a>
                      </li>
                    </ul>
                    <!-- Dropdown Structure -->
                  </div>
                  <div class="tab-inn">
                    <div class="table-responsive table-desi tab-map">
                      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6290413.804893654!2d-93.99620524741552!3d39.66116578737809!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880b2d386f6e2619%3A0x7f15825064115956!2sIllinois%2C+USA!5e0!3m2!1sen!2sin!4v1469954001005" allowfullscreen></iframe>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!--== BOTTOM FLOAT ICON ==-->
    <section>
      <div class="fixed-action-btn vertical">
        <a class="btn-floating btn-large red pulse">
          <i class="large material-icons">mode_edit</i>
        </a>
        <ul>
          <li>
            <a class="btn-floating red"><i class="material-icons">insert_chart</i></a>
          </li>
          <li>
            <a class="btn-floating yellow darken-1"><i class="material-icons">format_quote</i></a>
          </li>
          <li>
            <a class="btn-floating green"><i class="material-icons">publish</i></a>
          </li>
          <li>
            <a class="btn-floating blue"><i class="material-icons">attach_file</i></a>
          </li>
        </ul>
      </div>
    </section>

    <!--======== SCRIPT FILES =========-->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/materialize.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="script.js"></script>
    <script type="text/javascript" src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="https://cdn.canvasjs.com/jquery.canvasjs.min.js"></script>
  </body>

  </html>
<?php

} else {
  echo ("You are Not a valid user");
}

?>