<!DOCTYPE html>
<html lang="en">

<head>
  <title>
    Lava Material - Web Application and Website Multipurpose Admin Panel
    Template
  </title>
  <!--== META TAGS ==-->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  <!--== FAV ICON ==-->
  <link rel="shortcut icon" href="images/fav.ico" />

  <!-- GOOGLE FONTS -->
  <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700" rel="stylesheet" />

  <!-- FONT-AWESOME ICON CSS -->
  <link rel="stylesheet" href="css/font-awesome.min.css" />


  <!--== ALL CSS FILES ==-->
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/mob.css" />
  <link rel="stylesheet" href="css/bootstrap.css" />
  <link rel="stylesheet" href="css/materialize.css" />

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

<body>
  <div class="blog-login">
    <div class="blog-login-in">
      <form>
        <img src="images/logo.png" alt="" />
        <div class="row">
          <div class="input-field col s12">
            <input id="email" type="text" class="validate" />
            <label for="first_name1">Email </label>
          </div>
        </div>

        <div class="row">
          <div class="input-field col s12">
            <a class="waves-effect waves-light btn-large btn-log-in" onclick="login();">Login</a>
          </div>
        </div>
        <a href="forgot.html" class="for-pass">Forgot Password?</a>
      </form>
    </div>
  </div>
  <div class="modal" tabindex="-1" id="verificationModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Admin Verification</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <label class="form-label">Enter Your Verification Code</label>
          <input type="text" class="form-control" id="vcode">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" onclick="verify();">Verify</button>
        </div>
      </div>
    </div>
  </div>
  <!--======== SCRIPT FILES =========-->
  <script src="script.js"></script>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="bootstrap.bundle.js"></script>
  <script src="js/materialize.min.js"></script>
  <script src="js/custom.js"></script>
</body>

</html>