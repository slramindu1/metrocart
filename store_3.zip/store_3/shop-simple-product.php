<?php



// require "connection.php";
require "header.php";
if (isset($_GET["id"])) {
  $stockId = $_GET["id"];


  $user = $_SESSION["u"];
  // echo($user);



  $product_rs = Database::search("SELECT product.id,product.price,product.qty,product.description,
    product.title,product.datetime_added,product.delivery_fee_colombo,product.delivery_fee_other,
    product.category_cat_id,product.model_has_brand_id,product.color_clr_id,product.status_status_id,
    product.condition_condition_id,product.users_email,model.model_name AS mname,
    brand.brand_name AS bname FROM `product` INNER JOIN `model_has_brand` ON 
    model_has_brand.id=product.model_has_brand_id INNER JOIN `brand` ON 
    brand.brand_id=model_has_brand.brand_brand_id INNER JOIN `model` ON 
    model.model_id=model_has_brand.model_model_id WHERE product.id='" . $stockId . "'");

  $product_num = $product_rs->num_rows;
  if ($product_num == 1) {
    $product_data = $product_rs->fetch_assoc();


?>

    <!DOCTYPE html>
    <html>

    <head>
      <meta charset="utf-8" />
      <meta http-equiv="x-ua-compatible" content="ie=edge" />
      <title>Shop</title>
      <meta name="description" content="" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />

      <!-- Favicon -->
      <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

      <!-- CSS
		============================================ -->

      <!-- Icon Font CSS -->
      <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
      <link rel="stylesheet" href="assets/css/icofont.css" />

      <!-- Plugins CSS -->
      <link rel="stylesheet" href="assets/css/animate.min.css" />
      <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
      <link rel="stylesheet" href="assets/css/nivo-slider.css" />
      <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
      <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
      <link rel="stylesheet" href="assets/css/magnific-popup.css" />
      <link rel="stylesheet" href="assets/css/percircle.css" />

      <!-- Main Style CSS -->
      <link rel="stylesheet" href="assets/css/style.css" />
      <link rel="stylesheet" href="assets/css/responsive.css" />

    </head>

    <body>

      <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->

      <!-- header start -->

      <!-- header end -->

      <!-- Offcanvas Menu start -->
      <div class="offcanvas offcanvas-start" id="offcanvasMenu">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title">Menu</h5>
          <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <div class="account-menu">
            <ul>
              <li><a href="account.php">My Account</a></li>
              <li>
                <a href="cart.php">compare <span>(0)</span></a>
              </li>
              <li>
                <a href="wishlist.php">Wishlist <span>(0)</span></a>
              </li>
            </ul>
          </div>

          <div class="accordion" id="languageMenu">
            <div class="accordion-item">
              <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                English
              </button>
              <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
                <ul>
                  <li><a href="#">France</a></li>
                  <li><a href="#">Germany</a></li>
                  <li><a href="#">Japanese</a></li>
                </ul>
              </div>
            </div>

            <div class="accordion-item">
              <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                USD
              </button>
              <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
                <ul>
                  <li><a href="#">EUR - Euro</a></li>
                  <li><a href="#">GBP - British Pound</a></li>
                  <li><a href="#">INR - Indian Rupee</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="mobail-menu">
            <nav class="offcanvas-menu">
              <ul>
                <li class="active">
                  <a href="home.php">Home</a>
                  <ul class="sub-menu">
                    <li><a href="home.php">Home shop 1</a></li>
                    <li><a href="index-2.php">Home shop 2</a></li>
                    <li><a href="index-3.php">Home shop 3</a></li>
                  </ul>
                </li>
                <li>
                  <a href="shop.php">Shop</a>
                  <ul class="sub-menu">
                    <li>
                      <a class="mega-title" href="#">Shop Layout</a>
                      <ul>
                        <li><a href="shop-full-width.php">Full Width</a></li>
                        <li>
                          <a href="shop-sitebar-right.php">Sidebar Right</a>
                        </li>
                        <li><a href="shop-sitebar-left.php">Sidebar Left</a></li>
                        <li><a href="Shop-list-view.php">List View</a></li>
                      </ul>
                    </li>
                    <li>
                      <a class="mega-title" href="#">Shop Pages</a>
                      <ul class="sub-menu">
                        <li><a href="account.php">My account</a></li>
                        <li><a href="cart.php">Shoping cart</a></li>
                        <li><a href="checkout.php">checkout</a></li>
                        <li><a href="wishlist.php">wishlist</a></li>
                      </ul>
                    </li>
                    <li>
                      <a class="mega-title" href="#">Product type</a>
                      <ul class="sub-menu">
                        <li>
                          <a href="shop-simple-product.php">simple product</a>
                        </li>
                        <li>
                          <a href="shop-variable-Product.php">Variable Product</a>
                        </li>
                        <li>
                          <a href="shop-grouped-Product.php">Grouped Product</a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="blog.php">blog</a>
                  <ul class="sub-menu">
                    <li>
                      <a href="#">Blog Layouts 1</a>
                      <ul class="sub-menu">
                        <li>
                          <a href="blog-left-sitebar-list.php">left sitebar list</a>
                        </li>
                        <li>
                          <a href="blog-left-sitebar-1.php">left sitebar grid 1</a>
                        </li>
                        <li>
                          <a href="blog-left-sitebar-2.php">left sitebar grid 2</a>
                        </li>
                        <li>
                          <a href="blog-left-sitebar-3.php">left sitebar grid 3</a>
                        </li>
                      </ul>
                    </li>
                    <li>
                      <a href="#">Blog Layouts 2</a>
                      <ul class="sub-menu">
                        <li>
                          <a href="blog-right-sitebar-list.php">right sitebar list</a>
                        </li>
                        <li>
                          <a href="blog-right-sitebar-list-1.php">right sitebar list 1</a>
                        </li>
                        <li>
                          <a href="blog-right-sitebar-list-2.php">right sitebar list 2</a>
                        </li>
                        <li>
                          <a href="blog-right-sitebar-list-3.php">right sitebar list 3</a>
                        </li>
                      </ul>
                    </li>
                    <li>
                      <a href="#">Blog Layouts 3</a>
                      <ul class="sub-menu">
                        <li><a href="blog-1-col.php">grid 1 columns</a></li>
                        <li><a href="blog-2-col.php">grid 2 columns</a></li>
                        <li><a href="blog-3-col.php">grid 3 columns</a></li>
                        <li><a href="blog-4-col.php">grid 4 columns</a></li>
                      </ul>
                    </li>
                    <li>
                      <a href="#">Blog Layouts 4</a>
                      <ul class="sub-menu">
                        <li><a href="blog-details-1.php">format:images</a></li>
                        <li>
                          <a href="blog-details-gallery.php">format:gallery</a>
                        </li>
                        <li>
                          <a href="blog-details-vedio.php">format:video</a>
                        </li>
                        <li><a href="blog-details-2.php">format:audio</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li>
                  <a href="#">pages</a>
                  <ul class="sub-menu">
                    <li><a href="about.php">about us</a></li>
                    <li><a href="faq.php">F.A.Q.s</a></li>
                    <li><a href="404.php">404 pages</a></li>
                  </ul>
                </li>
                <li>
                  <a href="protfolio.php">Protfolio</a>
                  <ul class="sub-menu">
                    <li><a href="protfolio-details-1.php">single project</a></li>
                    <li><a href="protfolio-2-col.php">two columns</a></li>
                    <li><a href="protfolio-3-col.php">three columns</a></li>
                    <li><a href="protfolio.php">four columns</a></li>
                  </ul>
                </li>
                <li><a href="contact.php">contact us</a></li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
      <!-- Offcanvas Menu end -->

      <!-- simple product area start -->
      <div class="simple-product-area">
        <div class="container">
          <div class="woocommerce-breadcrumb mtb-15">
            <div class="menu">
              <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="shop.php">Shop</a></li>
                <li class="active"><a href="#"><?php echo $product_data["title"]; ?></a></li>
              </ul>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-9">
              <div class="row justify-content-center">
                <div class="col-lg-5 col-md-8">
                  <div class="symple-product mb-20">
                    <div class="single-product-menu mb-30 box-shadow">
                      <div class="nav single-product-active clear">
                        <?php
                        $image_rs = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $stockId . "'");
                        $image_num = $image_rs->num_rows;
                        $img = array();

                        if ($image_num != 0) {
                          for ($x = 0; $x < $image_num; $x++) {
                            $image_data = $image_rs->fetch_assoc();
                            $img[$x] = $image_data["img_path"];
                        ?>
                            <div class="single-img floatleft">
                             
                                <img src="<?php echo $img[$x]; ?>" class="img-thumbnail mt-1 mb-1" id="productImg<?php echo $x; ?>" onclick="loadMainImg(<?php echo $x; ?>);" />
                           
                            </div>
                          <?php
                          }
                        } else {
                          // If no product images are found, display placeholders
                          ?>
                          <div class="single-img floatleft">
                            <a href="#six" data-bs-toggle="tab">
                              <img src="assets/images/product/6.jpg" class="img-thumbnail mt-1 mb-1" id="productImgPlaceholder1" onclick="loadMainImg('Placeholder1');" />
                            </a>
                          </div>
                          <div class="single-img floatleft">
                            <a href="#seven" data-bs-toggle="tab">
                              <img src="assets/images/product/7.jpg" class="img-thumbnail mt-1 mb-1" id="productImgPlaceholder2" onclick="loadMainImg('Placeholder2');" />
                            </a>
                          </div>
                          <div class="single-img floatleft">
                            <a href="#eight" data-bs-toggle="tab">
                              <img src="assets/images/product/8.jpg" class="img-thumbnail mt-1 mb-1" id="productImgPlaceholder3" onclick="loadMainImg('Placeholder3');" />
                            </a>
                          </div>
                        <?php
                        }
                        ?>
                      </div>
                    </div>

                    <div class="single-product-tab box-shadow mb-20" id="mainProductContainer">
                      <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade show active">
                          <div class="mainImg" id="mainProductImg"></div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>

                <style>
                  .mainImg {
                    height: 340px;
                    background-image: url("assets/empty.svg");
                    background-size: contain;
                    background-repeat: no-repeat;
                    background-position: center;
                  }
                </style>
                <div class="col-lg-7">
                  <div class="symple-product box-shadow bg-fff p-15 mb-30">
                    <h3><?php echo $product_data["title"]; ?></h3>
                    <div class="product-content simple-product-content mb-10">
                      <ul>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                        <li><i class="fa fa-star"></i></li>
                      </ul>
                      <?php

                      $price = $product_data["price"];
                      $add = ($price / 100) * 10;
                      $new_price = $price + $add;
                      $diff = $new_price - $price;
                      $percent = ($diff / $price) * 100;

                      ?>
                      <a href="#">(3 customer reviews)</a> <br />
                      <span><del>Rs. <?php echo $new_price;  ?> .00</del><span>Rs <?php echo $price; ?> .00</span></span>
                    </div>
                    <p>
                      it over 2000 years old. Richard McClintock, a Latin
                      professor at Hampden-Sydney College in Virginia, looked up
                      one of the more
                    </p>
                    <div class="simple-product-form contuct-form mtb-20">

                      <div class="container">
                        <div class="row align-items-center">
                          <div class="col-auto">
                            <input min="1" max="1000" name="quantity" value="1" type="number" id="qty_input" />
                          </div>
                          <div class="col-auto">
                            <button onclick="addtocart(<?php echo $stockId; ?>);">Add to Cart</button>

                          </div>
                          <div class="col-auto">
                            <button type="submit" id="payhere-payment" onclick="buyNow(<?php echo $stockId ?>);">Buy Now</button>
                          </div>
                        </div>
                      </div>



                    </div>

                    <div class="product_meta">
                      <a href="<?php echo "sellerprofileview.php?users_email=" . ($product_data["users_email"]); ?>" class="btn1">View Seller</a>
                      <?php echo $product_data["users_email"] ?>
                      <br><br>
                      <div class="category mb-10">
                        <b>Categories:</b>
                        <a href="#">Accessories, </a>
                        <a href="#"> Clothing,</a>
                        <a href="#"> Hats,,</a>
                        <a href="#"> Hoodies</a>
                      </div>
                      <div class="single-blog-tag category bb pb-10">
                        <b>Tags:</b>
                        <a href="#">fashion,</a>
                      </div>

                      <div class="footer-content pt-15 text-uppercase">
                        <p>Share this product</p>
                        <ul>
                          <li>
                            <a href="#" data-bs-toggle="tooltip" title="Facebook"><i class="fa fa-facebook"></i></a>
                          </li>
                          <li>
                            <a href="#" data-bs-toggle="tooltip" title="Twetter"><i class="fa fa-twitter"></i></a>
                          </li>
                          <li>
                            <a href="#" data-bs-toggle="tooltip" title="Instagram"><i class="fa fa-instagram"></i></a>
                          </li>
                          <li>
                            <a href="#" data-bs-toggle="tooltip" title="Google-Plus"><i class="fa fa-google-plus"></i></a>
                          </li>
                          <li>
                            <a href="#" data-bs-toggle="tooltip" title="Linkedin"><i class="fa fa-linkedin"></i></a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="simple-product-tab box-shadow">
                <div class="simple-product-tab-menu clear">
                  <ul class="nav">
                    <li>
                      <a class="active" href="#description" data-bs-toggle="tab">Description</a>
                    </li>
                    <li>
                      <a href="#reviews" data-bs-toggle="tab">Reviews </a>
                    </li>
                  </ul>
                </div>
                <div class="tab-content bg-fff">
                  <div class="tab-pane fade show active" id="description">
                    <div class="product-description p-20 bt">
                      <h2>Product Description</h2>
                      <p>
                        it over 2000 years old. Richard McClintock, a Latin
                        professor at Hampden-Sydney College in Virginia, looked up
                        one of the more
                      </p>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="reviews">
                    <div class="product-reviews p-20 bt">
                      <div class="row">
                        <?php

                        $feedback_rs = Database::search("SELECT * FROM `feedback` WHERE `product_id`='" . $stockId . "'");
                        $feedback_num = $feedback_rs->num_rows;

                        for ($x = 0; $x < $feedback_num; $x++) {
                          $feedback_data = $feedback_rs->fetch_assoc();
                        ?>
                          <div class="col-lg-12">
                            <div class="review-area">

                              <ul>
                                <li class="review-1">
                                  <div class="review mb-20">
                                    <div class="review-img">
                                      <img class="img-thumbnail" src="assets/images/comment/1.jpg" alt="" />
                                    </div>
                                    <div class="col-12 mt-1 mb-1 mx-1">
                                      <div class="row  rounded me-0">
                                        <?php

                                        $user_rs = Database::search("SELECT * FROM `users` WHERE `email`='" . $feedback_data["users_email"] . "'");
                                        $user_data = $user_rs->fetch_assoc();

                                        ?>
                                        <div class="col-10 mt-1 mb-1 ms-0"><?php echo $user_data["fname"] . " " . $user_data["lname"]; ?></div>
                                        <div class="col-2 mt-1 mb-1 me-0">
                                          <?php
                                          if ($feedback_data["rating_id"] == 1) {
                                          ?>
                                            <span class="badge ">
                                              <div class="review-rating product-content simple-product-content pull-right">
                                                <ul>
                                                  <li><i class="fa fa-star text-warning"></i></li>
                                                  <li><i class="fa fa-star"></i></li>
                                                  <li><i class="fa fa-star"></i></li>
                                                  <li><i class="fa fa-star"></i></li>
                                                  <li><i class="fa fa-star"></i></li>
                                                </ul>
                                              </div>
                                            </span>
                                        </div>
                                      <?php
                                          } else if ($feedback_data["rating_id"] == 2) {
                                      ?>
                                        <span class="badge ">
                                          <div class="review-rating product-content simple-product-content pull-right">
                                            <ul>
                                              <li><i class="fa fa-star text-warning"></i></li>
                                              <li><i class="fa fa-star text-warning"></i></li>
                                              <li><i class="fa fa-star"></i></li>
                                              <li><i class="fa fa-star"></i></li>
                                              <li><i class="fa fa-star"></i></li>
                                            </ul>
                                          </div>
                                        </span>
                                      </div>
                                    <?php
                                          } else if ($feedback_data["rating_id"] == 3) {
                                    ?>
                                      <span class="badge ">
                                        <div class="review-rating product-content simple-product-content pull-right">
                                          <ul>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                          </ul>
                                        </div>
                                      </span>
                                    <?php
                                          } else if ($feedback_data["rating_id"] == 4) {
                                    ?>
                                      <span class="badge">
                                        <div class="review-rating product-content simple-product-content pull-right">
                                          <ul>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star"></i></li>
                                          </ul>
                                        </div>
                                      </span>
                                    <?php
                                          } else if ($feedback_data["rating_id"] == 5) {
                                    ?>
                                      <span class="badge">
                                        <div class="review-rating product-content simple-product-content pull-right">
                                          <ul>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>
                                            <li><i class="fa fa-star text-warning"></i></li>

                                          </ul>
                                        </div>
                                      </span>

                                    </div>
                                  <?php
                                          }
                                  ?>

                                  <div class="col-12">
                                    <b>
                                      <?php echo $feedback_data["description"]; ?>
                                    </b>
                                  </div>
                                  <div class="offset-6 col-6 text-end">
                                    <label class="form-label fs-6 text-black-50"><?php echo $feedback_data["date"]; ?></label>
                                  </div>
                                  </div>
                            </div>
                          </div>
                          </li>
                          </ul>
                      </div>
                    </div>
                  <?php
                        }

                  ?>

                  <div class="col-lg-6">
                    <div class="review-form form-style">
                      <h2>Add a review</h2>

                      <div class="col-12 d-none" id="msgdiv3">
                        <div class="alert alert-danger" role="alert" id="msg1">
                        </div>
                      </div>

                      <form id="ratingForm">
                        <p>Select You Can Provide Rating Stars</p>
                        <div class="review-rating product-content simple-product-content">
                          <select class="form-control" id="rating_select" name="rating_select">
                            <?php
                            $rs = Database::search("SELECT * FROM `rating`");
                            $n = $rs->num_rows;
                            for ($x = 0; $x < $n; $x++) {
                              $d = $rs->fetch_assoc();
                            ?>
                              <option value="<?php echo $d["id"]; ?>"><?php echo $d["rating_count"]; ?></option>
                            <?php
                            }
                            ?>
                          </select>
                        </div>
                        <p>Your Review</p>
                        <textarea name="customer_comment" id="customer_comment" cols="30" rows="10"></textarea>
                        <p>Email *</p>
                        <input type="email" id="email3" name="email3" />
                        <input type="hidden" name="pid" value="<?php echo $stockId; ?>" />
                        <button type="button" onclick="submit_feedback(<?php echo $stockId; ?>)">Submit</button>
                      </form>
                    </div>
                  </div>



                  </div>
                </div>
              </div>
            </div>
          </div>




        </div>

        <div class="col-lg-3">
          <!-- categories-area start -->
          <div class="categories-area box-shadow bg-fff">
            <div class="product-title home2-bg-1 text-uppercase home2-product-title">
              <i class="fa fa-bookmark icon bg-4"></i>
              <h3>categories</h3>
            </div>
            <div class="shop-categories-menu p-20 mb-30">
              <ul>
                <li><a href="#">Accessories</a><span> (7)</span></li>
                <li><a href="#">Clothing</a><span> (21)</span></li>
                <li><a href="#">Men's</a><span> (16)</span></li>
                <li><a href="#">Music</a><span> (11)</span></li>
                <li><a href="#">Posters</a><span> (7)</span></li>
                <li><a href="#">Women's</a><span> (14)</span></li>
              </ul>
            </div>
          </div>
          <!-- featured-area start -->

          <!-- product-tags-area start -->
          <div class="product-tags-area bg-fff box-shadow mtb-30">
            <div class="product-title home2-bg-1 text-uppercase home2-product-title">
              <i class="fa fa-bookmark icon bg-4"></i>
              <h3>Product Tags</h3>
            </div>
            <div class="tags tag-menu hover-bg p-20">
              <ul>
                <li><a href="#">commodo</a></li>
                <li><a href="#">enim</a></li>
                <li><a href="#">fashion</a></li>
                <li><a href="#">Fly</a></li>
                <li><a href="#">Glasses</a></li>
                <li><a href="#">Hats</a></li>
                <li><a href="#">Hoodies</a></li>
                <li><a href="#">libero</a></li>
                <li><a href="#">men</a></li>
                <li><a href="#">Men's</a></li>
                <li><a href="#">Nam</a></li>
                <li><a href="#">Popular</a></li>
                <li><a href="#">Product</a></li>
                <li><a href="#">version</a></li>
                <li><a href="#">women</a></li>
              </ul>
            </div>
          </div>
          <!-- compare-area start -->
          <div class="compare-area bg-fff box-shadow mb-30">
            <div class="product-title home2-bg-1 text-uppercase home2-product-title">
              <i class="fa fa-bookmark icon bg-4"></i>
              <h3>Compare</h3>
            </div>
            <div class="compare-menu p-20">
              <p>No products to compare</p>
              <a href="#">Clear all</a>
              <a href="#" data-bs-toggle="tooltip" title="Compare" class="pull-right compare text-uppercase">Compare
              </a>
            </div>
          </div>
        </div>
      </div>
      </div>
      </div>
      <!-- simple product area end -->
      <br>
      <hr><br>
      <!-- footer-area start -->
      <?php include "footer.php"; ?>
      <!-- footer-area end -->



      <!-- JS Vendor, Plugins & Activation Script Files -->

      <!-- Vendors JS -->
      <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
      <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

      <!-- Plugins JS -->
      <script src="assets/js/popper.min.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script src="assets/js/jquery.magnific-popup.min.js"></script>
      <script src="assets/js/jquery.mixitup.min.js"></script>
      <script src="assets/js/jquery-ui.min.js"></script>
      <script src="assets/js/jquery.scrollUp.min.js"></script>
      <script src="assets/js/jquery.countdown.min.js"></script>
      <script src="assets/js/jquery.nivo.slider.pack.js"></script>
      <script src="assets/js/owl.carousel.min.js"></script>
      <script src="assets/js/plugins.js"></script>
      <script src="script.js"></script>
      <script src="https://www.payhere.lk/lib/payhere.js"></script>

      <!-- <script src="assets/js/zoom.js"></script>
  <script src="assets/js/jquery.js"></script> -->


      <!-- Activation JS -->
      <script src="assets/js/main.js"></script>
      <script src="script.js"></script>


      <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      <script src="path/to/xzoom.min.js"></script>


    </body>

    </html>

<?php

  } else {
    echo ("Sory for the inconvinient");
  }
} else {
  echo ("Something went wrong");
}

?>