<!DOCTYPE html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>404</title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

  <!-- CSS
		============================================ -->

  <!-- Icon Font CSS -->
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/icofont.css" />

  <!-- Plugins CSS -->
  <link rel="stylesheet" href="assets/css/animate.min.css" />
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/nivo-slider.css" />
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
  <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/magnific-popup.css" />
  <link rel="stylesheet" href="assets/css/percircle.css" />

  <!-- Main Style CSS -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->

  <!-- header start  -->
  <div class="main-container">
    <!-- header start -->

    <!-- header end -->

    <!-- Offcanvas Menu start -->
    <div class="offcanvas offcanvas-start" id="offcanvasMenu">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title">Menu</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <div class="account-menu">
          <ul>
            <li><a href="account.php">My Account</a></li>
            <li>
              <a href="cart.php">compare <span>(0)</span></a>
            </li>
            <li>
              <a href="wishlist.php">Wishlist <span>(0)</span></a>
            </li>
          </ul>
        </div>

        <div class="accordion" id="languageMenu">
          <div class="accordion-item">
            <button class="accordion-button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
              English
            </button>
            <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
              <ul>
                <li><a href="#">France</a></li>
                <li><a href="#">Germany</a></li>
                <li><a href="#">Japanese</a></li>
              </ul>
            </div>
          </div>

          <div class="accordion-item">
            <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
              USD
            </button>
            <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#languageMenu">
              <ul>
                <li><a href="#">EUR - Euro</a></li>
                <li><a href="#">GBP - British Pound</a></li>
                <li><a href="#">INR - Indian Rupee</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div class="mobail-menu">
          <nav class="offcanvas-menu">
            <ul>
              <li class="active">
                <a href="home.php">Home</a>
                <ul class="sub-menu">
                  <li><a href="home.php">Home shop 1</a></li>
                  <li><a href="index-2.php">Home shop 2</a></li>
                  <li><a href="index-3.php">Home shop 3</a></li>
                </ul>
              </li>
              <li>
                <a href="shop.php">Shop</a>
                <ul class="sub-menu">
                  <li>
                    <a class="mega-title" href="#">Shop Layout</a>
                    <ul>
                      <li><a href="shop-full-width.php">Full Width</a></li>
                      <li>
                        <a href="shop-sitebar-right.php">Sidebar Right</a>
                      </li>
                      <li>
                        <a href="shop-sitebar-left.php">Sidebar Left</a>
                      </li>
                      <li><a href="Shop-list-view.php">List View</a></li>
                    </ul>
                  </li>
                  <li>
                    <a class="mega-title" href="#">Shop Pages</a>
                    <ul class="sub-menu">
                      <li><a href="account.php">My account</a></li>
                      <li><a href="cart.php">Shoping cart</a></li>
                      <li><a href="checkout.php">checkout</a></li>
                      <li><a href="wishlist.php">wishlist</a></li>
                    </ul>
                  </li>
                  <li>
                    <a class="mega-title" href="#">Product type</a>
                    <ul class="sub-menu">
                      <li>
                        <a href="shop-simple-product.php">simple product</a>
                      </li>
                      <li>
                        <a href="shop-variable-Product.php">Variable Product</a>
                      </li>
                      <li>
                        <a href="shop-grouped-Product.php">Grouped Product</a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li>
                <a href="blog.php">blog</a>
                <ul class="sub-menu">
                  <li>
                    <a href="#">Blog Layouts 1</a>
                    <ul class="sub-menu">
                      <li>
                        <a href="blog-left-sitebar-list.php">left sitebar list</a>
                      </li>
                      <li>
                        <a href="blog-left-sitebar-1.php">left sitebar grid 1</a>
                      </li>
                      <li>
                        <a href="blog-left-sitebar-2.php">left sitebar grid 2</a>
                      </li>
                      <li>
                        <a href="blog-left-sitebar-3.php">left sitebar grid 3</a>
                      </li>
                    </ul>
                  </li>
                  <li>
                    <a href="#">Blog Layouts 2</a>
                    <ul class="sub-menu">
                      <li>
                        <a href="blog-right-sitebar-list.php">right sitebar list</a>
                      </li>
                      <li>
                        <a href="blog-right-sitebar-list-1.php">right sitebar list 1</a>
                      </li>
                      <li>
                        <a href="blog-right-sitebar-list-2.php">right sitebar list 2</a>
                      </li>
                      <li>
                        <a href="blog-right-sitebar-list-3.php">right sitebar list 3</a>
                      </li>
                    </ul>
                  </li>
                  <li>
                    <a href="#">Blog Layouts 3</a>
                    <ul class="sub-menu">
                      <li><a href="blog-1-col.php">grid 1 columns</a></li>
                      <li><a href="blog-2-col.php">grid 2 columns</a></li>
                      <li><a href="blog-3-col.php">grid 3 columns</a></li>
                      <li><a href="blog-4-col.php">grid 4 columns</a></li>
                    </ul>
                  </li>
                  <li>
                    <a href="#">Blog Layouts 4</a>
                    <ul class="sub-menu">
                      <li><a href="blog-details-1.php">format:images</a></li>
                      <li>
                        <a href="blog-details-gallery.php">format:gallery</a>
                      </li>
                      <li>
                        <a href="blog-details-vedio.php">format:video</a>
                      </li>
                      <li><a href="blog-details-2.php">format:audio</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
              <li>
                <a href="#">pages</a>
                <ul class="sub-menu">
                  <li><a href="about.php">about us</a></li>
                  <li><a href="faq.php">F.A.Q.s</a></li>
                  <li><a href="404.php">404 pages</a></li>
                </ul>
              </li>
              <li>
                <a href="protfolio.php">Protfolio</a>
                <ul class="sub-menu">
                  <li>
                    <a href="protfolio-details-1.php">single project</a>
                  </li>
                  <li><a href="protfolio-2-col.php">two columns</a></li>
                  <li><a href="protfolio-3-col.php">three columns</a></li>
                  <li><a href="protfolio.php">four columns</a></li>
                </ul>
              </li>
              <li><a href="contact.php">contact us</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
    <!-- Offcanvas Menu end -->

    <!-- 404-area -->
    <div class="404-area ptb-140 bg-img-2">
      <div class="container">
        <div class="page-not-found text-center">
          <h2 class="text-dark fw-bold">Abnoramal Activites</h2>
          <h2>Your Account Suspended By Admin.</h2>
          <p>
            Sorry Your Account will be suspend by admin for the Customers report You Can Contact us our Support team <br>to know why suspend your account
          </p>
          <div class="input-src">
            <a href="contact.php" class="btn1">Contact Us</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- footer-area start -->
  <?php

  include "footer.php";

  ?>
  <!-- footer-area end -->

  <!-- JS Vendor, Plugins & Activation Script Files -->

  <!-- Vendors JS -->
  <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
  <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

  <!-- Plugins JS -->
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/jquery.mixitup.min.js"></script>
  <script src="assets/js/jquery-ui.min.js"></script>
  <script src="assets/js/jquery.scrollUp.min.js"></script>
  <script src="assets/js/jquery.countdown.min.js"></script>
  <script src="assets/js/jquery.nivo.slider.pack.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/plugins.js"></script>

  <!-- Activation JS -->
  <script src="assets/js/main.js"></script>
</body>

</html>