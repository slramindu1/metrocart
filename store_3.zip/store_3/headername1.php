<header>
  <div class="header-top-area bb d-none d-lg-block">
    <div class="container">
      <div class="row">

        <div class="col-lg-4">

          <div class="language-menu dropdown">
            <?php

            session_start();

            if (isset($_SESSION["u"])) {

              $data = $_SESSION["u"];

            ?>

              <span class="text-lg-start"><b>Welcome </b><?php echo $data["fname"]; ?></span> |
              <span class="text-lg-start fw-bold signout" onclick="signout();">Sign Out</span> |

            <?php

            } else {

            ?>

              <a href="index.php" class="text-decoration-none fw-bold">Sign In or Register</a> |

            <?php

            }

            ?>

          </div>
        </div>
        <div class="col-lg-3">
          <p class="h2-color text-center">Wellcome to Gadget Hub store!</p>
        </div>

        <div class="col-lg-5">
          <div class="header-top-right">
            <div class="account-menu">
             
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="header-middle-area">
    <div class="container">
      <div class="row align-items-center align-items-lg-start">
       

       

        
      </div>
    </div>
  </div>


  </div>
</header>