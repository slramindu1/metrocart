<!-- brand-area start -->
  <div class="brand-area mb-35">
    <div class="container">
      <div class="brand-active box-shadow p-15 bg-fff">
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/1.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/2.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/3.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/1.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/4.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/5.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/6.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/7.jpg" alt="" />
          </a>
        </div>
        <div class="single-brand">
          <a href="#">
            <img src="assets/images/brand/8.jpg" alt="" />
          </a>
        </div>
      </div>
    </div>
  </div>
  <!-- brand-area end -->
<!-- order-area start -->
<div class="order-area ptb-30 bt bg-fff">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-3 col-sm-6">
          <div class="single-order c-fff bg-1 p-20">
            <div class="order-icon">
              <span class="fa fa-plane"></span>
            </div>
            <div class="order-content">
              <h5>World-Wide Shipping</h5>
              <span>On order over $100</span>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="single-order c-fff bg-1 p-20">
            <div class="order-icon">
              <span class="fa fa-refresh"></span>
            </div>
            <div class="order-content">
              <h5>30 Days Return</h5>
              <span>Moneyback guarantee</span>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="single-order c-fff bg-1 p-20">
            <div class="order-icon">
              <span class="fa fa-umbrella"></span>
            </div>
            <div class="order-content">
              <h5>SUPPORT 24/7</h5>
              <span>Call us: ( +123 ) 456 789</span>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="single-order c-fff bg-1 p-20">
            <div class="order-icon">
              <span class="fa fa-user"></span>
            </div>
            <div class="order-content">
              <h5>MEMBER DISCOUNT</h5>
              <span>10% on order over $200</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<footer class="bg-fff bt">
      <div class="footer-top-area ptb-35 bb">
        <div class="container">
          <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
              <div class="footer-widget">
                <div class="footer-logo mb-25">
                  <img src="assets/images/logo/1.png" alt="" />
                </div>
                <div class="footer-content">
                  <p>
                    OneClick is a premium Wordpress theme with advanced admin
                    module. It's extremely customizable, easy to use and
                  </p>
                  <ul>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Facebook"
                        ><i class="fa fa-facebook"></i
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Twetter"
                        ><i class="fa fa-twitter"></i
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Instagram"
                        ><i class="fa fa-instagram"></i
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Google-Plus"
                        ><i class="fa fa-google-plus"></i
                      ></a>
                    </li>
                    <li>
                      <a href="#" data-bs-toggle="tooltip" title="Linkedin"
                        ><i class="fa fa-linkedin"></i
                      ></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-12">
              <div class="footer-widget">
                <h3 class="footer-title bb mb-20 pb-15">About Us</h3>
                <ul>
                  <li>
                    <div class="contuct-content">
                      <div class="contuct-icon">
                        <i class="fa fa-map-marker"></i>
                      </div>
                      <div class="contuct-info">
                        <span>75, Avenue Anatole France, Paris</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="contuct-content">
                      <div class="contuct-icon">
                        <i class="fa fa-fax"></i>
                      </div>
                      <div class="contuct-info">
                        <span>01.234 56789 - 10.987 65432</span>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="contuct-content">
                      <div class="contuct-icon">
                        <i class="fa fa-envelope"></i>
                      </div>
                      <div class="contuct-info">
                        <span>hasib.me1995@gmail.com</span>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-4 col-12">
              <div class="footer-widget">
                <h3 class="footer-title bb mb-20 pb-15">Information</h3>
                <div class="footer-menu home3-hover">
                  <ul>
                    <li><a href="blog.php">Our Blog</a></li>
                    <li><a href="shop.php">About Our Shop</a></li>
                    <li><a href="#">Secure Shopping</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-4 col-12">
              <div class="footer-widget">
                <h3 class="footer-title bb mb-20 pb-15">My account</h3>
                <div class="footer-menu home3-hover">
                  <ul>
                    <li><a href="account.php">My Account</a></li>
                    <li><a href="checkout.php">Checkout</a></li>
                    <li><a href="cart.php">Shopping Cart</a></li>
                    <li><a href="wishlist.php">Wishlist</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-4 col-12">
              <div class="footer-widget">
                <h3 class="footer-title bb mb-20 pb-15">Our services</h3>
                <div class="footer-menu">
                  <ul>
                    <li><a href="#">Shipping & Returns</a></li>
                    <li><a href="#">Secure Shopping</a></li>
                    <li><a href="#">International Shipping</a></li>
                    <li><a href="#">Affiliates</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom ptb-20">
        <div class="container">
          <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-12">
              <div class="copyright">
                <p>
                  &copy; 2022 <span> OneClick </span> Made with
                  <i class="fa fa-heart"></i> by
                  <a href="https://hasthemes.com/">HasThemes</a>
                </p>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-12">
              <div class="mayment text-right">
                <a href="#">
                  <img src="assets/images/p14.png" alt="" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>