<!DOCTYPE html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>MetroCart | Home</title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="assets/css/main.css" rel="stylesheet" />
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

  <!-- CSS
		============================================ -->

  <!-- Icon Font CSS -->
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/icofont.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <!-- Plugins CSS -->
  <link rel="stylesheet" href="assets/css/animate.min.css" />
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/nivo-slider.css" />
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
  <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/magnific-popup.css" />
  <link rel="stylesheet" href="assets/css/percircle.css" />

  <!-- Main Style CSS -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->

  <!-- header start -->
  <?php
  include "header.php";

  ?>
  <!-- header end -->
  <?php



  if (isset($_SESSION["u"])) {

    $email = $_SESSION["u"]["email"];


    $details_rs = Database::search("SELECT * FROM `users` INNER JOIN `gender` ON 
    gender.id=users.gender_id WHERE `email`='" . $email . "'");

    $image_rs = Database::search("SELECT * FROM `profile_image` WHERE `users_email`='" . $email . "'");

    $address_rs = Database::search("SELECT * FROM `users_has_address` INNER JOIN `city` ON 
    users_has_address.city_city_id=city_city_id INNER JOIN `district` ON 
    city.district_district_id=district.district_id INNER JOIN `province` ON 
    district.province_province_id=province.province_id WHERE `users_email`='" . $email . "'");

    $details = $details_rs->fetch_assoc();
    $image_details = $image_rs->fetch_assoc();
    $address_details = $address_rs->fetch_assoc();

  ?>
    <!-- Offcanvas Menu end -->
    <?php

    if (empty($details["status"])) {

    ?>
      <script>
        window.location = "suspend_account.php"
      </script>
    <?php

    }
    ?>


    <?php

    if (!empty($details["verified_batch"])) {

    ?>

    <?php
    } else {
    ?>
      <br>
      <div class="container">
        <div class="alert alert-danger" role="alert">
          You Are Not Valid User Please Convert Your Account To Valid Account On My Profile Page
        </div>
      </div>
    <?php  } ?>
    <!-- slider area start -->
    <div id="basicSearchResult">
      <div class="sloder-area">
        <div id="slider-active">
          <img src="assets/images/slider/1.jpg" alt="" title="#active1" />
          <img src="assets/images/slider/2.jpg" alt="" title="#active2" />
        </div>
        <div id="active1" class="nivo-html-caption">
          <div class="container">
            <div class="row">
              <div class="col-lg-11">
                <div class="slide1-text text-left">
                  <div class="middle-text">
                    <div class="cap-sub-title animated">
                      <h3>Welcome to MetroCart</h3>
                    </div>
                    <div class="cap-title animated text-uppercase">
                      <h1>Samsung 153500</h1>
                    </div>
                    <div class="cap-dec animated">
                      <p>
                        Latest Best Product On Sri Lanka<br />
                        Available on Gadget Hub
                      </p>
                    </div>
                    <div class="cap-readmore animated">
                      <a href="#">View Collection</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="slider-progress"></div>
        </div>
        <div id="active2" class="nivo-html-caption">
          <div class="container">
            <div class="row">
              <div class="col-lg-11">
                <div class="slide1-text text-left">
                  <div class="middle-text">
                    <div class="cap-sub-title animated">
                      <h3>Welcome to Gadget Hub</h3>
                    </div>
                    <div class="cap-title animated text-uppercase">
                      <h1>G735 Wirless Headset</h1>
                    </div>
                    <div class="cap-dec animated">
                      <p>
                        Best Working Products On Sri Lanka
                        Latest Product On 2023 Year<br />
                        Visible On Gadget Hub
                      </p>
                    </div>
                    <div class="cap-readmore animated">
                      <a href="#">View Collection</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="slider-progress"></div>
        </div>
      </div>
      <!-- slider area end -->

      <!-- product area start -->

      <!-- all-product-area end -->
      <div class="row">
        <div class="col-1"></div>
        <div class="col-10">
          <div class="product-title bg-2 text-uppercase">
            <i class="fa fa-check-square-o icon bg-2"></i>
            <h3>All Products Cateogry</h3>
          </div>
        </div>
        <div class="col-1"></div>
      </div>

      <?php

      $c_rs = Database::search("SELECT * FROM `category`");
      $c_num = $c_rs->num_rows;

      for ($y = 0; $y < $c_num; $y++) {

        $c_data = $c_rs->fetch_assoc();

      ?>
        <div class="container">
          <div class="col-12 mt-3 mb-3 product-title bg-1 text-uppercase">
            <i class="fa fa-check-square-o icon bg-4"></i>
            <h3><?php echo $c_data["cat_name"]; ?></a> &nbsp;&nbsp;</h3>
            <a href="#" class="text-decoration-none text-dark fs-6">See All &nbsp;&rarr;</a>
          </div>
        </div>


        <!-- product -->
        ‘්‍<div class="col-12 mb-3">
          <div class="row ">

            <div class="col-12">
              <div class="row justify-content-center gap-2">

                <?php

                $product_rs = Database::search("SELECT * FROM `product` WHERE `category_cat_id`='" . $c_data["cat_id"] . "' AND 
                                             `status_status_id`='1' ORDER BY `datetime_added` DESC LIMIT 4 OFFSET 0");

                $product_num = $product_rs->num_rows;

                for ($x = 0; $x < $product_num; $x++) {
                  $product_data = $product_rs->fetch_assoc();

                ?>

                  <div class="card col-12 col-lg-2 mt-2 mb-2" style="width: 18rem;">

                    <?php

                    $img_rs = Database::search("SELECT * FROM `product_img` WHERE 
                                            `product_id`='" . $product_data['id'] . "'");

                    $img_data = $img_rs->fetch_assoc();

                    ?>

                    <img src="<?php echo $img_data["img_path"]; ?>" class="card-img-top img-thumbnail mt-2" style="height: 250px;" />
                    <div class="card-body ms-0 m-0 text-center">
                      <h5 class="card-title fw-bold fs-6"><?php echo $product_data["title"]; ?></h5>
                      <span class="badge rounded-pill text-bg-info">New</span><br />
                      <span class="card-text text-primary">Rs. <?php echo $product_data["price"]; ?> .00</span><br />
                      <span class="card-text text-warning fw-bold">In Stock</span><br />
                      <span class="card-text text-success fw-bold"><?php echo $product_data["qty"]; ?> Items Available</span><br />
                      <a href="<?php echo "shop-simple-product.php?id=" . ($product_data["id"]); ?>" class="col-12 btn btn-success">Buy Now</a>
                      <button class="col-12 btn btn-dark mt-2" onclick="addtocart(<?php echo $product_data['id']; ?>);">
                        <i class="bi bi-cart4 text-white fs-5"></i>
                      </button>

                      <button class="col-12 btn btn-light mt-2" onclick="addToWatchlist(<?php echo $product_data['id']; ?>);">
                        <i class="bi bi-heart-fill text-dark fs-5"></i>
                      </button>
                    </div>
                  </div>

                <?php

                }

                ?>



              </div>
            </div>

          </div>
        </div>


      <?php

      }
      include "footer.php"
      ?>

    </div>

    <br>





    </div>
  <?php
  } else {

    header("Location:home.php");
  }
  ?>


  <!-- JS Vendor, Plugins & Activation Script Files -->

  <!-- Vendors JS -->
  <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
  <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

  <!-- Plugins JS -->
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery.magnific-popup.min.js"></script>
  <script src="assets/js/jquery.mixitup.min.js"></script>
  <script src="assets/js/jquery-ui.min.js"></script>
  <script src="assets/js/jquery.scrollUp.min.js"></script>
  <script src="assets/js/jquery.countdown.min.js"></script>
  <script src="assets/js/jquery.nivo.slider.pack.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/plugins.js"></script>
  <script src="https://kit.fontawesome.com/02566f2f41.js" crossorigin="anonymous"></script>

  <!-- Activation JS -->
  <script src="assets/js/main.js"></script>
  <script src="script.js"></script>
</body>

</html>