<?php
require "connection.php";

$security_id = 1; // Set to a valid security_id that exists in your `security` table

$fname = $_POST["f"];
$lname = $_POST["l"];
$email = $_POST["e"];
$password = $_POST["p"];
$mobile = $_POST["m"];
$gender = $_POST["g"];

if (empty($fname)) {
    echo ("Please enter your First Name!");
} elseif (strlen($fname) > 50) {
    echo ("First Name must have LESS THAN 50 characters!");
} elseif (empty($lname)) {
    echo ("Please enter your Last Name!");
} elseif (strlen($lname) > 50) {
    echo ("Last Name must have LESS THAN 50 characters!");
} elseif (empty($email)) {
    echo ("Please enter your Email address!");
} elseif (strlen($email) > 100) {
    echo ("Email must have LESS THAN 100 characters!");
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo ("Invalid Email address!");
} elseif (empty($password)) {
    echo ("Please enter your Password!");
} elseif (strlen($password) < 5 || strlen($password) > 20) {
    echo ("Password length must be between 5 and 20!");
} elseif (empty($mobile)) {
    echo ("Please enter your Mobile Number!");
} elseif (strlen($mobile) != 10) {
    echo ("Mobile Number must contain 10 characters");
} elseif (!preg_match("/07[0-9]{8}/", $mobile)) {
    echo ("Invalid Mobile Number!");
} else {
    $rs = Database::search("SELECT * FROM `users` WHERE `email`='" . $email . "' OR `mobile`='" . $mobile . "'");
    if ($rs->num_rows > 0) {
        echo ("User with the same Email or Mobile already exists.");
    } else {
        $d = new DateTime("now", new DateTimeZone("Asia/Colombo"));
        $date = $d->format("Y-m-d H:i:s");

        $security_check = Database::search("SELECT `id` FROM `security` WHERE `id` = '$security_id'");
        if ($security_check->num_rows == 0) {
            echo ("Invalid security_id.");
        } else {
            Database::iud("INSERT INTO `users` (`fname`, `lname`, `email`, `password`, `mobile`, `joined_date`, `status`, `gender_id`, `security_id`, `2_step_verify_id`) VALUES ('$fname', '$lname', '$email', '$password', '$mobile', '$date', '1', '$gender', '$security_id', '$security_id')");
            echo ("success");
        }
    }
}
?>
