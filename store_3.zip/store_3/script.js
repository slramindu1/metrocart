function register() {
    var f = document.getElementById("f_name").value;
    var l = document.getElementById("l_name").value;
    var e = document.getElementById("email").value;
    var p = document.getElementById("password").value;
    var m = document.getElementById("mobile").value;
    var g = document.getElementById("gender").value;

    var form = new FormData();
    form.append("f", f);
    form.append("l", l);
    form.append("e", e);
    form.append("p", p);
    form.append("m", m);
    form.append("g", g);

    var r = new XMLHttpRequest();
    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var text = r.responseText;
            var msgDiv = document.getElementById("msgdiv");
            var msg = document.getElementById("msg");
            if (text == "success") {
                msg.innerHTML = "Registration successful!";
                msg.className = "alert alert-success";
                msgDiv.className = "d-block";
                setTimeout(function () {
                    window.location.href = "login-13.php";
                }, 2000);
            } else {
                msg.innerHTML = text;
                msg.className = "alert alert-danger";
                msgDiv.className = "d-block";
            }
        }
    };
    r.open("POST", "signUpProcess.php", true);
    r.send(form);
}

function login() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var rememberme = document.getElementById("checkbox1").checked;

    var f = new FormData();
    f.append("e", email);
    f.append("p", password);
    f.append("r", rememberme);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "success") {
                window.location = "home.php";
            } else {
                alert(t);
            }
        }
    };

    r.open("POST", "signInProcess.php", true);
    r.send(f);
}





var bm;
function forgotpassword() {
    var email = document.getElementById("email2");
    // alert(email);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "Success") {

                alert("Verification code has sent to your Email. Please check your inbox");


            } else {
                alert(t);
            }

        }
    }

    r.open("GET", "forgotPasswordProcess.php?e=" + email.value, true);
    r.send();
}



function verifyuser() {

}

function contact() {
    var email = document.getElementById("em").value;
    var user = document.getElementById("username").value;
    var message = document.getElementById("mail").value;

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "Success") {
                alert("Mail Sent . We contact You In Few Hours");
                window.location.reload();
            } else {
                alert(t);
            }
        }
    }

    r.open("GET", "ContactUsProcess.php?em=" + email + "&u=" + user + "&m=" + message, true);
    r.send();
}

function signout() {

    // alert("Ok");

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "success") {
                window.location.reload();
            }
        }
    };

    r.open("GET", "signoutProcess.php", true);
    r.send();

}
function showPassword() {

    var np = document.getElementById("np");
    var npb = document.getElementById("npb");

    if (np.type == "password") {

        np.type = "text";
        npb.innerHTML = "Hide";

    } else {

        np.type = "password";
        npb.innerHTML = "Show";

    }

}

function showPassword2() {

    var rnp = document.getElementById("rnp");
    var rnpb = document.getElementById("rnpb");

    if (rnp.type == "password") {

        rnp.type = "text";
        rnpb.innerHTML = "Hide";

    } else {

        rnp.type = "password";
        rnpb.innerHTML = "Show";

    }

}

function update_account() {


    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var mobile = document.getElementById("mobile").value;
    var address = document.getElementById("address").value;
    var postal_code = document.getElementById("postal_code").value;
    var city = document.getElementById("city").value;

    alert("First Name: " + fname);
    alert("Last Name: " + lname);
    alert("Email: " + email);
    alert("Password: " + password);
    alert("Mobile: " + mobile);
    alert("Address: " + address);
    alert("Postal Code: " + postal_code);
    alert("City: " + city);

}

function resetPassword() {

    var email = document.getElementById("email");
    var np = document.getElementById("np");
    var rnp = document.getElementById("rnp");
    var vcode = document.getElementById("vc");



    // alert(email);
    // alert(vcode);
    // alert(np);
    // alert(rnp);

    var f = new FormData();
    f.append("e", email.value);
    f.append("n", np.value);
    f.append("r", rnp.value);
    f.append("v", vcode.value);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;

            if (t == "success") {
                alert("Your Password Updated");
                window.location.href = "index.php";

            } else {
                alert(t);
            }
        }
    };

    r.open("POST", "resetPasswordProcess.php", true);
    r.send(f);

}


function updateProfile() {

    alert("Ok");
    // alert("Ok");

    //   var first_name = document.getElementById("fname").value;
    //  var last_name = document.getElementById("lname").value;


    //  alert(first_name);
    // alert(last_name);



    var profile_img = document.getElementById("profileImage");
    // var profile_banner = document.getElementById("profilebanner");
    var first_name = document.getElementById("fname");
    var last_name = document.getElementById("lname");
    var mobile_no = document.getElementById("mobile");
    var password = document.getElementById("pw");
    var email_address = document.getElementById("email");
    var address_line_1 = document.getElementById("line1");
    var address_line_2 = document.getElementById("line2");
    var province = document.getElementById("province");
    var district = document.getElementById("district");
    var city = document.getElementById("city");
    var postal_code = document.getElementById("pc");


    // alert(first_name);
    // alert(postal_code);
    var f = new FormData();
    f.append("img", profile_img.files[0]);
    f.append("fn", first_name.value);
    f.append("ln", last_name.value);
    f.append("mn", mobile_no.value);
    f.append("pw", password.value);
    f.append("ea", email_address.value);
    f.append("al1", address_line_1.value);
    f.append("al2", address_line_2.value);
    f.append("p", province.value);
    f.append("d", district.value);
    f.append("c", city.value);
    f.append("pc", postal_code.value);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.status == 200 && r.readyState == 4) {
            var t = r.responseText;

            if (t == "success") {
                // signout();
                window.location = "home.php";
            } else {
                alert(t);
            }

        }
    }

    r.open("POST", "userProfileUpdateProcess.php", true);
    r.send(f);

}


$(function () {
    $(".xzoom, .xzoom - gallery").xzoom({
        zoomWidth: 400,
        tint: "#333",
        Xoffset: 15,
    });
});





function submit_feedback(id) {
    var form = new FormData(document.getElementById("ratingForm"));
    form.append("pid", id);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "ratingProcess.php", true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            var response = xhr.responseText;
            var msgDiv = document.getElementById("msgdiv3");
            var msg = document.getElementById("msg1");

            if (response == "success") {
                msg.innerHTML = "Your review has been submitted successfully!";
                msg.className = "alert alert-success";
            } else {
                msg.innerHTML = response;
                msg.className = "alert alert-danger";
            }
            msgDiv.classList.remove("d-none");
        }
    };
    xhr.send(form);
}


function updateprofile() {

    var view = document.getElementById("imgview"); //pfp viewer section grabber 
    var file = document.getElementById("profileimg"); //file chooser part grabber

    file.onchange = function () {
        var file1 = this.files[0];
        var pfpurl = window.URL.createObjectURL(file1);
        view.src = pfpurl;
    }
}

function addproductphoto() {

    var view1 = document.getElementById("product_image_view1"); //pfp viewer section grabber 
    var file1 = document.getElementById("i0"); //file chooser part grabber

    file1.onchange = function () {
        var file2 = this.files[0];
        var pfpurl = window.URL.createObjectURL(file2);
        view1.src = pfpurl;
    }
}

function addproductphoto1() {

    var view1 = document.getElementById("product_image_view2"); //pfp viewer section grabber 
    var file2 = document.getElementById("i1"); //file chooser part grabber

    file2.onchange = function () {
        var file3 = this.files[0];
        var pfpurl = window.URL.createObjectURL(file3);
        view1.src = pfpurl;
    }
}


function addproductphoto2() {

    var view1 = document.getElementById("product_image_view3"); //pfp viewer section grabber 
    var file3 = document.getElementById("i2"); //file chooser part grabber

    file3.onchange = function () {
        var file3 = this.files[0];
        var pfpurl = window.URL.createObjectURL(file3);
        view1.src = pfpurl;
    }
}





function updatebanner() {

    var view1 = document.getElementById("banner_view"); //pfp viewer section grabber 
    var file1 = document.getElementById("profilebanner"); //file chooser part grabber

    file1.onchange = function () {
        var file2 = this.files[0];
        var pfpurl = window.URL.createObjectURL(file2);
        view1.src = pfpurl;
    }
}

// function addProduct() {


//     var title = document.getElementById("title");
//     var desc = document.getElementById("desc");
//     var category = document.getElementById("category");
//     var dwc = document.getElementById("dwc");
//     var doc = document.getElementById("doc");

// alert(title);
// alert(desc);
// alert(category);
// alert(dwc);
// alert(doc);


// var condition = 0;

// if (document.getElementById("b").checked) {
//     condition = 1;
// } else if (document.getElementById("u").checked) {
//     condition = 2;
// }

// var image1 = document.getElementById("i0");
// var image2 = document.getElementById("i1");
// var image3 = document.getElementById("i2");
// var clr = document.getElementById("clr");
// var brand = document.getElementById("brand");
// var qty = document.getElementById("qty");
// var model = document.getElementById("model");
// var cost = document.getElementById("cost");




// alert(image1);
// alert(image2);
// alert(image3);
// alert(clr);
// alert(brand);
// alert(qty);
// alert(model);
// alert(cost);

// var f = new FormData();

// f.append("t", title.value);
// f.append("desc", desc.value);
// f.append("ca", category.value);
// f.append("dwc", dwc.value);
// f.append("doc", doc.value);
// f.append("image1", image1.value);
// f.append("image2", image2.value);
// f.append("image3", image3.value);
// f.append("col", clr.value);
// f.append("b", brand.value);
// f.append("qty", qty.value);
// f.append("m", model.value);
// f.append("con", condition);
// f.append("cost", cost.value);









// var file_count1 = image1.files.length;

// var file_count2 = image2.files.length;

// var file_count3 = image3.files.length;

// for (var x = 0; x < file_count1; x++) {

//     f.append("image1" + x, image.files[x]);

// }
// for (var x = 0; x < file_count2; x++) {

//     f.append("image2" + x, image.files[x]);

// }
// for (var x = 0; x < file_count3; x++) {

//     f.append("image3" + x, image.files[x]);

// }

// var r = new XMLHttpRequest();

// r.onreadystatechange = function () {
//     if (r.readyState == 4) {
//         var t = r.responseText;

//         if (t == "Product images saved successfully") {
//             window.location.reload();
//         } else {
//             alert(t);
//         }

//     }
// }

// r.open("POST", "addProductProcess.php", true);
// r.send(f);

// }

function addProduct() {
    var title = document.getElementById("title");
    var desc = document.getElementById("desc");
    var category = document.getElementById("category");
    var dwc = document.getElementById("dwc");
    var doc = document.getElementById("doc");

    var condition = 0;
    if (document.getElementById("b").checked) {
        condition = 1; // Brand new
    } else if (document.getElementById("u").checked) {
        condition = 2; // Used
    }

    var image1 = document.getElementById("i0");
    var image2 = document.getElementById("i1");
    var image3 = document.getElementById("i2");
    var clr = document.getElementById("clr");
    var brand = document.getElementById("brand");
    var qty = document.getElementById("qty");
    var model = document.getElementById("model");
    var cost = document.getElementById("cost");

    var f = new FormData();
    f.append("t", title.value);
    f.append("desc", desc.value);
    f.append("ca", category.value);
    f.append("dwc", dwc.value);
    f.append("doc", doc.value);
    f.append("image1", image1.files[0]); // Corrected from image1.value to image1.files[0]
    f.append("image2", image2.files[0]);
    f.append("image3", image3.files[0]);
    f.append("col", clr.value);
    f.append("b", brand.value);
    f.append("qty", qty.value);
    f.append("m", model.value);
    f.append("con", condition);
    f.append("cost", cost.value);

    var r = new XMLHttpRequest();
    r.onreadystatechange = function () {
        if (r.readyState == 4 && r.status == 200) {
            var t = r.responseText;
            if (t == "Product images saved successfully") {
                window.location.reload();
            } else {
                alert(t);
            }
        }
    }

    r.open("POST", "addProductProcess.php", true);
    r.send(f);
}


function change() {

    window.location = "home.php";
}
function deleteFromCart(id) {
    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;

            if (t == "Product has been removed") {
                alert(t);
                window.location.reload();
            } else {
                alert(t);
            }
        }
    }

    r.open("GET", "removeCartProcess.php?id=" + id, true);
    r.send();
}



function Back() {
    window.location = "index.php";
}


var av;
function adminVerification() {
    var email = document.getElementById("e");

    var f = new FormData();
    f.append("e", email.value);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "Success") {
                var adminVerificationModal = document.getElementById("verificationModal");
                av = new bootstrap.Modal(adminVerificationModal);
                av.show();
            } else {
                alert(t);
            }
        }
    }

    r.open("POST", "adminVerificationProcess.php", true);
    r.send(f);
}

function verify() {
    var verification = document.getElementById("vcode");

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "success") {
                av.hide();
                window.location = "admin_dashboard.php";
            } else {
                alert(t);
            }

        }
    }

    r.open("GET", "verificationProcess.php?v=" + verification.value, true);
    r.send();
}

function subject() {
    alert("Sorry You Can't Change This subject You Required Fill Other Sections");
}

function blockUser(email) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.readyState == 4) {
            var txt = request.responseText;
            if (txt == "blocked") {
                document.getElementById("ub" + email).innerHTML = "Unblock";
                document.getElementById("ub" + email).classList = "btn btn-success";
            } else if (txt == "unblocked") {
                document.getElementById("ub" + email).innerHTML = "Block";
                document.getElementById("ub" + email).classList = "btn btn-danger";
            } else {
                alert(txt);
            }
        }
    }

    request.open("GET", "userBlockProcess.php?email=" + email, true);
    request.send();

}
function advancedSearch(x) {
    var txt = document.getElementById("t");
    var category = document.getElementById("c1");
    var brand = document.getElementById("b1");
    var model = document.getElementById("m");
    var condition = document.getElementById("c2");
    var color = document.getElementById("c3");
    var from = document.getElementById("pf");
    var to = document.getElementById("pt");
    var sort = document.getElementById("s");

    var f = new FormData();
    f.append("t", txt.value);
    f.append("cat", category.value);
    f.append("b", brand.value);
    f.append("m", model.value);
    f.append("con", condition.value);
    f.append("col", color.value);
    f.append("pf", from.value);
    f.append("to", to.value);
    f.append("s", sort.value);
    f.append("page", x);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            document.getElementById("view_area").innerHTML = t;
        }
    }

    r.open("POST", "advancedSearchProcess.php", true);
    r.send(f);

}

function loadMainImg(id) {
    var sample_img = document.getElementById("productImg" + id).src;
    var main_img = document.getElementById("mainProductImg");

    main_img.style.backgroundImage = "url(" + sample_img + ")";
}

function basicSearch(x) {
    var txt = document.getElementById("basic_search_txt");
    var select = document.getElementById("select");

    var f = new FormData();
    f.append("t", txt.value);
    f.append("s", select.value);
    f.append("page", x);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            document.getElementById("basicSearchResult").innerHTML = t;
        }
    }

    r.open("POST", "basicSearchProcess.php", true);
    r.send(f);

}

function addtocart(id) {

    // alert(id);
    // alert("ok");
    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            alert(t);
            window.location("cart.php");
        }
    }

    r.open("GET", "addToCartProcess.php?id=" + id, true);
    r.send();
}
function addtocart_from_watchlist(id) {


    // alert("Ok");

    // alert(id);
    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            alert(t);
            window.location("cart.php");
        }
    }

    r.open("GET", "addToCartProcess.php?id=" + id, true);
    r.send();
}


function subscribe() {

    var email = document.getElementById("email3");

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "Success") {

                alert("Verification code has sent to your Email. Please check your inbox");
            } else {
                alert(t);
            }

        }
    }

    r.open("GET", "subscribesendprocess.php?e=" + email.value, true);
    r.send();

}
var vm;
function verify1() {

    // alert("Ok");

    var email = document.getElementById("email3");


    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "Success") {

                alert("Verification code has sent to your Email. Please check your inbox");


            } else {
                alert(t);
            }

        }
    }

    r.open("GET", "verifyProcess.php?e=" + email.value, true);
    r.send();


}
function nic() {
    var nicValue = document.getElementById("nic1");


    var f = new FormData();
    f.append("nicValue", nicValue.value);



    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "success") {
                window.location = "home.php";
            } else {
                alert(t);
            }
        }
    }

    r.open("POST", "nicaddProcess.php", true);
    r.send(f);
}


function addToWatchlist(id) {

    var r = new XMLHttpRequest();

    r.onreadystatechange = function () {
        if (r.readyState == 4) {
            var t = r.responseText;
            if (t == "added") {
                document.getElementById("heart" + id).style.className = "text-danger";
                window.location.reload();
            } else if (t == "removed") {
                document.getElementById("heart" + id).style.className = "text-dark";
                window.location.reload();
            } else {
                alert(t);
            }
        }
    }

    r.open("GET", "addToWatchlistProcess.php?id=" + id, true);
    r.send();

}


// function checkout() {
//     var f = new FormData();
//     f.append("cart", true);

//     var request = new XMLHttpRequest();
//     request.onreadystatechange = function () {
//         if (request.readyState == 4 && request.status == 200) {
//             var response = request.responseText;
//             // alert(response);
//             var payment = JSON.parse(response);
//             doCheckout(payment, "checkoutProcess.php");
//         }
//     };

//     request.open("POST", "paymentProcess.php", true);
//     request.send(f);


// }

// function doCheckout(payment, path) {

//   // Payment completed. It can be a successful failure.
//   payhere.onCompleted = function onCompleted(orderId) {
//     console.log("Payment completed. OrderID:" + orderId);

//      var f = new FormData();
//         f.append("payment", JSON.stringify(payment));

//         var request = new XMLHttpRequest();
//         request.onreadystatechange = function () {
//             if (request.readyState == 4 & request.status == 200) {
//                 var responce = request.responseText;
//                 var order = JSON.parse(responce);
//                     // alert(responce)
//                 if (order.resp == "Success") {
//                     reload();
//                     console.log("Order completed with ID: " + order.order_id);
//                     window.location = "invoice.php?orderId=" + order.order_id; // Fixed key name
//                 } else {
//                     alert(responce);
//                 }

//             }
//         };

//         request.open("POST", path, true);
//         request.send(f);
//     };
//     // Note: validate the payment and show success or failure page to the customer


// // Payment window closed
// payhere.onDismissed = function onDismissed() {
//     // Note: Prompt user to pay again or show an error page
//     console.log("Payment dismissed");
// };

// // Error occurred
// payhere.onError = function onError(error) {
//     // Note: show an error page
//     console.log("Error:"  + error);
// };

// // Show the payhere.js popup, when "PayHere Pay" is clicked
// // document.getElementById('payhere-payment').onclick = function (e) {
//     payhere.startPayment(payment);
// };

// function buyNow(stockId) {
//     // alert(stockId);
//     var qty = document.getElementById("qty");

//     if (qty.value > 0) {

//         var f = new FormData();
//         f.append("cart", false);
//         f.append("stockId",stockId);
//         f.append("qty",qty.value);

//         var request = new XMLHttpRequest();
//         request.onreadystatechange = function () {
//             if (request.readyState == 4 && request.status == 200) {
//                 var responce = request.responseText;
//                 // alert(responce);
//                 var payment = JSON.parse(responce);
//                 payment.stock_id = stockId;
//                 payment.qty = qty.value;
//                 doCheckout(payment,"buynowProcess.php");
//             }
//         }

//         request.open("POST","paymentProcess.php",true);
//         request.send(f);

//     } else {
//         alert("Please enter valid quantity");
//     }
// }



//today code
function buyNow(id) {
    var qty = document.getElementById("qty_input").value;

    var r = new XMLHttpRequest();

    r.onreadystatechange = function() {
        if (r.readyState == 4) {
            if (r.status == 200) {
                var t = r.responseText;
                try {
                    var obj = JSON.parse(t);

                    if (obj == "1") {
                        alert("Please login.");
                        window.location = "index.php";
                    } else if (obj == "2") {
                        alert("Please update your profile");
                        window.location = "userProfile.php";
                    } else {
                        var mail = obj["umail"];
                        var amount = obj["amount"];

                        payhere.onCompleted = function onCompleted(orderId) {
                            console.log("Payment completed. OrderID:" + orderId);
                            saveInvoice(orderId, id, mail, amount, qty);
                        };

                        payhere.onDismissed = function onDismissed() {
                            console.log("Payment dismissed");
                        };

                        payhere.onError = function onError(error) {
                            console.log("Error:" + error);
                        };

                        var payment = {
                            "sandbox": true,
                            "merchant_id": "1227811", // Replace with your Merchant ID
                            // "merchant_secret": 'Move this to server-side', // Do not include this on client-side
                            "return_url": "http://localhost/store_3/shop-simple-product.php?id=" + id, // Important
                            "cancel_url": "http://localhost/store_3/shop-simple-product.php?id=" + id, // Important
                            "notify_url": "http://sample.com/notify",
                            "order_id": obj["id"],
                            "items": obj["item"],
                            "amount": amount,
                            "currency": "LKR",
                            "hash": obj["hash"], // Ensure this is provided by the backend
                            "first_name": obj["fname"],
                            "last_name": obj["lname"],
                            "email": mail,
                            "phone": obj["mobile"],
                            "address": obj["address"],
                            "city": obj["city"],
                            "country": "Sri Lanka",
                            "delivery_address": obj["address"],
                            "delivery_city": obj["city"],
                            "delivery_country": "Sri Lanka",
                            "custom_1": "",
                            "custom_2": ""
                        };

                        payhere.startPayment(payment);
                    }
                } catch (e) {
                    console.error("Error parsing response:", e);
                    alert("There was an error processing your payment. Please try again.");
                }
            } else {
                console.error("Error with request:", r.status, r.statusText);
                alert("There was an error processing your request. Please try again.");
            }
        }
    };

    r.open("GET", "payhereprocess.php?id=" + id + "&qty=" + qty, true);
    r.send();
}



function saveInvoice(orderId,id,mail,amount,qty){

    var f = new FormData();
    f.append("o",orderId);
    f.append("i",id);
    f.append("m",mail);
    f.append("a",amount);
    f.append("q",qty);

    var r = new XMLHttpRequest();

    r.onreadystatechange = function (){
        if(r.readyState == 4){
            var t = r.responseText;
            if(t == "1"){

                window.location = "invoice.php?id="+orderId;

            }else{
                alert (t);
            }
        }
    }

    r.open("POST","saveInvoice.php",true);
    r.send(f);

}


function print(){
    var restorepage = document.body.innerHTML;
    var page = document.getElementById("page").innerHTML;
    document.body.innerHTML = page;
    window.print();
    document.body.innerHTML = restorepage;
}
