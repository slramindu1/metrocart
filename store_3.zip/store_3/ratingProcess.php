<?php
require "connection.php";

if (isset($_POST["pid"])) {
    $pid = $_POST["pid"];
}

$rating_select = $_POST["rating_select"];
$customer_comment = $_POST["customer_comment"];
$email3 = $_POST["email3"];

if (empty($customer_comment)) {
    echo "Please enter your Review!";
} else if (strlen($customer_comment) > 30) {
    echo "Review must have LESS THAN 30 characters!";
} else if (empty($email3)) {
    echo "Please enter your Email address!";
} else if (strlen($email3) > 100) {
    echo "Email must have LESS THAN 100 characters!";
} else if (!filter_var($email3, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid Email address!";
} else {
    $rs = Database::search("SELECT * FROM `feedback` WHERE `users_email`='" . $email3 . "'");
    $n = $rs->num_rows;

    if ($n > 0) {
        echo "You can only add 1 comment.";
    } else {
        $d = new DateTime();
        $tz = new DateTimeZone("Asia/Colombo");
        $d->setTimezone($tz);
        $date = $d->format("Y-m-d H:i:s");

        Database::iud("INSERT INTO `feedback` 
        (`description`,`date`,`product_id`,`users_email`,`rating_id`)
        VALUES ('" . $customer_comment . "','" . $date . "','" . $pid . "','" . $email3 . "','" . $rating_select . "')");

        echo "success";
    }
}
?>
