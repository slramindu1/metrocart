<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profle </title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

    <!-- CSS
      ============================================ -->

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/icofont.css" />

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/nivo-slider.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/percircle.css" />

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>
    <?php
    include "headername.php";
    require "connection.php";
    ?>
    <?php



    if (isset($_SESSION["u"])) {

        $email = $_SESSION["u"]["email"];

        // $details_rs = Database::search("SELECT * FROM `users` INNER JOIN `profile_image` ON
        // users.email=profile_image.users_email INNER JOIN `user_has_address` ON 
        // users.email=user_has_address.users_email INNER JOIN `city` ON 
        // user_has_address.city_id=city.id INNER JOIN `district` ON 
        // city.district_id=district.id INNER JOIN `province` ON 
        // district.province_id=province.id INNER JOIN `gender` ON 
        // gender.id=users.gender_id WHERE `email`='".$email."'");

        $details_rs = Database::search("SELECT * FROM `users` INNER JOIN `gender` ON 
gender.id=users.gender_id WHERE `email`='" . $email . "'");

        $image_rs = Database::search("SELECT * FROM `profile_image` WHERE `users_email`='" . $email . "'");

        $address_rs = Database::search("SELECT * FROM `users_has_address` INNER JOIN `city` ON 
users_has_address.city_city_id=city_city_id INNER JOIN `district` ON 
city.district_district_id=district.district_id INNER JOIN `province` ON 
district.province_province_id=province.province_id WHERE `users_email`='" . $email . "'");

        $details = $details_rs->fetch_assoc();
        $image_details = $image_rs->fetch_assoc();
        $address_details = $address_rs->fetch_assoc();

    ?>

        <div class="modal" tabindex="-1" id="VerifyModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Forgot Password</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <div class="row g-3">

                            

                            <div class="col-12">
                                <label class="form-label">Verification Code</label>
                                <input type="text" class="form-control" id="vc" />
                            </div>

                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="verify2();">Verify Account</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="container" style="margin-top: 300px;">
            <form>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="email3" aria-describedby="emailHelp" placeholder="Enter email" value="<?php echo $details["email"]; ?>" readonly>
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>

                
            </form>
            <button type="submit" class="btn btn-primary" onclick="1();">Submit</button>
        </div>




    <?php

    } else {

        header("Location:home.php");
    }

    ?>
    <!-- Vendors JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <!-- Plugins JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.mixitup.min.js"></script>
    <script src="assets/js/jquery-ui.min.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/jquery.countdown.min.js"></script>
    <script src="assets/js/jquery.nivo.slider.pack.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="https://kit.fontawesome.com/02566f2f41.js" crossorigin="anonymous"></script>
    <!-- Activation JS -->
    <script src="assets/js/main.js"></script>
    <script src="script.js"></script>

</body>