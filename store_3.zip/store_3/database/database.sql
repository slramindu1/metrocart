-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.33 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.7.0.6850
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for gadget_hub
CREATE DATABASE IF NOT EXISTS `gadget_hub` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `gadget_hub`;

-- Dumping structure for table gadget_hub.2_step_verify
CREATE TABLE IF NOT EXISTS `2_step_verify` (
  `id` int NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.2_step_verify: ~2 rows (approximately)
INSERT INTO `2_step_verify` (`id`, `status`) VALUES
	(0, 'Deactive'),
	(1, 'Active');

-- Dumping structure for table gadget_hub.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(100) NOT NULL,
  `fname` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `lname` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `verification_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.admin: ~2 rows (approximately)
INSERT INTO `admin` (`email`, `fname`, `lname`, `verification_code`) VALUES
	('chandrakantha476@gmail.com', 'Ramindu', 'Ravihansa', '65130acac936d'),
	('ramindu.jiat@gmail.com', 'Ramindu', 'Ravihansa', '66b5d495a7dc7');

-- Dumping structure for table gadget_hub.all_category
CREATE TABLE IF NOT EXISTS `all_category` (
  `id` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.all_category: ~0 rows (approximately)
INSERT INTO `all_category` (`id`, `name`) VALUES
	(1, 'All');

-- Dumping structure for table gadget_hub.best_selling
CREATE TABLE IF NOT EXISTS `best_selling` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `All_Category_id` int NOT NULL,
  `datetime_added` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Best Selling_product1_idx` (`product_id`),
  KEY `fk_Best_Selling_All_Category1_idx` (`All_Category_id`),
  CONSTRAINT `fk_Best Selling_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_Best_Selling_All_Category1` FOREIGN KEY (`All_Category_id`) REFERENCES `all_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.best_selling: ~1 rows (approximately)

-- Dumping structure for table gadget_hub.brand
CREATE TABLE IF NOT EXISTS `brand` (
  `brand_id` int NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.brand: ~0 rows (approximately)
INSERT INTO `brand` (`brand_id`, `brand_name`) VALUES
	(1, 'samsung');

-- Dumping structure for table gadget_hub.brand_has_category
CREATE TABLE IF NOT EXISTS `brand_has_category` (
  `brand_brand_id` int NOT NULL,
  `category_cat_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `fk_brand_has_category_category1_idx` (`category_cat_id`),
  KEY `fk_brand_has_category_brand1_idx` (`brand_brand_id`),
  CONSTRAINT `fk_brand_has_category_brand1` FOREIGN KEY (`brand_brand_id`) REFERENCES `brand` (`brand_id`),
  CONSTRAINT `fk_brand_has_category_category1` FOREIGN KEY (`category_cat_id`) REFERENCES `category` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.brand_has_category: ~0 rows (approximately)
INSERT INTO `brand_has_category` (`brand_brand_id`, `category_cat_id`, `id`) VALUES
	(1, 1, 1);

-- Dumping structure for table gadget_hub.cart
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qty` int NOT NULL,
  `product_id` int NOT NULL,
  `users_email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cart_product1_idx` (`product_id`),
  KEY `fk_cart_users1_idx` (`users_email`),
  CONSTRAINT `fk_cart_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_cart_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.cart: ~4 rows (approximately)
INSERT INTO `cart` (`id`, `qty`, `product_id`, `users_email`) VALUES
	(15, 1, 4, 'hasithaprabhath410@gmail.com'),
	(18, 1, 1, 'hasithaprabhath410@gmail.com'),
	(19, 1, 3, 'hasithaprabhath410@gmail.com'),
	(20, 4, 4, 'ramindu.jiat@gmail.com'),
	(22, 1, 13, 'ramindu.jiat@gmail.com');

-- Dumping structure for table gadget_hub.category
CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.category: ~4 rows (approximately)
INSERT INTO `category` (`cat_id`, `cat_name`) VALUES
	(1, 'mobile'),
	(2, 'laptop'),
	(3, 'tv'),
	(4, 'headset');

-- Dumping structure for table gadget_hub.city
CREATE TABLE IF NOT EXISTS `city` (
  `city_id` int NOT NULL AUTO_INCREMENT,
  `city_name` varchar(45) DEFAULT NULL,
  `district_district_id` int NOT NULL,
  PRIMARY KEY (`city_id`),
  KEY `fk_city_district1_idx` (`district_district_id`),
  CONSTRAINT `fk_city_district1` FOREIGN KEY (`district_district_id`) REFERENCES `district` (`district_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.city: ~0 rows (approximately)
INSERT INTO `city` (`city_id`, `city_name`, `district_district_id`) VALUES
	(1, 'colombo', 1);

-- Dumping structure for table gadget_hub.color
CREATE TABLE IF NOT EXISTS `color` (
  `clr_id` int NOT NULL AUTO_INCREMENT,
  `clr_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`clr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.color: ~0 rows (approximately)
INSERT INTO `color` (`clr_id`, `clr_name`) VALUES
	(1, 'black');

-- Dumping structure for table gadget_hub.comments
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `comment` text NOT NULL,
  `review` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `users_email` varchar(100) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_users2_idx` (`users_email`),
  CONSTRAINT `fk_comments_users2` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.comments: ~0 rows (approximately)

-- Dumping structure for table gadget_hub.condition
CREATE TABLE IF NOT EXISTS `condition` (
  `condition_id` int NOT NULL AUTO_INCREMENT,
  `condition_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`condition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.condition: ~0 rows (approximately)
INSERT INTO `condition` (`condition_id`, `condition_name`) VALUES
	(1, 'not return');

-- Dumping structure for table gadget_hub.district
CREATE TABLE IF NOT EXISTS `district` (
  `district_id` int NOT NULL AUTO_INCREMENT,
  `district_name` varchar(45) DEFAULT NULL,
  `province_province_id` int NOT NULL,
  PRIMARY KEY (`district_id`),
  KEY `fk_district_province1_idx` (`province_province_id`),
  CONSTRAINT `fk_district_province1` FOREIGN KEY (`province_province_id`) REFERENCES `province` (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.district: ~0 rows (approximately)
INSERT INTO `district` (`district_id`, `district_name`, `province_province_id`) VALUES
	(1, 'colombo', 1);

-- Dumping structure for table gadget_hub.feedback
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(45) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `product_id` int NOT NULL,
  `users_email` varchar(100) NOT NULL,
  `rating_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_product1_idx` (`product_id`),
  KEY `fk_comments_users1_idx` (`users_email`),
  KEY `fk_feedback_rating1_idx` (`rating_id`),
  CONSTRAINT `fk_comments_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_comments_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`),
  CONSTRAINT `fk_feedback_rating1` FOREIGN KEY (`rating_id`) REFERENCES `rating` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.feedback: ~0 rows (approximately)
INSERT INTO `feedback` (`id`, `description`, `date`, `product_id`, `users_email`, `rating_id`) VALUES
	(5, 'wasd', '2024-08-01 12:11:46', 4, 'ramindu.jiat@gmail.com', 1);

-- Dumping structure for table gadget_hub.gender
CREATE TABLE IF NOT EXISTS `gender` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gender_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.gender: ~1 rows (approximately)
INSERT INTO `gender` (`id`, `gender_name`) VALUES
	(1, 'male'),
	(2, 'female');

-- Dumping structure for table gadget_hub.invoice
CREATE TABLE IF NOT EXISTS `invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `total` double DEFAULT NULL,
  `qty` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `users_email` varchar(100) NOT NULL,
  `product_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_invoice_users1_idx` (`users_email`),
  KEY `fk_invoice_product1_idx` (`product_id`),
  CONSTRAINT `fk_invoice_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_invoice_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.invoice: ~2 rows (approximately)
INSERT INTO `invoice` (`id`, `order_id`, `date`, `time`, `total`, `qty`, `status`, `users_email`, `product_id`) VALUES
	(1, '1299', '2024-08-09', '12:44:36', 35500, '1', 'shipped', 'ramindu.jiat@gmail.com', 3),
	(2, '66b5d27776af0', '2024-08-09', NULL, 35500, '1', 'delivering', 'ramindu.jiat@gmail.com', 4);

-- Dumping structure for table gadget_hub.messages
CREATE TABLE IF NOT EXISTS `messages` (
  `msg_id` int NOT NULL AUTO_INCREMENT,
  `incoming_msg_id` int NOT NULL,
  `outgoing_msg_id` int NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table gadget_hub.messages: ~0 rows (approximately)

-- Dumping structure for table gadget_hub.model
CREATE TABLE IF NOT EXISTS `model` (
  `model_id` int NOT NULL AUTO_INCREMENT,
  `model_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.model: ~0 rows (approximately)
INSERT INTO `model` (`model_id`, `model_name`) VALUES
	(1, 'samsung');

-- Dumping structure for table gadget_hub.model_has_brand
CREATE TABLE IF NOT EXISTS `model_has_brand` (
  `model_model_id` int NOT NULL,
  `brand_brand_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `fk_model_has_brand_brand1_idx` (`brand_brand_id`),
  KEY `fk_model_has_brand_model1_idx` (`model_model_id`),
  CONSTRAINT `fk_model_has_brand_brand1` FOREIGN KEY (`brand_brand_id`) REFERENCES `brand` (`brand_id`),
  CONSTRAINT `fk_model_has_brand_model1` FOREIGN KEY (`model_model_id`) REFERENCES `model` (`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.model_has_brand: ~0 rows (approximately)
INSERT INTO `model_has_brand` (`model_model_id`, `brand_brand_id`, `id`) VALUES
	(1, 1, 1);

-- Dumping structure for table gadget_hub.product
CREATE TABLE IF NOT EXISTS `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` double DEFAULT NULL,
  `description` text,
  `title` varchar(100) DEFAULT NULL,
  `datetime_added` datetime DEFAULT NULL,
  `delivery_fee_colombo` double DEFAULT NULL,
  `delivery_fee_other` double DEFAULT NULL,
  `category_cat_id` int NOT NULL,
  `model_has_brand_id` int NOT NULL,
  `color_clr_id` int NOT NULL,
  `status_status_id` int NOT NULL,
  `condition_condition_id` int NOT NULL,
  `users_email` varchar(100) NOT NULL,
  `qty` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_category1_idx` (`category_cat_id`),
  KEY `fk_product_model_has_brand1_idx` (`model_has_brand_id`),
  KEY `fk_product_color1_idx` (`color_clr_id`),
  KEY `fk_product_status1_idx` (`status_status_id`),
  KEY `fk_product_condition1_idx` (`condition_condition_id`),
  KEY `fk_product_users1_idx` (`users_email`),
  CONSTRAINT `fk_product_category1` FOREIGN KEY (`category_cat_id`) REFERENCES `category` (`cat_id`),
  CONSTRAINT `fk_product_color1` FOREIGN KEY (`color_clr_id`) REFERENCES `color` (`clr_id`),
  CONSTRAINT `fk_product_condition1` FOREIGN KEY (`condition_condition_id`) REFERENCES `condition` (`condition_id`),
  CONSTRAINT `fk_product_model_has_brand1` FOREIGN KEY (`model_has_brand_id`) REFERENCES `model_has_brand` (`id`),
  CONSTRAINT `fk_product_status1` FOREIGN KEY (`status_status_id`) REFERENCES `status` (`status_id`),
  CONSTRAINT `fk_product_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.product: ~16 rows (approximately)
INSERT INTO `product` (`id`, `price`, `description`, `title`, `datetime_added`, `delivery_fee_colombo`, `delivery_fee_other`, `category_cat_id`, `model_has_brand_id`, `color_clr_id`, `status_status_id`, `condition_condition_id`, `users_email`, `qty`) VALUES
	(1, 350000, 'Dynamic island Stays on top of it all.', 'Apple Iphone 15', '2024-07-30 01:01:33', 5000, 8000, 1, 1, 1, 1, 1, 'ramindu.jiat@gmail.com', '12'),
	(2, 50000, '6.5 inches', 'Galaxy A25 5G', '2024-07-30 01:11:24', 5000, 6000, 1, 1, 1, 1, 1, 'ramindu.jiat@gmail.com', '5'),
	(3, 45000, 'Smooth 6.74″ 90Hz display', 'Redmi 13C', '2024-07-30 01:17:23', 4000, 6500, 1, 1, 1, 1, 1, 'ramindu.jiat@gmail.com', '24'),
	(4, 30000, '6.008 inch HD water-drop notch display', 'ZTE Blade A5', '2024-07-30 01:22:31', 3500, 5500, 1, 1, 1, 1, 1, 'ramindu.jiat@gmail.com', '10'),
	(5, 300000, '– Intel Core i3 – 1215U Processor', 'Dell Inspiron 3520 – i3', '2024-07-30 01:22:31', 5000, 9500, 2, 1, 1, 1, 1, 'ramindu.jiat@gmail.com', '6'),
	(6, 350000, '– Intel Core i7-13620H Processor', 'MSI Katana 15 Gaming B13VGK – i7', '2024-07-30 15:46:17', 5000, 9500, 2, 1, 1, 1, 1, 'ravihansa@gmail.com', '13'),
	(7, 400000, '– Intel Core i5 – 1235U Processor', 'MSI Modern 15 B12M – i5', '2024-07-30 15:46:17', 5000, 9500, 2, 1, 1, 1, 1, 'ravihansa@gmail.com', '24'),
	(8, 450000, '– Intel Core i5 – 1335U Processor', 'Asus Vivobook 15 X1504VA – i5', '2024-07-30 16:04:59', 5000, 9500, 2, 1, 1, 1, 1, 'ravihansa@gmail.com', '43'),
	(9, 50000, 'Model: LT-32N355', 'JVC 32 inch LED TV', '2024-07-30 21:21:26', 3500, 4500, 3, 1, 1, 1, 1, 'ramindu@gmail.com', '15'),
	(10, 46000, 'Model: L43T1S', 'Abans 43 inch FHD Smart TV', '2024-07-30 16:04:54', 5000, 9500, 3, 1, 1, 1, 1, 'ramindu@gmail.com', '12'),
	(11, 271249, 'Model: 55UR7550PSC', 'LG 55 inch UR75 UHD Smart 4K TV (2023)', '2024-07-30 16:04:54', 5000, 9500, 3, 1, 1, 1, 1, 'ramindu@gmail.com', '24'),
	(12, 187999, 'Model: L55T1', 'Abans 55 inch UHD Smart TV', '2024-07-30 16:04:54', 5000, 9500, 3, 1, 1, 1, 1, 'ramindu@gmail.com', '12'),
	(13, 92000, 'Sony', 'SONY WH-ULT900N BC Wireless Noise Canceling Headphones', '2024-07-30 21:41:48', 1000, 3000, 4, 1, 1, 1, 1, 'ramindu.jiat@gmail.com', '10'),
	(14, 75000, 'sony', 'Sony WF-1000XM5 Wireless Noise Canceling Earbuds', '2024-07-30 16:04:54', 2000, 3500, 4, 1, 1, 1, 1, 'ramindu@gmail.com', '20'),
	(15, 35000, 'sony', 'Sony LinkBuds S WF-LS900N Truly Wireless Noise Canceling Earbuds', '2024-07-30 16:04:54', 2000, 3500, 4, 1, 1, 1, 1, 'ramindu@gmail.com', '30'),
	(16, 40000, 'sony', 'Sony WF-L900 LinkBuds True Wireless Earbuds', '2024-07-30 16:04:54', 2000, 3500, 4, 1, 1, 1, 1, 'ramindu@gmail.com', '10');

-- Dumping structure for table gadget_hub.product_img
CREATE TABLE IF NOT EXISTS `product_img` (
  `img_path` varchar(100) NOT NULL,
  `product_id` int NOT NULL,
  PRIMARY KEY (`img_path`),
  KEY `fk_product_img_product1_idx` (`product_id`),
  CONSTRAINT `fk_product_img_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.product_img: ~54 rows (approximately)
INSERT INTO `product_img` (`img_path`, `product_id`) VALUES
	('assets\\images\\product\\iphone15\\iPhone-15-1-768x768.jpg', 1),
	('assets\\images\\product\\iphone15\\iPhone-15-2-768x768.jpg', 1),
	('assets\\images\\product\\iphone15\\iPhone-15-3-768x768.jpg', 1),
	('assets\\images\\product\\iphone15\\iPhone-15-5-768x768.jpg', 1),
	('assets\\images\\product\\Galaxy A25 5G\\A25-1-768x768.jpg', 2),
	('assets\\images\\product\\Galaxy A25 5G\\A25-2-768x768.jpg', 2),
	('assets\\images\\product\\Galaxy A25 5G\\A25-4-768x768.jpg', 2),
	('assets\\images\\product\\Galaxy A25 5G\\A25-5-768x768.jpg', 2),
	('assets\\images\\product\\Redmi 13 C\\Redmi-13C-1-768x768.jpg', 3),
	('assets\\images\\product\\Redmi 13 C\\Redmi-13C-Blue-768x768.jpg', 3),
	('assets\\images\\product\\Redmi 13 C\\Redmi-13C-Green-768x768.jpg', 3),
	('assets\\images\\product\\Redmi 13 C\\Redmi-Note-13-Pro-Fusion-600x600.jpg', 3),
	('assets\\images\\product\\ZTE Blade A5\\ZTE-A5-2020-3-768x768.jpg', 4),
	('assets\\images\\product\\ZTE Blade A5\\ZTE-A5-2020-4-768x768.jpg', 4),
	('assets\\images\\product\\ZTE Blade A5\\ZTE-A5-2020-Blue-768x768.jpg', 4),
	('assets\\images\\product\\ZTE Blade A5\\ZTE-A5-2020-Green-768x768.jpg', 4),
	('assets\\images\\product\\Dell Inspiron 3520 – i3\\Dell-Inspiron-3520-1-1.jpg', 5),
	('assets\\images\\product\\Dell Inspiron 3520 – i3\\Dell-Inspiron-3520-2-1.jpg', 5),
	('assets\\images\\product\\Dell Inspiron 3520 – i3\\Dell-Inspiron-3520-2.jpg', 5),
	('assets\\images\\product\\Dell Inspiron 3520 – i3\\Dell-Inspiron-3520-black.jpg', 5),
	('assets\\images\\product\\MSI Katana 15 Gaming B13VGK – i7\\MSI-Katana-15-Gaming-B13VGK-03-1.webp', 6),
	('assets\\images\\product\\MSI Katana 15 Gaming B13VGK – i7\\MSI-Katana-15-Gaming-B13VGK-04-1.webp', 6),
	('assets\\images\\product\\MSI Katana 15 Gaming B13VGK – i7\\MSI-Katana-15-Gaming-B13VGK-05-1.webp', 6),
	('assets\\images\\product\\MSI Katana 15 Gaming B13VGK – i7\\MSI-Katana-15-Gaming-B13VGK-1.webp', 6),
	('assets\\images\\product\\MSI Modern 15 B12M – i5\\MSI-Modern-15-B12M-full.jpg', 7),
	('assets\\images\\product\\MSI Modern 15 B12M – i5\\MSI-Modern-15-B12M-left.jpg', 7),
	('assets\\images\\product\\MSI Modern 15 B12M – i5\\MSI-Modern-15-B12M-side.jpg', 7),
	('assets\\images\\product\\MSI Modern 15 B12M – i5\\MSI-Modern-15-B12M-–-i5.webp', 7),
	('assets\\images\\product\\Asus Vivobook 15 X1504VA – i5\\lap1.webp', 8),
	('assets\\images\\product\\Asus Vivobook 15 X1504VA – i5\\lap2.jpg', 8),
	('assets\\images\\product\\Asus Vivobook 15 X1504VA – i5\\lap3.jpg', 8),
	('assets\\images\\product\\Asus Vivobook 15 X1504VA – i5\\lap4.webp', 8),
	('assets\\images\\product\\JVC 32 inch LED TV\\tv1.png', 9),
	('assets\\images\\product\\JVC 32 inch LED TV\\tv2.png', 9),
	('assets\\images\\product\\JVC 32 inch LED TV\\tv3.png', 9),
	('assets\\images\\product\\Abans 43 inch FHD Smart TV\\tv1.png', 10),
	('assets\\images\\product\\Abans 43 inch FHD Smart TV\\tv2.png', 10),
	('assets\\images\\product\\LG 55 inch UR75 UHD Smart 4K TV (2023)\\tv1.png', 11),
	('assets\\images\\product\\LG 55 inch UR75 UHD Smart 4K TV (2023)\\tv2.png', 11),
	('assets\\images\\product\\LG 55 inch UR75 UHD Smart 4K TV (2023)\\tv3.png', 11),
	('assets\\images\\product\\Abans 55 inch UHD Smart TV\\tv1.png', 12),
	('assets\\images\\product\\Abans 55 inch UHD Smart TV\\tv2.png', 12),
	('assets\\images\\product\\SONY WH-ULT900N BC Wireless Noise Canceling Headphones\\1.jpg', 13),
	('assets\\images\\product\\SONY WH-ULT900N BC Wireless Noise Canceling Headphones\\2.jpg', 13),
	('assets\\images\\product\\SONY WH-ULT900N BC Wireless Noise Canceling Headphones\\3.jpg', 13),
	('assets\\images\\product\\Sony WF-1000XM5 Wireless Noise Canceling Earbuds\\1.jpg', 14),
	('assets\\images\\product\\Sony WF-1000XM5 Wireless Noise Canceling Earbuds\\2.jpg', 14),
	('assets\\images\\product\\Sony WF-1000XM5 Wireless Noise Canceling Earbuds\\3.jpg', 14),
	('assets\\images\\product\\Sony WF-1000XM5 Wireless Noise Canceling Earbuds\\4.jpg', 14),
	('assets\\images\\product\\Sony LinkBuds S WF-LS900N Truly Wireless Noise Canceling Earbuds\\1.jpg', 15),
	('assets\\images\\product\\Sony LinkBuds S WF-LS900N Truly Wireless Noise Canceling Earbuds\\2.jpg', 15),
	('assets\\images\\product\\Sony LinkBuds S WF-LS900N Truly Wireless Noise Canceling Earbuds\\3.jpg', 15),
	('assets\\images\\product\\Sony LinkBuds S WF-LS900N Truly Wireless Noise Canceling Earbuds\\4.jpg', 15),
	('assets\\images\\product\\Sony WF-L900 LinkBuds True Wireless Earbuds\\1.jpg', 16),
	('assets\\images\\product\\Sony WF-L900 LinkBuds True Wireless Earbuds\\2.jpg', 16),
	('assets\\images\\product\\Sony WF-L900 LinkBuds True Wireless Earbuds\\3.jpg', 16),
	('assets\\images\\product\\Sony WF-L900 LinkBuds True Wireless Earbuds\\4.jpg', 16),
	('assets\\images\\product\\Sony WF-L900 LinkBuds True Wireless Earbuds\\5.jpg', 16),
	('assets\\images\\product\\Sony WF-L900 LinkBuds True Wireless Earbuds\\6.jpg', 16);

-- Dumping structure for table gadget_hub.profile_image
CREATE TABLE IF NOT EXISTS `profile_image` (
  `path` varchar(100) NOT NULL,
  `users_email` varchar(100) NOT NULL,
  `path_banner` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`path`),
  KEY `fk_profile_img_users1_idx` (`users_email`),
  CONSTRAINT `fk_profile_img_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.profile_image: ~2 rows (approximately)
INSERT INTO `profile_image` (`path`, `users_email`, `path_banner`) VALUES
	('', 'ramindu.jiat@gmail.com', ''),
	('assets\\images\\team\\2.jpg', 'ramindu@gmail.com', '');

-- Dumping structure for table gadget_hub.province
CREATE TABLE IF NOT EXISTS `province` (
  `province_id` int NOT NULL AUTO_INCREMENT,
  `province_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.province: ~0 rows (approximately)
INSERT INTO `province` (`province_id`, `province_name`) VALUES
	(1, 'western');

-- Dumping structure for table gadget_hub.rating
CREATE TABLE IF NOT EXISTS `rating` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rating_count` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.rating: ~5 rows (approximately)
INSERT INTO `rating` (`id`, `rating_count`) VALUES
	(1, 1),
	(2, 2),
	(3, 3),
	(4, 4),
	(5, 5);

-- Dumping structure for table gadget_hub.recent
CREATE TABLE IF NOT EXISTS `recent` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `users_email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_recent_product1_idx` (`product_id`),
  KEY `fk_recent_users1_idx` (`users_email`),
  CONSTRAINT `fk_recent_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_recent_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.recent: ~0 rows (approximately)
INSERT INTO `recent` (`id`, `product_id`, `users_email`) VALUES
	(5, 3, 'ramindu.jiat@gmail.com');

-- Dumping structure for table gadget_hub.report_topic
CREATE TABLE IF NOT EXISTS `report_topic` (
  `id` int NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.report_topic: ~4 rows (approximately)
INSERT INTO `report_topic` (`id`, `name`) VALUES
	(1, 'invalid Email'),
	(2, ' Important Name'),
	(3, 'Toxi Behaviour'),
	(4, 'Not Delivery Product'),
	(5, 'Seller Get Delivery Charges');

-- Dumping structure for table gadget_hub.security
CREATE TABLE IF NOT EXISTS `security` (
  `id` int NOT NULL,
  `security_name` varchar(45) DEFAULT NULL,
  `security_status` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.security: ~0 rows (approximately)
INSERT INTO `security` (`id`, `security_name`, `security_status`) VALUES
	(1, '2 Step Verification', 1);

-- Dumping structure for table gadget_hub.seller_report
CREATE TABLE IF NOT EXISTS `seller_report` (
  `users_email` varchar(100) NOT NULL,
  `report_topic_id` int NOT NULL,
  `Reported_Date` datetime DEFAULT NULL,
  KEY `fk_Seller_Report_users1_idx` (`users_email`),
  KEY `fk_seller_report_report_topic1_idx` (`report_topic_id`),
  CONSTRAINT `fk_seller_report_report_topic1` FOREIGN KEY (`report_topic_id`) REFERENCES `report_topic` (`id`),
  CONSTRAINT `fk_Seller_Report_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.seller_report: ~1 rows (approximately)

-- Dumping structure for table gadget_hub.status
CREATE TABLE IF NOT EXISTS `status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `status_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.status: ~0 rows (approximately)
INSERT INTO `status` (`status_id`, `status_name`) VALUES
	(1, 'in stock'),
	(2, 'Out Of Stock');

-- Dumping structure for table gadget_hub.sub_cateogry
CREATE TABLE IF NOT EXISTS `sub_cateogry` (
  `id` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `category_cat_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sub_cateogry_category1_idx` (`category_cat_id`),
  CONSTRAINT `fk_sub_cateogry_category1` FOREIGN KEY (`category_cat_id`) REFERENCES `category` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.sub_cateogry: ~3 rows (approximately)
INSERT INTO `sub_cateogry` (`id`, `name`, `category_cat_id`) VALUES
	(1, 'samsung', 1),
	(2, 'redmi', 1),
	(3, 'nokia', 1);

-- Dumping structure for table gadget_hub.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int DEFAULT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `joined_date` datetime DEFAULT NULL,
  `verification_code` varchar(20) DEFAULT NULL,
  `status` int NOT NULL,
  `subscribe` int DEFAULT NULL,
  `gender_id` int NOT NULL,
  `verified_batch` int DEFAULT NULL,
  `email_verify` int DEFAULT NULL,
  `verify_account_code` varchar(50) DEFAULT NULL,
  `security_id` int NOT NULL,
  `2_step_verify_id` int NOT NULL,
  `Nic` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`email`),
  KEY `fk_users_gender_idx` (`gender_id`),
  KEY `fk_users_security1_idx` (`security_id`),
  KEY `fk_users_2_step_verify1_idx` (`2_step_verify_id`),
  CONSTRAINT `fk_users_2_step_verify1` FOREIGN KEY (`2_step_verify_id`) REFERENCES `2_step_verify` (`id`),
  CONSTRAINT `fk_users_gender` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`),
  CONSTRAINT `fk_users_security1` FOREIGN KEY (`security_id`) REFERENCES `security` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.users: ~7 rows (approximately)
INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `password`, `mobile`, `joined_date`, `verification_code`, `status`, `subscribe`, `gender_id`, `verified_batch`, `email_verify`, `verify_account_code`, `security_id`, `2_step_verify_id`, `Nic`) VALUES
	(5, 'Ramindu', 'Amarasingha', 'hasithaprabhath410@gmail.com', '123456789', '0776168359', '2024-07-30 22:56:16', NULL, 0, NULL, 1, 1, NULL, NULL, 1, 1, NULL),
	(NULL, 'Ramindu', 'Amarasingha', 'ramindu.jiat12@gmail.com', '*0776*Ramindu', '0776178959', '2024-08-02 07:39:00', NULL, 1, NULL, 1, NULL, NULL, NULL, 1, 1, NULL),
	(1, 'Ramindu', 'Ravihansa', 'ramindu.jiat@gmail.com', '*0776*Ramindu', '0776168954', '2023-09-18 14:45:24', '66ac58d015ebc', 1, 1, 1, 1, 1, NULL, 1, 0, '711751513v'),
	(2, '1234', 'Ravihansa', 'ramindu@gmail.com', '123456789', '0776168954', '2023-09-18 14:45:24', '6513092e0d65b', 1, NULL, 1, 1, NULL, NULL, 0, 0, '711851513v'),
	(3, 'Ravihansa', '1234', 'ravihansa@gmail.com', '123456789', '0779868954', '2023-09-25 20:30:12', NULL, 1, NULL, 1, 1, NULL, NULL, 0, 0, '721751513v'),
	(4, 'Ramindu', 'Ravihansa', 'sprinsec.social@gmail.com', '123456789', '0776168959', '2023-10-02 21:41:21', NULL, 1, NULL, 1, 1, NULL, NULL, 0, 1, '201751513v'),
	(NULL, 'Ramindu', 'Amarasingha', 'xidepi6335@hostlace.com', '*0776*Ramindu', '0776468954', '2024-08-02 13:18:30', NULL, 1, NULL, 1, 1, 1, '9e034b94768d1cbd62f04a59cdffa5924282b446', 1, 1, NULL);

-- Dumping structure for table gadget_hub.users_has_address
CREATE TABLE IF NOT EXISTS `users_has_address` (
  `address_id` int NOT NULL AUTO_INCREMENT,
  `line1` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `line2` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `postal_code` varchar(5) DEFAULT NULL,
  `users_email` varchar(100) NOT NULL,
  `city_city_id` int NOT NULL,
  PRIMARY KEY (`address_id`),
  KEY `fk_users_has_city_city1_idx` (`city_city_id`),
  KEY `fk_users_has_city_users1_idx` (`users_email`),
  CONSTRAINT `fk_users_has_city_city1` FOREIGN KEY (`city_city_id`) REFERENCES `city` (`city_id`),
  CONSTRAINT `fk_users_has_city_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.users_has_address: ~1 rows (approximately)
INSERT INTO `users_has_address` (`address_id`, `line1`, `line2`, `postal_code`, `users_email`, `city_city_id`) VALUES
	(1, '571 Gahanuvala', ' Meegoda', '2255', 'ramindu.jiat@gmail.com', 1);

-- Dumping structure for table gadget_hub.watchlist
CREATE TABLE IF NOT EXISTS `watchlist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `qty` int DEFAULT NULL,
  `product_id` int NOT NULL,
  `users_email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_watchlist_product1_idx` (`product_id`),
  KEY `fk_watchlist_users1_idx` (`users_email`),
  CONSTRAINT `fk_watchlist_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `fk_watchlist_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;

-- Dumping data for table gadget_hub.watchlist: ~3 rows (approximately)
INSERT INTO `watchlist` (`id`, `qty`, `product_id`, `users_email`) VALUES
	(1, 12, 3, 'hasithaprabhath410@gmail.com'),
	(12, 1, 3, 'ramindu.jiat@gmail.com'),
	(13, 1, 4, 'ramindu.jiat@gmail.com');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
