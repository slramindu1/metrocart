<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product </title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

    <!-- CSS
      ============================================ -->

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/icofont.css" />

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/animate.min.css" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/nivo-slider.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/percircle.css" />

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
</head>

<body>


    <?php
    include "headername.php";
    ?>
    <?php require "connection.php";
    ?>
    <br>
    <hr><br>
    <div class="container">
        <div class="row">
            <?php



            if (isset($_SESSION["u"])) {

                $email = $_SESSION["u"]["email"];

                // $details_rs = Database::search("SELECT * FROM `users` INNER JOIN `profile_image` ON
                // users.email=profile_image.users_email INNER JOIN `user_has_address` ON 
                // users.email=user_has_address.users_email INNER JOIN `city` ON 
                // user_has_address.city_id=city.id INNER JOIN `district` ON 
                // city.district_id=district.id INNER JOIN `province` ON 
                // district.province_id=province.id INNER JOIN `gender` ON 
                // gender.id=users.gender_id WHERE `email`='".$email."'");

                $details_rs = Database::search("SELECT * FROM `users` INNER JOIN `gender` ON 
gender.id=users.gender_id WHERE `email`='" . $email . "'");

                $image_rs = Database::search("SELECT * FROM `profile_image` WHERE `users_email`='" . $email . "'");

                $address_rs = Database::search("SELECT * FROM `users_has_address` INNER JOIN `city` ON 
users_has_address.city_city_id=city_city_id INNER JOIN `district` ON 
city.district_district_id=district.district_id INNER JOIN `province` ON 
district.province_province_id=province.province_id WHERE `users_email`='" . $email . "'");

                $details = $details_rs->fetch_assoc();
                $image_details = $image_rs->fetch_assoc();
                $address_details = $address_rs->fetch_assoc();

            ?>

                <div class="col-12">
                    <div class="container">
                        <?php

                        if (!empty($details["verified_batch"])) {

                        ?>
                            <div class="woocommerce-breadcrumb ">
                                <div class="menu">
                                    <ul>
                                        <li><a href="home.php">Home</a></li>
                                        <li><a href="shop.php">Add Product</a></li>

                                    </ul>
                                </div>
                            </div>
                            <div class="col-12">


                                <div class="returning-customer-area p-20 mb-20">
                                    <div class="returning-customer mb-10">
                                        <i class="fa fa-book"></i>
                                        <span>Don't Know How To Add Products</span>
                                        <span class="login-form-click">Click here to Know</span>

                                    </div>
                                    <div class="login-form account-form p-20 clear bg-fff box-shadow">
                                        <div style="font-size: 15px;">Sure, here's a step-by-step description of the "Add Products" page:

                                            1. **Step 1: Click the "Add Products" Button**
                                            - Navigate to the designated section or page within the software or website where you manage products. Locate the prominently displayed "Add Products" button.

                                            2. **Step 2: Accessing the "Add Products" Page**
                                            - Upon clicking the "Add Products" button, the system directs you to a new page or modal window specifically designed for adding new products to the system.

                                            3. **Step 3: Input Product Information**
                                            - The "Add Products" page presents a form or set of input fields. Here, you can enter essential product details such as product name, description, price, category, and any other pertinent information.

                                            4. **Step 4: Uploading Product Images**
                                            - The page allows you to upload images associated with the product, enhancing its visual representation. You can typically upload multiple images to showcase the product from various angles.

                                            5. **Step 5: Specify Product Variations (if applicable)**
                                            - If the product has different variations such as size, color, or other customizable options, this step enables you to specify and configure those variations.

                                            6. **Step 6: Set Inventory and Pricing Details**
                                            - Define the product's stock availability, including initial stock, restocking options, and stock notifications. Additionally, set the pricing strategy, discounts, or promotions if applicable.

                                            7. **Step 7: Add Additional Product Information**
                                            - Provide any supplementary information related to the product, which may include product tags, SEO metadata, or additional notes for internal use.

                                            8. **Step 8: Save or Submit**
                                            - Once you've completed entering the required product information and settings, there's typically a "Save" or "Submit" button to confirm and add the product to the system.

                                            9. **Step 9: Confirmation and Feedback**
                                            - Upon successful addition, the system usually provides a confirmation message, indicating that the product has been added successfully. It may also offer options to add another product or return to the product management area.

                                            This "Add Products" page streamlines the process of adding new products to the system, making it efficient and user-friendly for managing your product inventory.</div>
                                    </div>

                                </div>
                            </div>
                            <div class="container">
                                <center><img src="assets/images/shoping.png" class="img5"></center>
                                <center> <a href="addproductadd.php" class="btn btn-secondary">Add Product</a></center>
                            </div>

                            


                        <?php
                        } else {
                        ?>



                            <h1 class="text-danger fw-bold">You Are Not A Verfied User</h1>
                            <div style="font-size: 15px;">

                                Thank you for visiting our ecommerce website. To ensure a secure and trustworthy shopping experience, we prioritize the verification of our users. As of now, your account is <span class="text-danger fw-bold">not verified.</span>

                                Verification is a crucial step in establishing trust and safety within our platform. Verified users enjoy various benefits, including enhanced security, faster transactions, and personalized recommendations based on their preferences.

                                To complete the verification process and unlock these advantages, please follow the instructions provided in your account or reach out to our support team for assistance.

                                Thank you for your understanding and cooperation.
                            </div> <br>
                            <hr>
                            <h1 class="text-primary fw-bold">How To Become A Verifed User</h1>
                            <div style="font-size: 15px;">


                                1. **Log In to Your Account**: Visit the ecommerce website and log in using your registered credentials.

                                2. **Access Your Profile**: Navigate to your account profile by clicking on your profile icon or username, usually located at the top right corner of the webpage.

                                3. **Update Your Profile**: Within your profile, review and update your personal information, including your contact details, address, and any other required fields.

                                4. **Provide Necessary Information**: Fill in any additional information requested for verification purposes, such as identification details or payment information.

                                5. **Verify Your Email Address**: If you haven't already done so, verify your email address by clicking on a verification link sent to your registered email.

                                6. **Verify Your Phone Number**: Complete the phone number verification process, which may involve receiving a verification code via SMS and entering it on the website.

                                7. **Upload Required Documents**: If further verification is needed, upload any necessary documents such as a government-issued ID, utility bills, or credit card statements as specified by the website.

                                8. **Submit Verification Request**: After providing all required information and documents, submit a verification request through the designated process provided on the website.

                                9. **Wait for Approval**: Allow some time for the website administrators to review your provided information and documents. The verification process may take a few hours to a few days.

                                10. **Receive Confirmation**: Once your verification is approved, you'll receive a confirmation email or notification confirming your verified user status.

                                11. **Enjoy Verified User Benefits**: As a verified user, you'll now have access to enhanced security features, smoother transactions, and personalized shopping experiences.

                                12. **Keep Your Information Updated**: Ensure to regularly update your profile and review the provided information to maintain your verified user status and enjoy continued benefits.

                                If any specific steps or requirements are provided by the ecommerce website, be sure to follow those instructions accordingly.
                            </div>
                        <?php  } ?>
                    </div>
                </div>
        </div>
    </div>
<?php } ?>
<br><br>
<?php
include "footer.php";

?>



<!-- Vendors JS -->
<script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
<script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

<!-- Plugins JS -->
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/jquery.mixitup.min.js"></script>
<script src="assets/js/jquery-ui.min.js"></script>
<script src="assets/js/jquery.scrollUp.min.js"></script>
<script src="assets/js/jquery.countdown.min.js"></script>
<script src="assets/js/jquery.nivo.slider.pack.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="https://kit.fontawesome.com/02566f2f41.js" crossorigin="anonymous"></script>
<!-- Activation JS -->
<script src="assets/js/main.js"></script>
<script src="script.js"></script>
</body>