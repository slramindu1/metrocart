<!DOCTYPE html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>MetroCart | Login and Register </title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="login_res/img/favicon.png" />
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="login_res/css/bootstrap.min.css" />
  <!-- Fontawesome CSS -->
  <link rel="stylesheet" href="login_res/css/fontawesome-all.min.css" />
  <!-- Flaticon CSS -->
  <link rel="stylesheet" href="login_res/font/flaticon.css" />
  <!-- Google Web Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
  <!-- Custom CSS -->
  <link rel="stylesheet" href="login_res/style.css" />
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->
  <div id="preloader" class="preloader">
    <div class="inner">
      <div class="line1"></div>
      <div class="line2"></div>
      <div class="line3"></div>
    </div>
  </div>
  <div id="wrapper" class="wrapper">
    <div class="fxt-template-animation fxt-template-layout13">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 col-12 order-md-2 fxt-bg-wrap">
            <div class="fxt-bg-img" data-bg-image="login_res/img/figure/bg13-l.jpg">
              <div class="fxt-header">
                <div class="fxt-transformY-50 fxt-transition-delay-1">
                  <a href="index.php" class="fxt-logo"><img src="assets/images/logo/2.png" alt="Logo" /></a>
                </div>
                <div class="fxt-transformY-50 fxt-transition-delay-2">
                  <h1>Welcome To Our  MetroCart</h1>
                </div>
                <div class="fxt-transformY-50 fxt-transition-delay-3">
                  <p>
                    Grursus mal suada faci lisis Lorem ipsum dolarorit more
                    ametion consectetur elit. Vesti at bulum nec odio aea the
                    dumm ipsumm ipsum that dolocons rsus mal suada and
                    fadolorit to the dummy consectetur elit the Lorem Ipsum
                    genera.
                  </p>
                </div>
              </div>
              <ul class="fxt-socials">
                <li class="fxt-facebook fxt-transformY-50 fxt-transition-delay-4">
                  <a href="#" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                </li>
                <li class="fxt-twitter fxt-transformY-50 fxt-transition-delay-5">
                  <a href="#" title="twitter"><i class="fab fa-twitter"></i></a>
                </li>
                <li class="fxt-google fxt-transformY-50 fxt-transition-delay-6">
                  <a href="#" title="google"><i class="fab fa-google-plus-g"></i></a>
                </li>
                <li class="fxt-linkedin fxt-transformY-50 fxt-transition-delay-7">
                  <a href="#" title="linkedin"><i class="fab fa-linkedin-in"></i></a>
                </li>
                <li class="fxt-youtube fxt-transformY-50 fxt-transition-delay-8">
                  <a href="#" title="youtube"><i class="fab fa-youtube"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-6 col-12 order-md-1 fxt-bg-color">
            <div class="fxt-content">
              <h2>Register</h2>
              <div class="fxt-form">
                <div>
                  <div class="form-group">
                    <label for="f_name" class="input-label">First Name</label>
                    <input type="text" id="f_name" class="form-control" name="f_name" placeholder="example name" />
                  </div>
                  <div class="form-group">
                    <label for="l_name" class="input-label">Last Name</label>
                    <input type="text" id="l_name" class="form-control" name="l_name" placeholder="example name" />
                  </div>
                  <div class="form-group">
                    <label for="email" class="input-label">Email Address</label>
                    <input type="email" id="email" class="form-control" name="email" placeholder="demo@gmail.com" />
                  </div>
                  <div class="form-group">
                    <label for="password" class="input-label">Password</label>
                    <input id="password" type="password" class="form-control" name="password" placeholder="********" />
                    <i toggle="#password" class="fa fa-fw fa-eye toggle-password field-icon"></i>
                  </div>
                  <div class="form-group">
                    <label for="mobile" class="input-label">Mobile</label>
                    <input type="text" id="mobile" class="form-control" name="mobile" placeholder="0776168954" />
                  </div>
                  <div class="form-group">
                    <label for="gender" class="input-label">Gender</label>
                    <select class="form-control" id="gender" name="gender">
                      <?php
                      require "connection.php";
                      $rs = Database::search("SELECT * FROM `gender`");
                      while ($d = $rs->fetch_assoc()) {
                        echo "<option value=\"{$d['id']}\">{$d['gender_name']}</option>";
                      }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <button type="button" class="fxt-btn-fill" onclick="register();">Register</button>
                  </div>
                  <div id="msgdiv" class="d-none">
                    <div id="msg" class="alert"></div>
                  </div>
                  <div class="text-center">
                    <p>
                      Have an account?<a href="index.php" class="switcher-text2 inline-text">Log in</a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
  <!-- jquery-->
  <script src="login_res/js/jquery.min.js"></script>
  <!-- Bootstrap js -->
  <script src="login_res/js/bootstrap.min.js"></script>
  <!-- Imagesloaded js -->
  <script src="login_res/js/imagesloaded.pkgd.min.js"></script>
  <!-- Validator js -->
  <script src="login_res/js/validator.min.js"></script>
  <!-- Custom Js -->
  <script src="login_res/js/main.js"></script>
  <script src="script.js"></script>
</body>

</html>