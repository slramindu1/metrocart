<?php

require "connection.php";

require "SMTP.php";
require "PHPMailer.php";
require "Exception.php";

use PHPMailer\PHPMailer\PHPMailer;

if (isset($_GET["e"])) {

    $email = $_GET["e"];



    $rs = Database::search("SELECT * FROM `users` WHERE `email`='" . $email . "'");
    $n = $rs->num_rows;

    if ($n == 1) {

        $code = sha1($email . time());
        $verification_url = 'http://localhost/store_3/verifyuser.php?code=' . $code;
        $dverify = 1;

        Database::iud("UPDATE `users` SET `verify_account_code`='" . $code . "' WHERE `email`='" . $email . "'");


        $mail = new PHPMailer;
        $mail->IsSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ramindu.jiat@gmail.com';
        $mail->Password = 'jsle xiaz qoxu wtwg';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        $mail->setFrom('ramindu.jiat@gmail.com', 'Reset Password');
        $mail->addReplyTo('ramindu.jiat@gmail.com', 'Reset Password');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Gadget Hub Account  Verification ';
        $bodyContent = ' <center><img src="https://raw.githubusercontent.com/slramindu1/mysite1/31b095254238b3df569eb36970c325dd7ae1741a/2.png?token=BBPIBBTZ72A6JQDTIHO5ZFDE4LWLQ"/></center>
        Dear User,<br><br>
        Thank you for choosing [Company/Organization Name] for your account needs. We appreciate your commitment to securing your account and maintaining a high level of security and trust.<br>

        To ensure the safety and integrity of your account, we kindly request your assistance in completing the account verification process. This procedure is an essential step to confirm your<br>
         identity and maintain the security of your account.
        
        Please follow the instructions below to verify your account:<br>
        

        
        Log In: Use your existing account credentials to log in to the verification portal.<br>
        
        Complete Verification Steps: Follow the on-screen instructions to complete the verification process. This may involve providing certain personal information or validating your account<br> using a one-time code sent to your registered email or phone number.
        
        Confirm Account Verification: Once you have successfully completed the verification process, your account will be verified, and you will receive a confirmation email.<br>
        
        Please note that failure to complete the account verification within [specified timeframe, e.g., 48 hours] may result in limited access to your account until the verification is complete.<br>
        
        If you encounter any difficulties during this process or have any questions, please feel free to contact our dedicated support team at [Customer Support Contact Information]<br>. We are here to assist you every step of the way.<br>
        
        Thank you for your cooperation in ensuring the security and privacy of your account. We value your trust and look forward to continuing to provide you with excellent service.
            <h4 style="font-weight:"bold";  font-weight:bold; ">Your verification code is ' . $verification_url . '</h4><br>
            <br>
            Best regards,<br>
            <br>
           Media Center <br><br>
           Customer Support Team
           alt="">
           ';


        $mail->Body    = $bodyContent;

        if (!$mail->send()) {
            echo 'Verification code sending failed';
        } else {
            echo 'Success';
        }
    } else {
        echo ("Invalid Email Address");
    }
}
