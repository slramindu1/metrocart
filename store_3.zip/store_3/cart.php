<!DOCTYPE html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Cart</title>
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />

  <!-- CSS
		============================================ -->

  <!-- Icon Font CSS -->
  <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="assets/css/icofont.css" />

  <!-- Plugins CSS -->
  <link rel="stylesheet" href="assets/css/animate.min.css" />
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/nivo-slider.css" />
  <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
  <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/magnific-popup.css" />
  <link rel="stylesheet" href="assets/css/percircle.css" />

  <!-- Main Style CSS -->
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/responsive.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>

<body>

  <?php
  include "header.php";
  if (isset($_SESSION["u"])) {

    $user = $_SESSION["u"]["email"];

    $total = 0;
    $subtal = 0;
    $shipping = 0;

  ?>

    <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="http://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->

    <?php

    $cart_rs = Database::search("SELECT * FROM `cart` WHERE `users_email`='" . $user . "'");
    $cart_num = $cart_rs->num_rows;

    if ($cart_num == 0) {

    ?>
      <div class="col-12">
        <div class="row">
          <div class="col-12 emptyCart"></div>
          <div class="col-12 text-center mb-2">
            <label class="form-label fs-1 fw-bold">
              <br>
              You have no items in your Cart yet.
            </label>
          </div>
          <div class="offset-lg-4 col-12 col-lg-4 mb-4 d-grid">
            <a href="home.php" class="btn btn-danger">
              Start Shopping
            </a>
          </div>
        </div>
      </div>
      <!-- Empty View -->
    <?php

    } else {
    ?>

      <!-- cart-area start -->
      <div class="cart-main-container shop-bg">
        <div class="cart-area">
          <div class="container">
            <div class="woocommerce-breadcrumb mtb-15">
              <div class="menu">
                <ul>
                  <li><a href="home.php">Home</a></li>
                  <li class="active"><a href="cart.php">cart</a></li>
                </ul>
              </div>
            </div>

            <div class="account-title mtb-20 text-center">
              <h1>Cart</h1>
            </div>

            <div class="cart-table mb-50 bg-fff">
              <form action="#">
                <div class="table-content table-responsive">
                  <table>
                    <thead>
                      <tr>
                        <th class="product-remove"></th>
                        <th class="product-thumbnail"></th>
                        <th class="product-name">Product</th>
                        <th class="product-seller">Seller</th>
                        <th class="product-price">Price</th>
                        <th class="product-quantity">Quantity</th>
                        <th class="product-subtotal">Total</th>
                      </tr>
                    </thead>
                    <tbody>

                      <?php
                      for ($x = 0; $x < $cart_num; $x++) {
                        $cart_data = $cart_rs->fetch_assoc();

                        $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $cart_data["product_id"] . "'");
                        $product_data = $product_rs->fetch_assoc();



                        $product_imgsearch = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $cart_data["product_id"] . "' LIMIT 1");
                        $product_img = $product_imgsearch->fetch_assoc();

                        $total = $total + ($product_data["price"] * $cart_data["qty"]);

                        $address_rs = Database::search("SELECT district.district_id AS did FROM `users_has_address` INNER JOIN `city` ON 
                        users_has_address.city_city_id=city.city_id INNER JOIN `district` ON city.district_district_id=district.district_id WHERE 
                        `users_email`='" . $user . "'");
                        $address_data = $address_rs->fetch_assoc();

                        $ship = 0;
                        $shipping = 0; // Initialize $shipping variable

                        if ($address_data && isset($address_data["did"])) {
                          if ($address_data["did"] == 4) {
                            $ship = $product_data["delivery_fee_colombo"];
                            $shipping = $shipping + $product_data["delivery_fee_colombo"];
                          } else {
                            $ship = $product_data["delivery_fee_other"];
                            $shipping = $shipping + $product_data["delivery_fee_other"];
                          }
                        }

                        $seller_rs = Database::search("SELECT * FROM `users` WHERE `email`='" . $product_data["users_email"] . "'");
                        $seller_data = $seller_rs->fetch_assoc();
                        $seller = $seller_data["fname"] . " " . $seller_data["lname"];

                      ?>
                        <!-- product area start -->
                        <tr class="cart-item">
                          <td class="product-remove">
                            <a href="#" class="remove" title="Remove this item" onclick="deleteFromCart(<?php echo $cart_data['id']; ?>);">Remove</a>
                          </td>
                          <td class="product-thumbnail">
                            <a href="#">
                              <img src="<?php echo $product_img["img_path"]; ?>" alt="" />
                            </a>
                          </td>

                          <td class="product-name">
                            <a href="#"><?php echo $product_data["title"]; ?> </a>
                          </td>
                          <td class="product-seller">
                            <a href="#"><?php echo $seller; ?></a>
                          </td>
                          <td class="product-price">
                            <span class="amounte">Rs. <?php echo $product_data["price"]; ?> .00</span>
                          </td>
                          <td class="product-quantity">
                            <input value="1" min="1" type="number" />
                          </td>
                          <td class="product-subtotal">
                            <span class="sub-total">Rs. <?php echo $product_data["price"]; ?> .00</span>
                          </td>
                        </tr>
                        <!-- product area end -->

                      <?php
                      }
                      ?>



                      <tr>
                        <td colspan="6" class="actions clear">
                          <div class="coupon mb-10 floatleft">
                            <input name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Coupon code" type="text" />
                            <input class="button" name="apply_coupon" value="Apply Coupon" type="submit" />
                          </div>
                          <div class="floatright mb-10">
                            <input class="button cursor-not" name="update_cart" value="Update Cart" type="submit" />
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </form>
            </div>

            <div class="row">
              <div class="col-lg-6">
                <!-- product area start -->
                <div class="cart-product bg-fff box-shadow mb-50">
                  <div class="product-title home2-bg-1 text-uppercase home2-product-title">
                    <i class="fa fa-bookmark icon bg-4"></i>
                    <h3>Cross-Sells</h3>
                  </div>
                  <div class="col-12 mb-3">
                    <div class="row ">

                      <div class="col-12">
                        <div class="row justify-content-center gap-2">

                          <?php

                          $product_rs = Database::search("SELECT * FROM `product` WHERE `category_cat_id` ORDER BY `datetime_added` DESC LIMIT 2 OFFSET 0");

                          $product_num = $product_rs->num_rows;

                          for ($x = 0; $x < $product_num; $x++) {
                            $product_data = $product_rs->fetch_assoc();

                          ?>

                            <div class="card col-12 col-lg-2 mt-2 mb-2" style="width: 18rem;">

                              <?php

                              $img_rs = Database::search("SELECT * FROM `product_img` WHERE 
                                            `product_id`='" . $product_data['id'] . "'");

                              $img_data = $img_rs->fetch_assoc();

                              ?>

                              <img src="<?php echo $img_data["img_path"]; ?>" class="card-img-top img-thumbnail mt-2" style="height: 250px;" />
                              <div class="card-body ms-0 m-0 text-center">
                                <h5 class="card-title fw-bold fs-6"><?php echo $product_data["title"]; ?></h5>
                                <span class="badge rounded-pill text-bg-info">New</span><br />
                                <span class="card-text text-primary">Rs. <?php echo $product_data["price"]; ?> .00</span><br />
                                <span class="card-text text-warning fw-bold">In Stock</span><br />
                                <span class="card-text text-success fw-bold"><?php echo $product_data["qty"]; ?> Items Available</span><br />
                                <a href="<?php echo "shop-simple-product.php?id=" . ($product_data["id"]); ?>" class="col-12 btn btn-success">Buy Now</a>
                                <button class="col-12 btn btn-dark mt-2" onclick="addToCart(<?php echo $product_data['id']; ?>);" style="height: 40px;">
                                  <i class="bi bi-cart4 text-white fs-5 "></i>
                                </button>

                                <button class="col-12 btn btn-secondary mt-2" onclick="addToWatchlist(<?php echo $product_data['id']; ?>);" style="height: 40px;">
                                  <i class="bi bi-heart-fill text-dark fs-5"></i>
                                </button>
                              </div>
                            </div>

                          <?php

                          }

                          ?>



                        </div>
                      </div>

                    </div>
                  </div>
                </div>
                <!-- product area end -->
              </div>
              <div class="col-lg-6">
                <div class="cart_totals">
                  <div class="cart-total-taitle mb-30 text-uppercase">
                    <h3>Cart Totals</h3>
                  </div>
                </div>
                <div class="table-content table-responsive mb-30">
                  <table>
                    <tr>
                      <td><strong>Subtotalitems (<?php echo $cart_num; ?>)</strong></td>
                      <td><b>Rs. <?php echo $total; ?> .00</b></td>
                    </tr>
                    <tr>
                      <td><strong>Shipping</strong></td>
                      <td><b>Rs. <?php echo  $shipping; ?> .00</b></td>
                    </tr>
                    <tr>
                      <td><strong>Total</strong></td>
                      <td><b>Rs. <?php echo $total + $shipping; ?> .00</b></td>
                    </tr>
                  </table>
                </div>
                <div class="simple-product-form contuct-form mb-30">
                  
                    <button onclick="checkout();">Proceed to Checkout</button>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php
    }
      ?>
      </div>
    <?php

  } else {
    echo ("Please login or signup first");
  }


  include "footer.php"
    ?>

    <!-- footer-area end -->

    <!-- JS Vendor, Plugins & Activation Script Files -->

    <!-- Vendors JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/jquery.mixitup.min.js"></script>
    <script src="assets/js/jquery-ui.min.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/jquery.countdown.min.js"></script>
    <script src="assets/js/jquery.nivo.slider.pack.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="script.js"></script>
    <!-- Activation JS -->
    <script src="assets/js/main.js"></script>
    <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>
</body>

</html>