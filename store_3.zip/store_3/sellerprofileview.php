<?php

require "connection.php";

if (isset($_GET["users_email"])) {
    $pid = $_GET["users_email"];

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <!-- Icon Font CSS -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
        <link rel="stylesheet" href="assets/css/icofont.css" />

        <!-- Plugins CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css" />
        <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="assets/css/nivo-slider.css" />
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
        <link rel="stylesheet" href="assets/css/jquery-ui.min.css" />
        <link rel="stylesheet" href="assets/css/magnific-popup.css" />
        <link rel="stylesheet" href="assets/css/percircle.css" />

        <!-- Main Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css" />
        <link rel="stylesheet" href="assets/css/responsive.css" />
    </head>

    <body>
        <?php include "headername.php"





        ?>
        <?php
        $details_rs = Database::search("SELECT `fname`,`lname`,`mobile` FROM `users` WHERE `email`='" . $pid . "'");
        $details = $details_rs->fetch_assoc();


        $banner_rs = Database::search("SELECT * FROM `profile_image` WHERE `users_email`='" . $pid . "'");
        $banner = $banner_rs->fetch_assoc();
        ?>

        <div class="container">
            <div>
                <br>
                <?php

                if (empty($banner["path_banner"])) {
                ?>
                    <img src="assets/images/banner.png" class="rounded img9" id="banner_view" />
                <?php
                } else {
                ?>
                    <img src="<?php echo $banner["path_banner"]; ?>" class="rounded img9" style="width: 1056px;" id="banner_view" />
                <?php
                }

                ?>
                <style>
                    .img9 {
                        width: 1356px;
                        height: 400px;
                    }
                </style>
                <br><br>
                <div class="row">
                    <div class="col-2">

                        <?php

                        if (empty($banner["path"])) {
                        ?>
                            <img src="assets/images/banner.png" class="rounded img10" id="logo" />
                        <?php
                        } else {
                        ?>
                            <img src="<?php echo $banner["path"]; ?>" class="rounded img10" id="logo" />
                        <?php
                        }

                        ?>
                        <style>
                            .img10 {
                                width: 500px;
                                height: 150px;
                            }
                        </style>
                    </div>
                    <div class="col-7 mt-3">
                        <h5>Seller Name = <?php echo $details["fname"]; ?> <?php echo $details["lname"]; ?></h5>
                        <h5>Seller Email = <?php echo ($pid); ?></h5>
                        <h5>Seller Mobile Number = <?php echo $details["mobile"]; ?></h5>
                    </div>
                    <div class="col-3">
                        <button class="btn btn-primary" onclick="follow();" id="followButton">Follow</button>
                      
                </div>
            </div>
            <br>
            <center>
                <h5>Seller Add Products</h5>
            </center>
            <div class="offset-1 col-10 text-center">
                <div class="row justify-content-center">

                    <?php

                    if (isset($_GET["page"])) {
                        $pageno = $_GET["page"];
                    } else {
                        $pageno = 1;
                    }

                    $product_rs = Database::search("SELECT * FROM `product` WHERE `users_email`='" . $pid . "'");
                    $product_num = $product_rs->num_rows;

                    $results_per_page = 6;
                    $number_of_pages = ceil($product_num / $results_per_page);

                    $page_results = ($pageno - 1) * $results_per_page;
                    $selected_rs =  Database::search("SELECT * FROM `product` WHERE `users_email`='" . $pid . "' 
                                    LIMIT " . $results_per_page . " OFFSET " . $page_results . "");

                    $selected_num = $selected_rs->num_rows;

                    for ($x = 0; $x < $selected_num; $x++) {
                        $selected_data = $selected_rs->fetch_assoc();
                    ?>

                        <!-- card -->
                        <div class="card mb-3 mt-3 col-12 col-lg-6">
                            <div class="row">
                                <div class="col-md-4 mt-4">
                                    <?php

                                    $product_img_rs = Database::search("SELECT * FROM `product_img` WHERE `product_id`='" . $selected_data["id"] . "'");
                                    $product_img_data = $product_img_rs->fetch_assoc();

                                    ?>
                                    <img src="<?php echo $product_img_data["img_path"]; ?>" class="img-fluid rounded-start" />
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title fw-bold"><?php echo $selected_data["title"]; ?></h5>
                                        <span class="card-text fw-bold text-primary">Rs. <?php echo $selected_data["price"]; ?> .00</span><br />
                                        <span class="card-text fw-bold text-success"><?php echo $selected_data["qty"]; ?> Items left</span>

                                        <div class="row">
                                            <div class="col-12">
                                                <div class="row g-1">
                                                    <div class="col-12 col-lg-6 d-grid">
                                                        <a href="<?php echo "shop-simple-product.php?id=" . ($product_data["id"]); ?>" class="col-12 btn btn-success">Buy Now</a>
                                                    </div>
                                                    <div class="col-12 col-lg-6 d-grid">
                                                        <button class="col-12 btn btn-danger" onclick="addToCart(<?php echo $product_data['id']; ?>);">Add To Cart</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- card -->

                    <?php
                    }

                    ?>

                </div>
            </div>
        </div>

        
        <!-- Vendors JS -->
        <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
        <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

        <!-- Plugins JS -->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/jquery.mixitup.min.js"></script>
        <script src="assets/js/jquery-ui.min.js"></script>
        <script src="assets/js/jquery.scrollUp.min.js"></script>
        <script src="assets/js/jquery.countdown.min.js"></script>
        <script src="assets/js/jquery.nivo.slider.pack.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="script.js"></script>
        <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>
        <!-- <script src="assets/js/zoom.js"></script>
  <script src="assets/js/jquery.js"></script> -->
        <script src="https://kit.fontawesome.com/02566f2f41.js" crossorigin="anonymous"></script>

        <!-- Activation JS -->
        <script src="assets/js/main.js"></script>
        <script src="script.js"></script>
    </body>

    </html>


<?php
} else {
    echo ("Invalid checking seller");
}

?>